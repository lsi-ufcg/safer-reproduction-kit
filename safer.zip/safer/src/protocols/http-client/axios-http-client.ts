import axios, { AxiosResponse } from 'axios';
import humps from 'humps';

import { HttpClient, HttpRequest, HttpResponse, HttpStatusCode } from '#protocols/http-client/http-client';

import loggerSync from '../../utils/logger';

const UPPER_LETTER_AND_NUMBER_REGEX = /(?=[A-Z0-9])/;

export class AxiosHttpClient implements HttpClient {
  private verbose: boolean;

  constructor(params: { verbose: boolean }) {
    this.verbose = params.verbose;
  }

  async request({ url, method, body, headers = {}, transformPayload = false, transformResponse = false, transformNumbers = true }: HttpRequest): Promise<HttpResponse> {
    let axiosResponse: AxiosResponse;
    const humpsOptions = transformNumbers ? { split: UPPER_LETTER_AND_NUMBER_REGEX } : undefined;

    try {
      const request = {
        url,
        method,
        data: transformPayload ? humps.decamelizeKeys(body, humpsOptions) : body,
        headers,
      };
      if (this.verbose) {
        loggerSync({ level: 'dir', object: request });
      }
      axiosResponse = await axios.request(request);
    } catch (error: any) {
      axiosResponse = error.response;
    }

    if (!axiosResponse) {
      // Service down, returns CORS error
      return {
        statusCode: HttpStatusCode.SERVICE_UNAVAILABLE,
        body: {
          error: {
            title: 'CORS Error',
            description: 'Service down. Error returned by axios HttpClient implementation',
          },
        },
      };
    }

    const response = {
      statusCode: axiosResponse.status,
      body: transformResponse ? humps.camelizeKeys(axiosResponse.data, humpsOptions) : axiosResponse.data,
    };
    if (this.verbose) {
      loggerSync({ level: 'dir', object: response });
    }

    return response;
  }
}
