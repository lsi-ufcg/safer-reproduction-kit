export type ProjectType = 'maven' | 'gradle';

export type WeightVulnerabilityType = {
  low: number;
  medium: number;
  high: number;
  critical: number;
  [key: string]: number;
};

export type ExecutionsType = {
  buildProject: boolean;
  projectTests: boolean;
  exploratoryTesting: boolean;
  clearLastLogs: boolean;
  clearLastReport: boolean;
};

export type ExploratoryTestingParamsType = {
  timeLimitGeneratingTests: number;
};

export type JsonConfigType = {
  weightVulnerability: WeightVulnerabilityType;
  executions: ExecutionsType;
  exploratoryTestingParams?: ExploratoryTestingParamsType;
};

export type ConfigType = JsonConfigType & {
  projectType: ProjectType;
  projectAbsolutePath: string;
};
