export type ProjectType = 'maven' | 'gradle';

export type WeightVulnerabilityType = {
  low: number;
  medium: number;
  high: number;
  critical: number;
  [key: string]: number;
};

export type ExecutionsType = {
  buildProject: boolean;
  projectTests: boolean;
  exploratoryTesting: boolean;
  /** Deprecated and ignored (every run gets its own directory); accepted so older configs stay valid. */
  clearLastLogs?: boolean;
  /** Deprecated and ignored (every run gets its own directory); accepted so older configs stay valid. */
  clearLastReport?: boolean;
};

export type ExploratoryTestingParamsType = {
  /** Seconds Randoop spends generating tests (default 60). */
  timeLimitGeneratingTests?: number;
};

export type SmokeTestConfigType = { enabled: boolean; command: string; timeoutSec: number };
export type OsvConfigType = { concurrency?: number; retries?: number };

export type JsonConfigType = {
  weightVulnerability: WeightVulnerabilityType;
  executions: ExecutionsType;
  exploratoryTestingParams?: ExploratoryTestingParamsType;
  allowPrerelease?: boolean;
  alignmentCheck?: boolean;
  smokeTest?: SmokeTestConfigType;
  osv?: OsvConfigType;
  /** Seconds before a project build (`mvn clean verify` or `./gradlew clean build`) is killed (default 3600). */
  buildTimeoutSec?: number;
};

export type ConfigType = JsonConfigType & {
  projectType: ProjectType;
  projectAbsolutePath: string;
};
