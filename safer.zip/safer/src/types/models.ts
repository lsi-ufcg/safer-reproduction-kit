import { ExecutionsType } from './config';

export type DependencyVulnerability = {
  id: string;
  severity: string;
  severityScore: number;
  isTransitive: boolean;
  sourceDependency: Dependency | undefined;
};

export type ReportData = {
  dependenciesVersionsRank: { dependency: Dependency; rank: VersionVulnerability[] }[];
  appliedDependencies: { dependency: Dependency; version: string }[];
  executions: ExecutionsType;
};

// for more info: https://github.com/package-url/purl-spec
export type Dependency = {
  group: string;
  name: string;
  version: string;
};

export type Dependencies = {
  parent: Dependency;
  standard: Dependency[];
};

export type VersionVulnerability = { version: string; detailsDependencyVulnerability: { details: DependencyVulnerability[]; rate: number } };
