export type Text = {
  _text: string;
};

type XmlJsDependency = {
  groupId: Text;
  artifactId: Text;
  version?: Text;
  scope?: Text;
};

export type XmlElement = {
  type: string;
  name: string;
  elements?: XmlElement[];
  text?: string;
}

export type PomJs = {
  project: {
    parent: XmlJsDependency;
    properties: {
      'java.version': {
        _text: string;
      };
    };
    dependencies: {
      dependency: XmlJsDependency[];
    };
  };
};

export type MavenMetadataJs = {
  metadata: { versioning: { versions: { version: Text[] } } };
};
