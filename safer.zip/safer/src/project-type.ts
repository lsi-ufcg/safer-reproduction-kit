import fs from 'fs';
import path from 'path';

import { ProjectType } from './types/config';

/** `pom.xml` → maven; `build.gradle` or `build.gradle.kts` → gradle (root project only); otherwise null. */
export function detectProjectType(dir: string): ProjectType | null {
  const has = (f: string) => fs.existsSync(path.join(dir, f));
  if (has('pom.xml')) return 'maven';
  if (has('build.gradle') || has('build.gradle.kts')) return 'gradle';
  return null;
}
