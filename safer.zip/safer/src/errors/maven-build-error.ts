import { ExecException } from 'child_process';

export class MavenBuildError extends Error {
  error: ExecException;

  constructor(error: ExecException) {
    super('Maven build error');
    this.error = error;
  }
}
