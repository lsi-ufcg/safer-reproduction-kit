import { promises as fs } from 'fs';
import path from 'path';

import Ajv from 'ajv';

import { JsonConfigType } from '../types/config';

const ajv = new Ajv();

async function getJsonConfig(): Promise<JsonConfigType> {
  const saferRoot = process.env.SAFER_ROOT_PATH ?? path.resolve('..');
  const configPath = process.env.SAFER_CONFIG ?? path.join(saferRoot, 'config.json');
  const schemaPath = path.join(saferRoot, 'src/types/schema_config.json');

  try {
    const [configContent, schemaContent] = await Promise.all([fs.readFile(configPath, 'utf8'), fs.readFile(schemaPath, 'utf8')]);

    const config: JsonConfigType = JSON.parse(configContent);
    const schema = JSON.parse(schemaContent);

    const validate = ajv.compile(schema);
    if (!validate(config)) {
      console.error('Configuration JSON is invalid.');
      console.error(validate.errors?.map(error => error.message).join(', '));
      process.exit(1);
    }

    _validateWeightVulnerability(config.weightVulnerability);
    _validateExecutions(config.executions);
    if (config.executions.exploratoryTesting && config.exploratoryTestingParams) {
      _validateExploratoryTestingParams(config.exploratoryTestingParams);
    }

    return config;
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
      process.exit(1);
    } else {
      console.error('An unexpected error occurred.');
      process.exit(1);
    }
  }
}


function _validateWeightVulnerability(weightVulnerability: any): void {
  const levels = ['low', 'medium', 'high', 'critical'];
  levels.forEach(level => {
    const value = weightVulnerability[level];
    if (value === undefined || isNaN(Number(value))) {
      console.error(`Invalid value for weightVulnerability.${level}: '${value}'. All levels must be valid numbers.`);
      process.exit(1);
    }
  });
}

function _validateExecutions(executions: any): void {
  const properties = ['buildProject', 'projectTests', 'exploratoryTesting']; // clearLastLogs/clearLastReport: deprecated, ignored
  properties.forEach(property => {
    const value = executions[property];
    if (value === undefined || typeof value !== 'boolean') {
      console.error(`Invalid value for executions.${property}: '${value}'. All properties must be valid booleans.`);
      process.exit(1);
    }
  });
}

function _validateExploratoryTestingParams(exploratoryTestingParams: any): void {
  const properties = ['timeLimitGeneratingTests'];
  properties.forEach(property => {
    const value = exploratoryTestingParams[property];
    if (value !== undefined && isNaN(Number(value))) {
      console.error(`Invalid value for exploratoryTestingParams.${property}: '${value}'.`);
      process.exit(1);
    }
  });
}

export { getJsonConfig };
