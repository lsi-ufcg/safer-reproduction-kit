import fs from 'fs';
import os from 'os';
import path from 'path';

import { describe, expect, it } from 'vitest';

import { getJsonConfig } from './get-config';

describe('getJsonConfig', () => {
  it('accepts the new optional keys and reads SAFER_CONFIG', async () => {
    const file = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'safer-cfg-')), 'c.json');
    fs.writeFileSync(file, JSON.stringify({
      weightVulnerability: { low: 1, medium: 2, high: 3, critical: 5 },
      executions: { buildProject: true, projectTests: false, exploratoryTesting: false, clearLastLogs: true, clearLastReport: true },
      allowPrerelease: false,
      alignmentCheck: true,
      smokeTest: { enabled: true, command: 'true', timeoutSec: 10 },
      osv: { concurrency: 4, retries: 2 },
    }));
    process.env.SAFER_ROOT_PATH = path.resolve(__dirname, '../..');
    process.env.SAFER_CONFIG = file;
    const cfg = await getJsonConfig();
    expect(cfg.smokeTest?.command).toBe('true');
    expect(cfg.osv?.concurrency).toBe(4);
  });

  it('accepts exploratory testing without params and without the deprecated clear* flags', async () => {
    const file = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'safer-cfg-')), 'c.json');
    fs.writeFileSync(file, JSON.stringify({
      weightVulnerability: { low: 1, medium: 2, high: 3, critical: 5 },
      executions: { buildProject: true, projectTests: false, exploratoryTesting: true },
    }));
    process.env.SAFER_ROOT_PATH = path.resolve(__dirname, '../..');
    process.env.SAFER_CONFIG = file;
    const cfg = await getJsonConfig();
    expect(cfg.executions.exploratoryTesting).toBe(true);
    expect(cfg.exploratoryTestingParams).toBeUndefined();
  });
});
