export const SemanticVersioningHelper = {
  compareVersions: (versionA: string, versionB: string) => {
    const splitA = versionA.split('.').map(Number);
    const splitB = versionB.split('.').map(Number);

    // Compare MAJOR, MINOR, and PATCH versions
    for (let i = 0; i < splitA.length; i++) {
      if (splitA[i] > splitB[i]) {
        return 1;
      } else if (splitA[i] < splitB[i]) {
        return -1;
      }
    }

    // All components are equal
    return 0;
  },
};
