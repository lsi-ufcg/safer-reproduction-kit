import { makeHttpClient } from '#protocols/http-client/http-client';
import { Dependency } from '#types/models';

import { SonatypeRepositoryGetDependencyNewerVersions } from './impl/sonatype/sonatype-repository-get-depedendency-newer-versions';

export interface GetDependencyNewerVersions {
  execute(dependency: Dependency): Promise<string[]>;
}

export const makeGetDependencyNewerVersionsService = (): GetDependencyNewerVersions =>
  new SonatypeRepositoryGetDependencyNewerVersions(makeHttpClient());
