import { ReportData } from '#types/models';


export interface ReportExecution {
  execute(reportData: ReportData): void;
}