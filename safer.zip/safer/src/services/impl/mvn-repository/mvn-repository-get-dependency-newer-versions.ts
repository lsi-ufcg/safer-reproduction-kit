import convert from 'xml-js';

import { MVN_REPOSITORY_BASE_URL } from '#config/environment';
import { SemanticVersioningHelper } from '#helpers/semantic-versioning-helper';
import { HttpClient } from '#protocols/http-client/http-client';
import { GetDependencyNewerVersions } from '#services/get-dependency-newer-versions';
import { Dependency } from '#types/models';
import { MavenMetadataJs, Text } from '#types/xml-js';

export class MvnRepositoryGetDependencyNewerVersions implements GetDependencyNewerVersions {
  constructor(private readonly httpClient: HttpClient) {}

  async execute(dependency: Dependency): Promise<string[]> {
    const httpResponse = await this.httpClient.request({
      method: 'get',
      url: `${MVN_REPOSITORY_BASE_URL}/${resolveEndpoint(dependency)}`,
    });

    const response = convert.xml2js(httpResponse.body, { compact: true }) as MavenMetadataJs;
    const versions = response.metadata.versioning.versions.version
      .map(version => extractSemanticVersioning(version))
      .sort(SemanticVersioningHelper.compareVersions);
    const versionsSet = versions.filter((version, index) => versions.indexOf(version) === index);
    const startIndex = versionsSet.findIndex(version => version === dependency.version);
    const newerVersions = versionsSet.slice(startIndex, versionsSet.length);
    return newerVersions;
  }
}

const resolveEndpoint = (dependency: Dependency) => {
  return `${dependency.group.split('.').join('/')}/${dependency.name}/maven-metadata.xml`;
};

const extractSemanticVersioning = (version: Text) => {
  const [major, minor, patch] = version._text.split('.');
  const hasPatchVersion = !isNaN(Number(patch));
  if (hasPatchVersion) {
    return `${major}.${minor}.${patch.split('-')[0]}`;
  }
  return `${major}.${minor.split('-')[0]}`;
};
