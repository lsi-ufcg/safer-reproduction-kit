import { DEPS_DEV_BASE_URL } from '#config/environment';
import { HttpClient } from '#protocols/http-client/http-client';
import { GetDependencyVulnerabilities, GetDependencyVulnerabilitiesParams } from '#services/get-dependency-vulnerabilities';
import { DependencyVulnerability } from '#types/models';

export class DepsDevGetDependencyVulnerabilities implements GetDependencyVulnerabilities {
  constructor(private readonly httpClient: HttpClient) {}

  async execute(params: GetDependencyVulnerabilitiesParams): Promise<DependencyVulnerability[]> {
    const httpResponse = await this.httpClient.request({
      url: `${DEPS_DEV_BASE_URL}/maven/p/${encodeURI(`${params.dependency.group}:${params.dependency.name}`)}/v/${params.version}/dependencies`,
      method: 'get',
    });
    const depsDevVulnerabilities = httpResponse.body?.dependencies ?? [];
    const vulnerabilities = depsDevVulnerabilities.map((dependency: any) => {
      const advisories = dependency.advisories ?? [];
      const [group, name] = dependency.package.name.split(':');
      const version = dependency.version;
      return advisories.map((vulnerability: any) => {
        const severity = vulnerability.gitHubSeverity?.toLowerCase() === 'moderate' ? 'medium' : vulnerability.gitHubSeverity?.toLowerCase();
        return {
          id: vulnerability.sourceID,
          severity: severity,
          severityScore: vulnerability.scoreV3 || _getScoreDefault(severity),
          isTransitive: dependency.distance > 0,
          sourceDependency: {
            group,
            name,
            version,
          },
        };
      });
    });
    return vulnerabilities.flat(Infinity);
  }
}
function _getScoreDefault(severity: any): any {
  switch (severity.toLowerCase()) {
    case 'none':
    case undefined:
    case null:
      return 0.0;
    case 'low':
      return 0.1; // Start of the "Low" severity range
    case 'medium':
      return 4.0; // Start of the "Medium" severity range
    case 'high':
      return 7.0; // Start of the "High" severity range
    case 'critical':
      return 9.0; // Start of the "Critical" severity range
    default:
      return 0.0;
  }
}
