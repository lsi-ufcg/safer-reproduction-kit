import { ReportExecution } from '#services/report';
import { ProjectType } from '#types/config';
import { ReportData } from '#types/models';

import LOGGER_REPORT from '../../../utils/loggerReport';

type VulnerabilityCounters = {
  low: number;
  medium: number;
  high: number;
  critical: number;
  [key: string]: number;
};

type SeverityDetails = {
  [dependency: string]: { [severity: string]: string[] };
};

interface VulnerabilitiesDetails {
  before: SeverityDetails;
  after: SeverityDetails;
}

export class ReportMaven implements ReportExecution {
  constructor(private readonly projectType: ProjectType) {}

  execute(reportData: ReportData): void {
    LOGGER_REPORT.info('Dependency and Security Report\n', { color: 'bold.underline' });
    // TODO: Parameterize this information
    const infoData = 'The information was obtained from Open Source Insights, which gathers security advisories information from OSV.\n';
    LOGGER_REPORT.info(infoData, { color: 'bold.underline' });
    LOGGER_REPORT.info('Analyzed Dependencies:\n', { color: 'bold' });
    const initialVulnerabilities: VulnerabilityCounters = { low: 0, medium: 0, high: 0, critical: 0 };
    const finalVulnerabilities: VulnerabilityCounters = { low: 0, medium: 0, high: 0, critical: 0 };
    const vulnerabilitiesDetails: VulnerabilitiesDetails = { before: {}, after: {} };
    const dependenciesWithVulnerabilitiesBefore = new Set<string>();
    const dependenciesWithVulnerabilitiesAfter = new Set<string>();

    reportData.dependenciesVersionsRank.forEach(depRank => {
      const dep = depRank.dependency;
      const appliedVersion = reportData.appliedDependencies.find(ad => ad.dependency.name === dep.name && ad.dependency.group === dep.group)?.version;
      const versionLabel = dep.version === appliedVersion ? '[NEW] [OLD]' : '[OLD]';
      LOGGER_REPORT.info(`- ${dep.group}:${dep.name}: ${dep.version} ${versionLabel}`, { color: 'green' });

      depRank.rank.forEach(version => {
        const isNewVersion = version.version === appliedVersion;
        const isOldVersion = version.version === dep.version;
        const versionTag = isNewVersion ? `[NEW]${isOldVersion ? ' [OLD]' : ''}` : isOldVersion ? '[OLD]' : '';
        LOGGER_REPORT.info(`  Version: ${version.version} ${versionTag}, Vulnerabilities: ${version.detailsDependencyVulnerability.rate}`, { color: 'yellow' });
        version.detailsDependencyVulnerability.details.forEach(vul => {
          const severityKey = vul.severity.toLowerCase();
          const depIdentifier = `${dep.group}:${dep.name}: ${dep.version}`;
          const vulDetail = `ID: ${vul.id}, Severity: ${vul.severity}, Score: ${vul.severityScore}, Transitive: ${vul.isTransitive ? 'Yes' : 'No'}`;
          LOGGER_REPORT.info(`    ${vulDetail}`, { color: 'red' });

          if (isNewVersion) {
            finalVulnerabilities[severityKey] += 1;
            vulnerabilitiesDetails.after[depIdentifier] = vulnerabilitiesDetails.after[depIdentifier] || {};
            vulnerabilitiesDetails.after[depIdentifier][severityKey] = vulnerabilitiesDetails.after[depIdentifier][severityKey] || [];
            vulnerabilitiesDetails.after[depIdentifier][severityKey].push(vulDetail);
            dependenciesWithVulnerabilitiesAfter.add(depIdentifier);
          }
          if (isOldVersion) {
            initialVulnerabilities[severityKey] += 1;
            vulnerabilitiesDetails.before[depIdentifier] = vulnerabilitiesDetails.before[depIdentifier] || {};
            vulnerabilitiesDetails.before[depIdentifier][severityKey] = vulnerabilitiesDetails.before[depIdentifier][severityKey] || [];
            vulnerabilitiesDetails.before[depIdentifier][severityKey].push(vulDetail);
            dependenciesWithVulnerabilitiesBefore.add(depIdentifier);
          }
          if (vul.sourceDependency) {
            LOGGER_REPORT.info(`    Source Dependency: ${vul.sourceDependency.group}:${vul.sourceDependency.name}:${vul.sourceDependency.version}`, { color: 'blue' });
          }
        });
      });

      LOGGER_REPORT.info('');
    });

    LOGGER_REPORT.info('It was executed:', { color: 'bold' });
    LOGGER_REPORT.info(`- Project Build: ${reportData.executions.buildProject ? 'Yes' : 'No'}`, { color: 'cyan' });
    LOGGER_REPORT.info(`- Project Tests: ${reportData.executions.projectTests ? 'Yes' : 'No'}`, { color: 'cyan' });
    LOGGER_REPORT.info(`- Exploratory Testing: ${reportData.executions.exploratoryTesting ? 'Yes' : 'No'}`, { color: 'cyan' });
    LOGGER_REPORT.info('');

    LOGGER_REPORT.info('Vulnerabilities Summary:', { color: 'bold.underline' });
    LOGGER_REPORT.info(infoData, { color: 'bold.underline' });
    LOGGER_REPORT.info(`Number of dependencies with vulnerabilities:\n Before: ${dependenciesWithVulnerabilitiesBefore.size} After: ${dependenciesWithVulnerabilitiesAfter.size}`, { color: 'yellow' });
    const numberOfVulnerabilities = {
      before: Object.values(initialVulnerabilities).reduce((acc, cur) => acc + cur, 0),
      after: Object.values(finalVulnerabilities).reduce((acc, cur) => acc + cur, 0),
    };
    LOGGER_REPORT.info(`Number of vulnerabilities:\n Before: ${numberOfVulnerabilities.before} After: ${numberOfVulnerabilities.after}`, { color: 'yellow' });
    LOGGER_REPORT.info(
      `Before execution, total vulnerabilities were:\n Low: ${initialVulnerabilities.low}, Medium: ${initialVulnerabilities.medium}, High: ${initialVulnerabilities.high}, Critical: ${initialVulnerabilities.critical}`,
      { color: 'yellow' },
    );
    LOGGER_REPORT.info(
      `After execution, total vulnerabilities are:\n Low: ${finalVulnerabilities.low}, Medium: ${finalVulnerabilities.medium}, High: ${finalVulnerabilities.high}, Critical: ${finalVulnerabilities.critical}`,
      { color: 'yellow' },
    );

    LOGGER_REPORT.info('Details of vulnerabilities before execution:', { color: 'bold' });
    Object.entries(vulnerabilitiesDetails.before).forEach(([dep, details]) => {
      LOGGER_REPORT.info(`Dependency ${dep}:`, { color: 'blue' });
      Object.entries(details).forEach(([, vuls]) => {
        vuls.forEach(vul => {
          LOGGER_REPORT.info(`- ${vul}`, { color: 'red' });
        });
      });
    });
    LOGGER_REPORT.info('Details of vulnerabilities after execution:', { color: 'bold' });
    Object.entries(vulnerabilitiesDetails.after).forEach(([dep, details]) => {
      LOGGER_REPORT.info(`Dependency ${dep}:`, { color: 'blue' });
      Object.entries(details).forEach(([, vuls]) => {
        vuls.forEach(vul => {
          LOGGER_REPORT.info(`- ${vul}`, { color: 'red' });
        });
      });
    });
    LOGGER_REPORT.info('');

    LOGGER_REPORT.info('CSV:');
    LOGGER_REPORT.info(
      'Number of dependencies with vulnerabilities (Before),Number of dependencies with vulnerabilities (After),Number of vulnerabilities (Before),Number of vulnerabilities (After),Low vulnerabilities (Before),Low vulnerabilities (After),Medium vulnerabilities (Before),Medium vulnerabilities (After),High vulnerabilities (Before),High vulnerabilities (After),Critical vulnerabilities (Before),Critical vulnerabilities (After),Project Type',
    );
    LOGGER_REPORT.info(
      `${dependenciesWithVulnerabilitiesBefore.size},${dependenciesWithVulnerabilitiesAfter.size},${numberOfVulnerabilities.before},${numberOfVulnerabilities.after},${initialVulnerabilities.low},${finalVulnerabilities.low},${initialVulnerabilities.medium},${finalVulnerabilities.medium},${initialVulnerabilities.high},${finalVulnerabilities.high},${initialVulnerabilities.critical},${finalVulnerabilities.critical},${this.projectType}`,
    );

    LOGGER_REPORT.info('Recommendations:', { color: 'bold' });
    LOGGER_REPORT.info(
      '- Prioritize updating dependencies to their latest, compatible versions that pass all builds and tests, while also manually reviewing and applying updates to the most secure versions available, even if this requires additional compatibility adjustments.',
      { color: 'magenta' },
    );
    LOGGER_REPORT.info(
      '- Regularly conduct comprehensive security audits to promptly identify and address vulnerabilities within dependencies, incorporating both automated tools and expert reviews to ensure thorough coverage.',
      { color: 'magenta' },
    );
    LOGGER_REPORT.info(
      '- Adopt secure coding practices throughout the development lifecycle to prevent the introduction of vulnerabilities, emphasizing code reviews, secure coding standards, and developer training on security best practices.',
      { color: 'magenta' },
    );
    LOGGER_REPORT.info(
      '- Leverage automated testing, continuous integration, and continuous deployment (CI/CD) pipelines to maintain high standards of code quality and security, ensuring that any changes, including dependency updates, undergo rigorous testing before deployment.',
      { color: 'magenta' },
    );
    LOGGER_REPORT.info('');

    LOGGER_REPORT.info('Please consider the above recommendations to improve the security and stability of your project.\n\n', { color: 'bold' });
  }
}
