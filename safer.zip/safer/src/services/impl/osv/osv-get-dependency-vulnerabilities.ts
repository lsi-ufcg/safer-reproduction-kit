import { parseCvssVector } from 'vuln-vects';

import { OSV_BASE_URL } from '#config/environment';
import { HttpClient } from '#protocols/http-client/http-client';
import { GetDependencyVulnerabilities, GetDependencyVulnerabilitiesParams } from '#services/get-dependency-vulnerabilities';
import { DependencyVulnerability } from '#types/models';

export class OsvGetDependencyVulnerabilities implements GetDependencyVulnerabilities {
  constructor(private readonly httpClient: HttpClient) {}

  async execute(params: GetDependencyVulnerabilitiesParams): Promise<DependencyVulnerability[]> {
    const httpResponse = await this.httpClient.request({
      url: `${OSV_BASE_URL}/query`,
      method: 'post',
      body: {
        package: {
          name: params.dependency.name,
          ecosystem: 'Maven'
        },
        version: params.version,
      },
    });

    const osvVulnerabilities = httpResponse.body.vulns ?? [];

    const vulnerabilities = osvVulnerabilities.map((osvVulnerability: any) => {
      const severityStr = osvVulnerability.affected[0].severity[0].score as string;
      const cvssVectorScore = parseCvssVector(severityStr);
      const severityScore = cvssVectorScore.overallScore;
      const severity = cvssVectorScore.cvss3OverallSeverityText;
      return {
        id: osvVulnerability.id,
        severityScore,
        severity,
        isTransitive: false,
      };
    });
    return vulnerabilities;
  }
}
