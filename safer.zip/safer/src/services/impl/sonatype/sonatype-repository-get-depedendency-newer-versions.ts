import { SONATYPE_REPOSITORY_BASE_URL } from '#config/environment';
import { HttpClient } from '#protocols/http-client/http-client';
import { GetDependencyNewerVersions } from '#services/get-dependency-newer-versions';
import { Dependency } from '#types/models';

import loggerSync from '../../../utils/logger';

export class SonatypeRepositoryGetDependencyNewerVersions implements GetDependencyNewerVersions {
  constructor(private readonly httpClient: HttpClient) {}

  async execute(dependency: Dependency): Promise<string[]> {
    const targetVersion = dependency.version;
    let currentPage = 0;
    const allVersions = [];
    let targetVersionFound = false;

    const fetchPage = async (page: number) => {
      const params = {
        filter: `namespace:${dependency.group},name:${dependency.name}`,
        sortField: 'normalizedVersion',
        sortDirection: 'desc',
        page: `${page}`,
        size: '20',
      };

      try {
        const response = await this.httpClient.request({
          method: 'get',
          url: `${SONATYPE_REPOSITORY_BASE_URL}?${new URLSearchParams(params)}`,
        });
        return response.body;
      } catch (error: any) {
        loggerSync({ level: 'error', message: `Error fetching versions for dependency: ${dependency.group}:${dependency.name}`, object: error });
        throw error;
      }
    };

    while (!targetVersionFound) {
      const data = await fetchPage(currentPage);
      const versions = data.components.map((item: { version: string }) => item.version);
      allVersions.push(...versions);

      if (versions.includes(targetVersion)) {
        targetVersionFound = true;
      } else {
        currentPage++;
        if (currentPage >= data.pageCount) {
          loggerSync({ level: 'error', message: `Target version not found in available versions.  ${dependency.group}:${dependency.name}:${dependency.version}` });
          break;
        }
      }
    }

    const targetIndex = allVersions.indexOf(targetVersion);
    const versionsFromTargetToLatest = allVersions.slice(0, targetIndex + 1);

    return versionsFromTargetToLatest.length > 0 ? versionsFromTargetToLatest : allVersions;
  }
}
