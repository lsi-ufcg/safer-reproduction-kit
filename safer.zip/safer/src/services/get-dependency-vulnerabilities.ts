import { makeHttpClient } from '#protocols/http-client/http-client';
import { Dependency, DependencyVulnerability } from '#types/models';

import { DepsDevGetDependencyVulnerabilities } from './impl/deps-dev/deps-dev-get-dependency-vulnerabilities';

// import { OsvGetDependencyVulnerabilities } from './impl/osv/osv-get-dependency-vulnerabilities';

export type GetDependencyVulnerabilitiesParams = {
  dependency: Dependency;
  version: string;
};

export interface GetDependencyVulnerabilities {
  execute(params: GetDependencyVulnerabilitiesParams): Promise<DependencyVulnerability[]>;
}

export const makeGetDependencyVulnerabilitiesService = (): GetDependencyVulnerabilities => new DepsDevGetDependencyVulnerabilities(makeHttpClient());
