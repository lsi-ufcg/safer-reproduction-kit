import execCommand from '../../utils/execCommand';

import * as path from 'path';
import * as dotenv from 'dotenv';

dotenv.config({
    path: path.resolve('.', '../.env'),
});
const saferPath = process.env.SAFER_ROOT_PATH;

export const JavaRunner = {
  initJavaContainer: (javaVersion: string, projectAbsolutePath: string) => {
    console.log(projectAbsolutePath);
    execCommand(`${saferPath}/src/runners/java/init-java-container.sh ${javaVersion} ${projectAbsolutePath} ${saferPath}`);
  },
  deleteJavaContainer: () => {
    execCommand(`${saferPath}/src/runners/java/delete-java-container.sh`);
  },
};
