#!/bin/bash
JAVA_VERSION=$1
PROJECT_PATH=$2
SAFER_PATH=$3

echo "Building Docker Image for project $(basename $PROJECT_PATH) with Java version $JAVA_VERSION..."
docker buildx build -f $SAFER_PATH/src/runners/java/Dockerfile --build-arg JAVA_VERSION=$JAVA_VERSION -t java-setup .


if [ $? -eq 0 ]; then
    echo "Image built successfully. Running container..."
    echo $PROJECT_PATH
    docker run --network="host" -v ${PROJECT_PATH}:/app -u $(id -u):$(id -g) --name java-container-safer-$(basename $PROJECT_PATH) java-setup &
    # Waits for the container process to start before triggering maven builds
    sleep 3
else
    echo "Failed to build image."
    exit 1
fi
