#!/bin/bash
JAVA_VERSION=$1
PROJECT_PATH=$2
SAFER_PATH=$3

echo "Construindo a imagem Docker para o projeto($PROJECT_PATH) com Java $JAVA_VERSION..."
docker buildx build -f $SAFER_PATH/src/runners/java/Dockerfile --build-arg JAVA_VERSION=$JAVA_VERSION -t java-setup .


if [ $? -eq 0 ]; then
    echo "Imagem construída com sucesso. Executando o contêiner..."
    echo $PROJECT_PATH
    docker run --network="host" -v /home/$USER/.m2:/root/.m2 -v ${PROJECT_PATH}:/app --name java-container-safer java-setup &
    # Waits for the container process to start before triggering maven builds
    sleep 3
else
    echo "Falha na construção da imagem."
    exit 1
fi
