#!/bin/bash
JAVA_VERSION=$1
PROJECT_PATH=$2
SAFER_PATH=$3
# This run's container: java-container-safer-<Safer pid>, so concurrent Safer runs never remove each other's container
CONTAINER=${4:-java-container-safer}
# One image per Java version: concurrent runs on different versions must not retag each other's image
IMAGE="java-setup:${JAVA_VERSION}"

echo "Building Docker Image for project ($PROJECT_PATH) with Java version $JAVA_VERSION..."
docker buildx build -f $SAFER_PATH/src/runners/java/Dockerfile --build-arg JAVA_VERSION=$JAVA_VERSION -t "$IMAGE" .


if [ $? -eq 0 ]; then
    # Use the local Nexus as a Maven Central cache; if it does not come up, Maven downloads from Central directly
    NEXUS_MOUNT=""
    if $SAFER_PATH/src/runners/nexus/start-nexus.sh; then
        NEXUS_MOUNT="-v $SAFER_PATH/src/runners/nexus/settings.xml:/usr/share/maven/conf/settings.xml:ro"
    else
        echo "Nexus unavailable, Maven will download directly from Maven Central."
    fi

    # The container runs with the host UID, which is not in the image's /etc/passwd: without HOME=/tmp Java
    # resolves user.home to "?" and Maven creates its local repository in /app/?/.m2 (inside the project).
    # A persistent cache on the host, shared between projects, is mounted instead.
    M2_CACHE="${HOME}/.cache/safer/m2"
    mkdir -p "${M2_CACHE}"
    # Gradle cache (GRADLE_USER_HOME=/tmp/.gradle: wrapper, dependencies) and Safer's init script (/safer, read-only)
    GRADLE_CACHE="${HOME}/.cache/safer/gradle"
    mkdir -p "${GRADLE_CACHE}"

    # Remove containers left by Safer runs that were killed before cleaning up (their process no longer exists);
    # containers of runs still alive are never touched. A leftover with this run's own name is removed too.
    for c in $(docker ps -a --format '{{.Names}}' | grep -E '^java-container-safer-[0-9]+$'); do
        pid=${c##*-}
        if [ "$c" = "$CONTAINER" ] || [ ! -d "/proc/$pid" ]; then
            docker rm -f "$c" > /dev/null 2>&1
        fi
    done

    echo "Image built successfully. Running container for $PROJECT_PATH..."
    # Detached: the caller waits until `docker exec` works before starting builds
    docker run -d --network="host" --memory="${SAFER_CONTAINER_MEMORY:-4g}" -e HOME=/tmp -e MAVEN_OPTS="-Xmx1024m -Duser.home=/tmp" -e JAVA_TOOL_OPTIONS="-Xmx1024m" ${NEXUS_MOUNT} -v ${M2_CACHE}:/tmp/.m2 -v ${GRADLE_CACHE}:/tmp/.gradle -v ${SAFER_PATH}/src/runners/gradle:/safer:ro -v ${PROJECT_PATH}:/app -u $(id -u):$(id -g) --name "$CONTAINER" "$IMAGE" || exit 1
else
    echo "Failed to build image."
    exit 1
fi
