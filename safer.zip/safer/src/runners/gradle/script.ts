import { ConfigType } from '../../types/config';
import { createRunLog, runSafer, saferRootPath } from '../run-safer';
import { GradleTool } from './gradle-tool';

/** Root project only: subprojects and buildSrc are not analysed. */
export const runForGradle = async (config: ConfigType): Promise<void> => {
  const saferRoot = saferRootPath();
  const log = createRunLog(config, saferRoot);
  const tool = new GradleTool({ projectPath: config.projectAbsolutePath, saferRoot, logDir: log.runDir, buildTimeoutSec: config.buildTimeoutSec ?? 3600 });
  await runSafer(config, tool, log, { saferRoot });
};
