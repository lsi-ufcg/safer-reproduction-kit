import { GradleAdapter } from './gradle-adapter';
import loggerSync from './../../utils/logger';
import { ConfigType, ExecutionsType, WeightVulnerabilityType } from '#types/config';
import { JavaRunner } from './../../runners/java/java-runner';
import { makeGetDependencyNewerVersionsService } from '#services/get-dependency-newer-versions';
import { Dependency, DependencyVulnerability, VersionVulnerability } from '#types/models';
import { SemanticVersioningHelper } from '#helpers/semantic-versioning-helper';
import { makeGetDependencyVulnerabilitiesService } from '#services/get-dependency-vulnerabilities';
import { RandoopRunner } from '#runners/randoop/randoop-runner';
import { gradleProjectPath } from './utils'
import { MavenAdapter } from "#runners/maven/maven-adapter";
import { MavenRunner } from '#runners/maven/maven-runner';
import { ReportMaven } from '#services/impl/report/maven';
import { updateDependencyVersions } from '#runners/gradle/updateToGradle'
import { exit } from 'process';
import { GradleRunner } from './gradle-runner';

const getDependencyVulnerabilitiesService = makeGetDependencyVulnerabilitiesService();
const getDependencyNewerVersionsService = makeGetDependencyNewerVersionsService();

// configuração de exemplo para a execução do script
const config: ConfigType = {
  projectType: 'gradle',
  projectAbsolutePath: gradleProjectPath,
  weightVulnerability: {
    low: 1,
    medium: 2,
    high: 3,
    critical: 4
  },
  executions: {
    buildProject: true,
    projectTests: false,
    exploratoryTesting: false,
    clearLastLogs: false,
    clearLastReport: false
  },
  exploratoryTestingParams: {
    timeLimitGeneratingTests: 30
  }
};

const reportMaven = new ReportMaven('gradle');

//log de erro genérico
function logError(message: string, error: any) {
    loggerSync({ level: 'error', message: `${message}: ${error.message}` });
}

//log de info genérico
function logInfo(message: string) {
    loggerSync({ level: 'info', message });
}

// executa o processo de construção Gradle com a configuração fornecida
export const runForGradle = async (config: ConfigType) => {
  const { projectAbsolutePath, weightVulnerability, executions, projectType } = config;
  
  try {
    const { javaVersion, dependencies } = await GradleAdapter.getDeps(projectAbsolutePath);

    logInfo(`Required Java version: ${javaVersion}`);
    logInfo(`Dependencies: ${JSON.stringify(dependencies, null, 2)}`); //JSON.stringify converte o objeto dependencies em uma string JSON, "null" função opcional usada para modificar, 2 indentacao
    
    
    if (Number(javaVersion) < 8) {
      logError(`Java versions below 8 are not supported. Modify Docker image manually if needed.`, new Error('Unsupported Java Version'));
      return;
    }

    await JavaRunner.initJavaContainer(javaVersion, gradleProjectPath);
    const dependenciesNewerVersions = await getDependenciesNewerVersions(dependencies);
    loggerSync({ level: 'info', message: '\n\n\n========= DEPENDENCIES NEWER VERSIONS ==========\n' });
    loggerSync({ level: 'dir', object: dependenciesNewerVersions });

    const dependenciesVersionsRank = await getDependenciesVersionsRank(dependenciesNewerVersions, weightVulnerability);
    loggerSync({ level: 'info', message: '\n\n\n========= DEPENDENCIES VERSIONS RANK ==========\n' });
    loggerSync({ level: 'dir', object: dependenciesVersionsRank });
    
    const appliedDependencies = await updateDependenciesInGradle(dependenciesVersionsRank, gradleProjectPath, executions);

    await reportMaven.execute({ dependenciesVersionsRank, appliedDependencies, executions });
    console.log("Dealing with new build.gradle!!")
    await JavaRunner.deleteJavaContainer()
  } catch (error) {
    logError('Error configuring or building the project', error);
    throw error;
  }
};

const updateDependenciesInGradle = async (
  dependenciesVersionsRank: {
    dependency: Dependency;
    rank: VersionVulnerability[];
  }[],
  projectAbsolutePath: string,
  executions: ExecutionsType,
): Promise<{ dependency: Dependency; version: string; }[]> => {
  const appliedDependencies: { dependency: Dependency; version: string }[] = [];
  let newGradle = "";
  let oldGradle = await GradleAdapter.getGradle(projectAbsolutePath)
  for (const dependencyVersionsRank of dependenciesVersionsRank) {
    for (const possibleVersion of dependencyVersionsRank.rank) {
      const { dependency } = dependencyVersionsRank;
      const dependencyApplied = { dependency, version: possibleVersion.version };
      loggerSync({
        level: 'info',
        message: `Applying version ${possibleVersion.version} with vulnerability rate ${possibleVersion.detailsDependencyVulnerability.rate} of ${dependency.name} dependency in build.gradle`,
      });
      newGradle = newGradle == "" ? oldGradle : newGradle;
      if(newGradle != "") newGradle = await GradleAdapter.getBuildGradleReplacedDependencyVersion(newGradle, dependency, possibleVersion.version);
      await GradleAdapter.writeBuildGradleFile(newGradle);

      if (possibleVersion.version === dependency.version) {
        loggerSync({
          level: 'info',
          message: `Keeping the current version ${possibleVersion.version} of ${dependency.name}\n\n`,
        });
        appliedDependencies.push(dependencyApplied);
        break;
      }

      if (!executions.buildProject) {
        appliedDependencies.push(dependencyApplied);
        break;
      }

      try {
        loggerSync({
          level: 'info',
          message: `Running gradle build for version ${possibleVersion.version} of ${dependency.name} dependency`,
        });
        GradleRunner.runGradleBuild(projectAbsolutePath, false, { verbose: true });
        loggerSync({
          level: 'info',
          message: 'Gradle build executed successfully\n\n',
        });
        if (!executions.exploratoryTesting) {
          appliedDependencies.push(dependencyApplied);
          break;
        }
      } catch (error) {
        loggerSync({
          level: 'info',
          message: "Error on gradle build. Let's try a new version.\n",
          object: error,
        });
        continue;
      }

      if (executions.exploratoryTesting) {
        try {
          await RandoopRunner.runRandoopTests('maven', dependencyClasspath);
          loggerSync({
            level: 'info',
            message: 'Exploratory tests executed successfully\n\n',
          });
          appliedDependencies.push(dependencyApplied);
          break;
        } catch (error) {
          loggerSync({
            level: 'info',
            message: "Error on randoop testing. Let's try a new version.\n",
            object: error,
          });
          continue;
        }
      }
    }
  }
  return appliedDependencies;
};

const getDependenciesNewerVersions = async (dependencies: Dependency[]) => {
  const dependenciesNewerVersions: { dependency: Dependency; newerVersions: string[] }[] = await Promise.all(
    dependencies.map(async dependency => ({
      dependency,
      newerVersions: await getDependencyNewerVersionsService.execute(dependency),
    })),
  );
  
  return dependenciesNewerVersions;
};

const getDependenciesVersionsRank = async (
  dependenciesNewerVersions: {
    dependency: Dependency;
    newerVersions: string[];
  }[],
  weightVulnerability: WeightVulnerabilityType,
) => {
  const dependenciesVersionsRank: { dependency: Dependency; rank: VersionVulnerability[] }[] = await Promise.all(
    dependenciesNewerVersions.map(async dependencyNewerVersions => ({
      dependency: dependencyNewerVersions.dependency,
      rank: await getVersionsRank(dependencyNewerVersions.dependency, dependencyNewerVersions.newerVersions, weightVulnerability),
    })),
  );
  return dependenciesVersionsRank;
};
const getVersionsRank = async (dependency: Dependency, newerVersions: string[], weightVulnerability: WeightVulnerabilityType): Promise<VersionVulnerability[]> => {
  const versionsVulnerability: VersionVulnerability[] = await Promise.all(
    newerVersions.map(async version => ({
      version,
      detailsDependencyVulnerability: await calculateVulnerabilityRate(dependency, version, weightVulnerability),
    })),
  );

  const versionsRank = versionsVulnerability.sort((a, b) => {
    if (a.detailsDependencyVulnerability.rate !== b.detailsDependencyVulnerability.rate) {
      return a.detailsDependencyVulnerability.rate - b.detailsDependencyVulnerability.rate;
    }

    return SemanticVersioningHelper.compareVersions(a.version, b.version);
  });

  return versionsRank;
};

const calculateVulnerabilityRate = async (dependency: Dependency, version: string, weightVulnerability: WeightVulnerabilityType): Promise<{ details: DependencyVulnerability[]; rate: number }> => {
  const vulnerabilities = await getDependencyVulnerabilitiesService.execute({ dependency, version });
  const rate = vulnerabilities.reduce((rate, { severityScore, severity }) => rate + severityScore * weightVulnerability[severity], 0);
  return { details: vulnerabilities, rate };
};

/* async function main() {
  await runForGradle(config);
}

main().catch((error) => console.error(error)); */
