import fs from 'fs';
import path from 'path';

import { BuildTool } from '../../core/build-tool';
import { VersionPlan, planOverrides } from '../../core/candidates';
import { ResolveError } from '../../core/errors';
import { limiter } from '../../core/limit';
import { DirectDep, Gav, Override, StepResult, depKey } from '../../core/model';
import { UpdateUnit } from '../../core/units';
import { CONTAINER, ContainerExec, dockerExec, gradleFirstError, killedEarly, runHost, timedOut, withTimeout } from '../container';
import { GradleFiles, detectJavaVersion, findDeclarations, hasExplicitVersion, setDependencyVersions } from './gradle-edit';

/** Resolution/classpath calls (saferDeps, saferClasspath) are killed after this many seconds. */
export const RESOLVE_TIMEOUT_SEC = 600;
const DEFAULT_BUILD_TIMEOUT_SEC = 3600;
const DAEMON_STOP_TIMEOUT_SEC = 30;
/** Candidate versions resolved per saferDeps invocation by resolveTrees (each invocation costs Gradle's startup and configuration). */
export const BATCH_SIZE = 25;

/** Every Gradle call: the project's wrapper, the shared cache mounted at /tmp/.gradle and the Safer init script (mounted at /safer). */
export const GRADLE_PREFIX = [
  './gradlew',
  '--console=plain',
  '--no-configuration-cache',
  '-g',
  '/tmp/.gradle',
  '--project-cache-dir', // keeps .gradle/ out of the project
  '/tmp/.gradle/project-cache',
  '-Dorg.gradle.jvmargs=-Xmx768m',
  '--init-script',
  '/safer/safer.init.gradle',
];

/** Configuration → Maven-like scope; a dependency declared in several configurations takes the first scope in SCOPE_ORDER. */
const SCOPES: Record<string, string> = {
  implementation: 'compile',
  api: 'compile',
  runtimeOnly: 'runtime',
  developmentOnly: 'provided',
  compileOnly: 'provided',
  annotationProcessor: 'provided',
  testImplementation: 'test',
  testRuntimeOnly: 'test',
};
const SCOPE_ORDER = ['compile', 'runtime', 'provided', 'test'];

type FileKey = 'build' | 'properties' | 'catalog';
const FILE_KEYS: FileKey[] = ['build', 'properties', 'catalog'];
type Component = { group: string; name: string; version: string };
type BatchEntry = { tree?: Component[]; error?: string };
type SaferDeps = {
  direct: { group: string; name: string; version: string | null; configuration: string }[];
  runtime: Component[];
  compile: Component[];
  test: Component[];
  development: Component[]; // full runtimeClasspath on discovery calls when the shipped tree leaves developmentOnly out
  unresolved: Record<string, string[]>; // compile/test classpath failures (runtime ones fail the task)
  /** Only with -PsaferBatchFile: the unmodified copy (control) and one entry per plan. */
  batch?: { control: BatchEntry; versions: Record<string, BatchEntry> };
};

/** Parses saferDeps output; throws on invalid JSON or when `direct`/`runtime` are not arrays (compile/test/unresolved are optional). */
function parseSaferDeps(text: string): SaferDeps {
  const json = JSON.parse(text);
  if (!json || typeof json !== 'object' || !Array.isArray(json.direct) || !Array.isArray(json.runtime)) throw new Error('expected { direct: [], runtime: [] }');
  const list = (v: unknown) => (Array.isArray(v) ? (v as Component[]) : []);
  const batch = json.batch && typeof json.batch === 'object' && json.batch.control && json.batch.versions ? json.batch : undefined;
  return { direct: json.direct, runtime: json.runtime, compile: list(json.compile), test: list(json.test), development: list(json.development), unresolved: json.unresolved ?? {}, ...(batch && { batch }) };
}

const toGavs = (list: Component[]): Gav[] => list.map(({ group, name, version }) => ({ group, name, version }));
const sameTree = (a: Component[], b: Component[]) => {
  const key = (l: Component[]) => l.map(c => `${depKey(c)}:${c.version}`).sort().join('\n');
  return key(a) === key(b);
};

/** An empty tree, or one without the requested override, would be scored as clean: returns why it must be refused. */
function treeProblem(runtime: Component[], overrides: Override[] = []): string | undefined {
  if (runtime.length === 0) return 'gradle saferDeps returned an empty runtime tree';
  for (const o of overrides) {
    if (!runtime.some(g => depKey(g) === depKey(o.dep) && g.version === o.version)) {
      const found = runtime.find(g => depKey(g) === depKey(o.dep));
      return `resolved tree has ${depKey(o.dep)} ${found ? `at ${found.version}` : 'missing'} instead of ${o.version}`;
    }
  }
  return undefined;
}

export type GradleToolOptions = {
  projectPath: string;
  saferRoot: string;
  logDir: string; // container.log and discovery logs go here
  exec?: ContainerExec;
  startContainer?: boolean; // false in unit tests
  buildTimeoutSec?: number; // per `gradle clean build`, default 3600
  runHost?: typeof runHost; // host commands (container start/removal); injectable for tests
};

export class GradleTool implements BuildTool {
  readonly name = 'gradle' as const;
  private readonly exec: ContainerExec;
  private readonly host: typeof runHost;
  private accepted: GradleFiles | null = null;
  private seq = 0;
  private batchDisabled = false; // set when a batch's control copy does not match the shipped tree
  private javaVersion = 'unknown';
  private gradleVersion = 'unknown';
  // one Gradle invocation at a time: concurrent builds of one project would fight over build/ and the daemon
  private readonly slots = limiter(1);

  constructor(private readonly opts: GradleToolOptions) {
    this.exec = opts.exec ?? dockerExec();
    this.host = opts.runHost ?? runHost;
  }

  projectName(): string {
    return path.basename(this.opts.projectPath);
  }

  hasTests(): boolean {
    const walk = (dir: string): boolean =>
      fs.existsSync(dir) &&
      fs.readdirSync(dir, { withFileTypes: true }).some(e =>
        e.isDirectory() ? walk(path.join(dir, e.name)) : e.name.endsWith('.java') && fs.readFileSync(path.join(dir, e.name), 'utf8').includes('@Test'),
      );
    return walk(path.join(this.opts.projectPath, 'src', 'test', 'java'));
  }

  info(): Record<string, string> {
    return { java: this.javaVersion, gradle: this.gradleVersion };
  }

  classesDir(): string {
    return 'build/classes/java/main';
  }

  private filePath(key: FileKey): string {
    const rel = key === 'build' ? this.accepted!.buildFile : key === 'properties' ? 'gradle.properties' : 'gradle/libs.versions.toml';
    return path.join(this.opts.projectPath, rel);
  }

  private readFiles(): GradleFiles {
    const p = (f: string) => path.join(this.opts.projectPath, f);
    const buildFile = fs.existsSync(p('build.gradle')) ? 'build.gradle' : fs.existsSync(p('build.gradle.kts')) ? 'build.gradle.kts' : null;
    if (!buildFile) throw new Error(`no build.gradle or build.gradle.kts in ${this.opts.projectPath}`);
    const optional = (f: string) => (fs.existsSync(p(f)) ? fs.readFileSync(p(f), 'utf8') : undefined);
    const files: GradleFiles = { buildFile, build: fs.readFileSync(p(buildFile), 'utf8') };
    const properties = optional('gradle.properties');
    const catalog = optional('gradle/libs.versions.toml');
    if (properties !== undefined) files.properties = properties;
    if (catalog !== undefined) files.catalog = catalog;
    return files;
  }

  /** Writes one build file, only when its content on disk differs (reading a missing file throws). */
  private writeIfChanged(key: FileKey, text: string): void {
    const file = this.filePath(key);
    if (fs.readFileSync(file, 'utf8') !== text) fs.writeFileSync(file, text);
  }

  private writeFiles(target: GradleFiles): void {
    for (const key of FILE_KEYS) if (target[key] !== undefined) this.writeIfChanged(key, target[key]!);
  }

  async init(): Promise<void> {
    this.accepted = this.readFiles();
    const javaVersion = detectJavaVersion(this.accepted.build);
    this.javaVersion = javaVersion;
    const gradlew = path.join(this.opts.projectPath, 'gradlew');
    if (fs.existsSync(gradlew) && (fs.statSync(gradlew).mode & 0o111) === 0) fs.chmodSync(gradlew, fs.statSync(gradlew).mode | 0o755);
    if (this.opts.startContainer === false) return;
    const logFile = path.join(this.opts.logDir, 'container.log');
    const script = path.join(this.opts.saferRoot, 'src/runners/java/init-java-container.sh');
    const code = await this.host(`${script} ${javaVersion} ${this.opts.projectPath} ${this.opts.saferRoot} ${CONTAINER}`, {
      cwd: path.join(this.opts.saferRoot, 'src/runners/java'),
      logFile,
    });
    if (code !== 0) throw new Error(`Java ${javaVersion} container failed to start (see ${logFile})`);
    let ready = false;
    for (let i = 0; i < 60 && !ready; i++) {
      ready = (await this.exec(['true'])).code === 0;
      if (!ready) await new Promise(r => setTimeout(r, 1000));
    }
    if (!ready) throw new Error(`container ${CONTAINER} not ready after 60s (see ${logFile})`);
    this.gradleVersion = await this.detectGradleVersion();
  }

  /** `Gradle x.y` from `./gradlew --version` (also downloads the wrapper distribution on first use); 'unknown' when unreadable. */
  private async detectGradleVersion(): Promise<string> {
    try {
      const cmd = withTimeout(RESOLVE_TIMEOUT_SEC, ['./gradlew', '--version', '-g', '/tmp/.gradle']);
      const r = await this.exec(cmd.args, { timeoutMs: cmd.timeoutMs });
      const lines = r.stdout.split('\n').map(l => l.trim());
      return (r.code === 0 && (lines.find(l => /^Gradle \d/.test(l)) ?? lines.find(l => l.includes('Gradle')))) || 'unknown';
    } catch {
      return 'unknown';
    }
  }

  /**
   * One Gradle invocation in the container with the Safer flags; all output goes to logFile. `timeout -s KILL`
   * kills only the client, so after a timeout the daemon (which may still be running the build) is killed too.
   */
  private gradle(args: string[], logFile: string, sec: number) {
    const cmd = withTimeout(sec, [...GRADLE_PREFIX, ...args]);
    return this.slots(async () => {
      const r = await this.exec(cmd.args, { logFile, timeoutMs: cmd.timeoutMs });
      if (timedOut(r.code, r.durationMs, sec)) await this.stopDaemon();
      return r;
    });
  }

  /** Best effort: a failure here must not hide the timeout being reported. */
  private async stopDaemon(): Promise<void> {
    try {
      const stop = withTimeout(DAEMON_STOP_TIMEOUT_SEC, ['pkill', '-KILL', '-f', 'GradleDaemon']);
      const r = await this.exec(stop.args, { timeoutMs: stop.timeoutMs });
      if (r.code === 127) {
        // no pkill in the image: ask Gradle to stop its daemons
        const gentle = withTimeout(DAEMON_STOP_TIMEOUT_SEC, ['./gradlew', '--stop', '-g', '/tmp/.gradle']);
        await this.exec(gentle.args, { timeoutMs: gentle.timeoutMs });
      }
    } catch {
      // ignored
    }
  }

  /**
   * Runs an init-script task writing to build/safer/<base>-<n>.<ext>, parsed once by `parse`; a parse error or a
   * `check` rejection is a ResolveError that keeps the log.
   */
  private async taskToFile<T>(task: string, base: string, ext: string, extra: string[], parse: (text: string) => T, check?: (value: T) => string | undefined): Promise<T> {
    const n = ++this.seq;
    const out = `build/safer/${base}-${n}.${ext}`;
    const outPath = path.join(this.opts.projectPath, out);
    const logFile = path.join(this.opts.logDir, `gradle-${base}-${process.pid}-${n}.log`);
    try {
      const r = await this.gradle([task, `-PsaferOut=${out}`, ...extra], logFile, RESOLVE_TIMEOUT_SEC);
      if (timedOut(r.code, r.durationMs, RESOLVE_TIMEOUT_SEC)) throw new ResolveError(`gradle ${task} timeout after ${RESOLVE_TIMEOUT_SEC}s`, logFile);
      if (r.code !== 0 || !fs.existsSync(outPath)) {
        const log = fs.existsSync(logFile) ? fs.readFileSync(logFile, 'utf8') : '';
        throw new ResolveError(`gradle ${task} failed: ${gradleFirstError(log) ?? killedEarly(r.code) ?? `exit ${r.code}`}`, logFile);
      }
      let value: T;
      try {
        value = parse(fs.readFileSync(outPath, 'utf8'));
      } catch (err) {
        throw new ResolveError(`gradle ${task} returned malformed output: ${err instanceof Error ? err.message : String(err)}`, logFile);
      }
      const problem = check?.(value);
      if (problem) throw new ResolveError(problem, logFile);
      fs.rmSync(logFile, { force: true }); // keep logs only for failures
      return value;
    } finally {
      fs.rmSync(outPath, { force: true });
    }
  }

  private saferDeps(extra: string[] = [], check?: (deps: SaferDeps) => string | undefined): Promise<SaferDeps> {
    return this.taskToFile('saferDeps', 'deps', 'json', extra, parseSaferDeps, check);
  }

  /** Compile/test classpath entries that did not resolve are not an error; their counts go to gradle-discovery.log (never the console). */
  private logUnresolved(unresolved: Record<string, string[]>): void {
    const lines = Object.entries(unresolved)
      .filter(([, list]) => Array.isArray(list) && list.length > 0)
      .map(([configuration, list]) => `unresolved ${configuration}: ${list.length}`);
    if (lines.length) this.discoveryLog(lines.join('\n'));
  }

  private discoveryLog(text: string): void {
    try {
      fs.mkdirSync(this.opts.logDir, { recursive: true });
      fs.appendFileSync(path.join(this.opts.logDir, 'gradle-discovery.log'), `${text}\n`);
    } catch {
      // diagnostics only
    }
  }

  async listDirectDeps(): Promise<DirectDep[]> {
    const json = await this.saferDeps();
    this.logUnresolved(json.unresolved);
    const files = this.accepted!;
    const merged = new Map<string, { group: string; name: string; version: string | null; scope: string }>();
    for (const d of json.direct) {
      const scope = SCOPES[d.configuration] ?? 'compile';
      const prev = merged.get(depKey(d));
      if (!prev) merged.set(depKey(d), { group: d.group, name: d.name, version: d.version, scope });
      else {
        if (SCOPE_ORDER.indexOf(scope) < SCOPE_ORDER.indexOf(prev.scope)) prev.scope = scope;
        prev.version ??= d.version;
      }
    }
    const resolved = (key: string) => [json.runtime, json.compile, json.test, json.development].map(list => list.find(c => depKey(c) === key)?.version).find(v => v);
    const versionProperties = new Map<string, string>();
    for (const decl of findDeclarations(files)) {
      const key = depKey(decl);
      if (versionProperties.has(key)) continue;
      if (decl.versionSource === 'property') versionProperties.set(key, decl.property!);
      else if (decl.versionSource === 'catalog-ref') versionProperties.set(key, `catalog:${decl.property}`);
    }
    const toDep = (key: string, explicitVersion: boolean): DirectDep => {
      const m = merged.get(key)!;
      const versionProperty = versionProperties.get(key);
      return { group: m.group, name: m.name, version: m.version ?? resolved(key) ?? '', explicitVersion, scope: m.scope, ...(versionProperty !== undefined && { versionProperty }) };
    };
    const deps: DirectDep[] = [];
    const seen = new Set<string>();
    for (const decl of findDeclarations(files)) {
      const key = depKey(decl);
      if (seen.has(key) || !merged.has(key)) continue; // e.g. a configuration the init script does not report
      seen.add(key);
      deps.push(toDep(key, hasExplicitVersion(files, decl)));
    }
    for (const key of merged.keys()) if (!seen.has(key)) deps.push(toDep(key, false)); // added by plugins, not the build file
    return deps;
  }

  async resolveTree(overrides?: Override[]): Promise<Gav[]> {
    const extra = overrides?.length ? [`-PsaferOverride=${overrides.map(o => `${o.dep.group}:${o.dep.name}:${o.version}`).join(',')}`] : [];
    const check = ({ runtime }: SaferDeps) => treeProblem(runtime, overrides);
    return toGavs((await this.saferDeps(extra, check)).runtime);
  }

  /**
   * Resolves the shipped tree for many plans of one unit, BATCH_SIZE per Gradle invocation
   * (-PsaferBatchFile). Each batch also resolves an unmodified copy; if that control differs from the shipped tree,
   * batching is not trustworthy for this build, so this and every later call fall back to resolveTree per version.
   * Per-version failures are returned as errors, never thrown.
   */
  async resolveTrees(unit: UpdateUnit, plans: VersionPlan[]): Promise<Map<string, Gav[] | Error>> {
    const out = new Map<string, Gav[] | Error>();
    const one = async (plan: VersionPlan) => {
      try {
        out.set(plan.version, await this.resolveTree(planOverrides(unit, plan)));
      } catch (err) {
        out.set(plan.version, err instanceof Error ? err : new Error(String(err)));
      }
    };
    for (let i = 0; i < plans.length; i += BATCH_SIZE) {
      const chunk = plans.slice(i, i + BATCH_SIZE);
      if (this.batchDisabled) {
        for (const p of chunk) await one(p);
        continue;
      }
      let json: SaferDeps;
      try {
        const file = `build/safer/batch-${++this.seq}.json`;
        fs.mkdirSync(path.join(this.opts.projectPath, 'build/safer'), { recursive: true });
        fs.writeFileSync(path.join(this.opts.projectPath, file), JSON.stringify(Object.fromEntries(chunk.map(p => [p.version, p.versions]))));
        json = await this.saferDeps([`-PsaferBatchFile=${file}`]);
      } catch (err) {
        for (const p of chunk) out.set(p.version, err instanceof Error ? err : new Error(String(err)));
        continue;
      }
      const control = json.batch?.control;
      const mismatch = !json.batch
        ? 'no batch output'
        : control?.error ?? (sameTree(control?.tree ?? [], json.runtime) ? undefined : 'control copy differs from the shipped tree');
      if (mismatch) {
        this.batchDisabled = true;
        this.discoveryLog(`batch resolution disabled (${mismatch}); resolving one version per Gradle call`);
        for (const p of chunk) await one(p);
        continue;
      }
      for (const p of chunk) {
        const entry = json.batch!.versions[p.version];
        const problem = !entry ? 'missing from batch output' : entry.error ? `gradle saferDeps failed: ${entry.error}` : treeProblem(entry.tree ?? [], planOverrides(unit, p));
        out.set(p.version, problem ? new ResolveError(problem) : toGavs(entry!.tree!));
      }
    }
    return out;
  }

  async apply(overrides: Override[]) {
    const r = setDependencyVersions(this.accepted!, overrides);
    this.writeFiles(r.files); // starts from the accepted texts, so an earlier un-restored apply is undone too
    return r.applied;
  }

  async restore(): Promise<void> {
    this.writeFiles(this.accepted!);
  }

  async accept(): Promise<void> {
    this.accepted = this.readFiles();
  }

  async build({ tests, logFile }: { tests: boolean; logFile: string }): Promise<StepResult> {
    fs.mkdirSync(path.dirname(logFile), { recursive: true });
    // like Maven's -Dmaven.test.skip: without tests, the test sources are not compiled either
    const skip = tests ? [] : ['-x', 'test', '-x', 'compileTestJava'];
    const sec = this.opts.buildTimeoutSec ?? DEFAULT_BUILD_TIMEOUT_SEC;
    const r = await this.gradle(['clean', 'build', ...skip], logFile, sec);
    const ok = r.code === 0;
    if (!ok && timedOut(r.code, r.durationMs, sec)) return { ok, logFile, durationMs: r.durationMs, firstError: `timeout after ${sec}s` };
    const log = fs.existsSync(logFile) ? fs.readFileSync(logFile, 'utf8') : '';
    return { ok, logFile, durationMs: r.durationMs, firstError: ok ? undefined : gradleFirstError(log) ?? killedEarly(r.code) ?? `gradle exit ${r.code}` };
  }

  async classpath(): Promise<string> {
    return this.taskToFile('saferClasspath', 'classpath', 'txt', [], text => text.trim());
  }

  async packagedArtifact(): Promise<string | null> {
    const libs = path.join(this.opts.projectPath, 'build', 'libs');
    if (!fs.existsSync(libs)) return null;
    const jars = fs
      .readdirSync(libs)
      .filter(f => /\.(jar|war)$/.test(f) && !/-(plain|sources|javadoc)\.(jar|war)$/.test(f))
      .map(f => path.join(libs, f))
      .sort((a, b) => fs.statSync(b).mtimeMs - fs.statSync(a).mtimeMs);
    return jars[0] ?? null;
  }

  /** Each cleanup step runs even if an earlier one fails; the first error is rethrown at the end. */
  async dispose(): Promise<void> {
    const errors: unknown[] = [];
    const step = async (fn: () => unknown) => {
      try {
        await fn();
      } catch (err) {
        errors.push(err);
      }
    };
    for (const key of FILE_KEYS) {
      const text = this.accepted?.[key];
      if (text !== undefined) await step(() => this.writeIfChanged(key, text));
    }
    await step(() => fs.rmSync(path.join(this.opts.projectPath, 'build', 'safer'), { recursive: true, force: true }));
    if (this.opts.startContainer !== false) {
      await step(() => this.host(`docker rm -f ${CONTAINER}`, { cwd: this.opts.projectPath, logFile: path.join(this.opts.logDir, 'container.log') }));
    }
    if (errors.length) throw errors[0];
  }
}
