#!/bin/bash

PROJECT_PATH=$1
PROJECT_TESTS=$2
VERBOSE=$3  # flag para log detalhado

cd "$PROJECT_PATH" || exit 1  # acessa o diretório do projeto ou sai com erro

# executa o build com ou sem logs detalhados, omitindo testes
if [ "$VERBOSE" = "true" ]; then
    ./gradlew clean check -b build.gradle -x compileTestJava checkstyleMain
else
    ./gradlew clean check -b build.gradle -x compileTestJava checkstyleMain > /dev/null
fi
