import * as fs from 'fs';
import * as path from 'path';
import { parseStringPromise } from 'xml2js';

interface DependencyInfo {
  groupId: string;
  artifactId: string;
  version: string;
}

/**
 * Reads POM file, extracts dependency versions,
 * and returns a map of "groupId:artifactId" -> version.
 */
async function extractPomVersions(pomFilePath: string): Promise<Map<string, string>> {
  console.log("Reading POM at:", path.resolve(pomFilePath));
  const xmlContent = await fs.readFileSync(pomFilePath, 'utf-8');
  const parsed = await parseStringPromise(xmlContent);
  
  // Navigate to: project -> dependencies -> dependency
  const dependencies = parsed?.project?.dependencies?.[0]?.dependency || [];

  const versionMap = new Map<string, string>();

  dependencies.forEach((dep: any) => {
    const groupId = dep?.groupId?.[0];
    const artifactId = dep?.artifactId?.[0];
    const version = dep?.version?.[0];
    if (groupId && artifactId && version) {
      // Key will look like "groupId:artifactId"
      const key = `${groupId}:${artifactId}`;
      versionMap.set(key, version);
    }
  });

  return versionMap;
}

/**
 * Update or insert versions into build.gradle lines.
 * 
 * This example:
 * - Looks for lines like:  implementation 'groupId:artifactId:oldVersion'
 * - Replaces oldVersion with the version from the POM if present
 */
function updateGradleDependencies(
  gradleLines: string[],
  pomVersionMap: Map<string, string>
): string[] {
  return gradleLines.map((line) => {
    // A naive regex that captures "groupId:artifactId:version"
    // in lines like: implementation 'groupId:artifactId:1.2.3'
    const gradleDepRegex = /\b(implementation|compile|compileOnly|runtimeOnly)\b\s*['"]([^:'"]+):([^:'"]+)(?::([^:'"]+))?['"]/;
    
    const match = line.match(gradleDepRegex);
    if (match) {
      const [_, gradleScope, groupId, artifactId, oldVersion] = match;
      const key = `${groupId}:${artifactId}`;
      const newVersion = pomVersionMap.get(key);
      if (newVersion && oldVersion && newVersion !== oldVersion) {
        // Replace the line’s version with the POM version
        // e.g., from "implementation 'g:a:1.2.3'" to "implementation 'g:a:4.1.4'"
        return line.replace(`${groupId}:${artifactId}:${oldVersion}`, `${groupId}:${artifactId}:${newVersion}`);
      } 
      else if (newVersion && !oldVersion) {
        // If old version was not declared in the Gradle line
        // but the POM has one, we can append it
        return line.replace(
          `${groupId}:${artifactId}`,
          `${groupId}:${artifactId}:${newVersion}`
        );
      }
    }
    return line; // if no match, leave the line unchanged
  });
}

export async function updateDependencyVersions(POM_PATH: string, GRADLE_PATH: string) {
  try {
    // 1. Read POM and build.gradle
    console.log("Reading build.gradle at:", path.resolve(GRADLE_PATH))
    const [versionMap, gradleFileContent] = await Promise.all([
      extractPomVersions(POM_PATH),
      fs.readFileSync(GRADLE_PATH, 'utf-8'),
    ]);

    // 2. Process build.gradle lines
    const gradleLines = gradleFileContent.split('\n');
    const updatedLines = updateGradleDependencies(gradleLines, versionMap);

    // 3. Write back to build.gradle (or a new file if you want to keep original intact)
    await fs.writeFileSync(GRADLE_PATH, updatedLines.join('\n'), 'utf-8');

    console.log('build.gradle has been updated with versions from pom.xml!');
  } catch (error) {
    console.error('Error while updating build.gradle:', error);
  }
}
