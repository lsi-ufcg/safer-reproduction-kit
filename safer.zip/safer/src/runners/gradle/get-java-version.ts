import { executeGradleCommand } from './utils';

export async function getJavaVersion(gradleProjectPath: string): Promise<string> {
    const gradleCommand = `./gradlew properties | grep "sourceCompatibility" | awk '{print $2}'`;

    try {
        return await executeGradleCommand(gradleCommand, gradleProjectPath);
    } catch (error) {
        console.error("Error fetching Java version:", error);
        throw error;
    }
}
