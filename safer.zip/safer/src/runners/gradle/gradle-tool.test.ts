import fs from 'fs';
import os from 'os';
import path from 'path';

import { beforeEach, describe, expect, it } from 'vitest';

import { ResolveError } from '../../core/errors';
import { singleUnit } from '../../core/units';
import { CONTAINER, ContainerExec } from '../container';
import { BATCH_SIZE, GRADLE_PREFIX, GradleTool, RESOLVE_TIMEOUT_SEC } from './gradle-tool';

const BUILD = `plugins { id 'java' }
sourceCompatibility = '17'
dependencies {
    implementation "g:a:\${aVersion}"
    testImplementation 'g:t:1.0'
    implementation 'g:m'
    runtimeOnly 'g:t:1.0'
    compileOnly 'g:p:2.0'
    annotationProcessor 'g:p:2.0'
    implementation libs.c
}
`;
const PROPS = 'aVersion=1.0\n';
const CATALOG = '[versions]\nc = "3.0"\n\n[libraries]\nc = { module = "g:c", version.ref = "c" }\n';

let dir: string;
let calls: string[][];
let ignoreCOverride: boolean; // makes the fake ignore a -PsaferOverride of g:c
let controlDiffers: boolean; // makes the fake batch's control copy differ from the shipped tree

const read = (f: string) => fs.readFileSync(path.join(dir, f), 'utf8');
const plansOf = (versions: string[]) => versions.map(v => ({ version: v, versions: { 'g:a': v } }));
const prop = (args: string[], name: string) => args.find(a => a.startsWith(`-P${name}=`))?.split('=')[1];
const FAIL_LOG = "FAILURE: Build failed with an exception.\n\n* What went wrong:\nExecution failed for task ':compileJava'.\n> Compilation failed; see the compiler error output for details.\n";

/** Plays the init script: writes what saferDeps/saferClasspath would, from the build files on disk. */
const fakeExec = (): ContainerExec => async (args, opts) => {
  calls.push(args);
  const out = prop(args, 'saferOut');
  if (out) {
    const file = path.join(dir, out);
    fs.mkdirSync(path.dirname(file), { recursive: true });
    if (args.includes('saferClasspath')) fs.writeFileSync(file, '/app/build/classes/java/main:/app/build/resources/main:/tmp/.gradle/caches/a-1.0.jar');
    else {
      const overrides = prop(args, 'saferOverride')?.split(',').map(e => e.split(':'));
      const a = overrides?.find(o => o[1] === 'a')?.[2] ?? read('gradle.properties').match(/aVersion=(.*)/)![1];
      const cOverride = overrides?.find(o => o[1] === 'c')?.[2];
      const gav = (group: string, name: string, version: string | null, configuration?: string) => ({ group, name, version, ...(configuration && { configuration }) });
      const runtimeOf = (v: string) => [gav('g', 'a', v), gav('g', 'dep-of-a', v), gav('g', 'm', '5.0'), gav('g', 'c', cOverride && !ignoreCOverride ? cOverride : '3.0'), gav('g', 't', '1.0'), gav('g', 'plug', '0.1')];
      const shipped = (v: string) => runtimeOf(v).filter(g => g.name !== 'plug'); // plug is developmentOnly
      const batchFile = prop(args, 'saferBatchFile');
      const batch = batchFile ? (JSON.parse(fs.readFileSync(path.join(dir, batchFile), 'utf8')) as Record<string, Record<string, string>>) : undefined;
      fs.writeFileSync(
        file,
        JSON.stringify({
          direct: [
            gav('g', 'a', read('gradle.properties').match(/aVersion=(.*)/)![1], 'implementation'),
            gav('g', 'm', null, 'implementation'),
            gav('g', 'c', '3.0', 'implementation'),
            gav('g', 't', '1.0', 'runtimeOnly'),
            gav('g', 'p', '2.0', 'compileOnly'),
            gav('g', 'p', '2.0', 'annotationProcessor'),
            gav('g', 'plug', null, 'developmentOnly'),
            gav('g', 't', '1.0', 'testImplementation'),
          ],
          runtime: shipped(a),
          development: runtimeOf(a),
          compile: [gav('g', 'a', a), gav('g', 'm', '5.0'), gav('g', 'c', '3.0'), gav('g', 'p', '2.0')],
          test: [gav('g', 'a', a), gav('g', 't', '1.0')],
          ...(batch && {
            batch: {
              control: { tree: controlDiffers ? shipped('0.0') : shipped(a) },
              versions: Object.fromEntries(
                Object.entries(batch).map(([k, pins]) => {
                  const v = pins['g:a'];
                  return [k, v === '99.0' ? { error: 'Unresolved productionRuntimeClasspath dependencies (1): g:a:99.0 (Could not find g:a:99.0.)' } : v === '7.7' ? { tree: shipped('7.6') } : { tree: shipped(v) }];
                }),
              ),
            },
          }),
        }),
      );
    }
  }
  const failed = args.includes('build') && read('gradle.properties').includes('aVersion=9.9');
  if (opts?.logFile) fs.writeFileSync(opts.logFile, failed ? FAIL_LOG : 'BUILD SUCCESSFUL in 1s\n');
  return { code: failed ? 1 : 0, stdout: '', durationMs: 1 };
};

beforeEach(() => {
  dir = fs.mkdtempSync(path.join(os.tmpdir(), 'safer-gradle-'));
  fs.writeFileSync(path.join(dir, 'build.gradle'), BUILD);
  fs.writeFileSync(path.join(dir, 'gradle.properties'), PROPS);
  fs.mkdirSync(path.join(dir, 'gradle'));
  fs.writeFileSync(path.join(dir, 'gradle/libs.versions.toml'), CATALOG);
  calls = [];
  controlDiffers = false;
  ignoreCOverride = false;
});

const tool = (extra: Partial<ConstructorParameters<typeof GradleTool>[0]> = {}) =>
  new GradleTool({ projectPath: dir, saferRoot: '/x', logDir: dir, exec: fakeExec(), startContainer: false, ...extra });

describe('GradleTool', () => {
  it('lists direct deps in build-file order, merging configurations by scope precedence', async () => {
    const t = tool();
    await t.init();
    expect(await t.listDirectDeps()).toEqual([
      { group: 'g', name: 'a', version: '1.0', explicitVersion: true, scope: 'compile', versionProperty: 'aVersion' },
      { group: 'g', name: 't', version: '1.0', explicitVersion: true, scope: 'runtime' },
      { group: 'g', name: 'm', version: '5.0', explicitVersion: false, scope: 'compile' },
      { group: 'g', name: 'p', version: '2.0', explicitVersion: true, scope: 'provided' },
      { group: 'g', name: 'c', version: '3.0', explicitVersion: true, scope: 'compile', versionProperty: 'catalog:c' },
      { group: 'g', name: 'plug', version: '0.1', explicitVersion: false, scope: 'provided' },
    ]);
    const deps = calls.at(-1)!;
    expect(deps).toContain('saferDeps');
    expect(prop(deps, 'saferOut')).toMatch(/^build\/safer\/deps-\d+\.json$/);
    expect(fs.readdirSync(path.join(dir, 'build/safer'))).toEqual([]); // output consumed
  });

  it('runs every Gradle call through the wrapper with the Safer flags and init script', async () => {
    const t = tool();
    await t.init();
    await t.resolveTree();
    expect(calls.at(-1)!.slice(0, 14)).toEqual([
      'timeout', '-s', 'KILL', String(RESOLVE_TIMEOUT_SEC),
      './gradlew', '--console=plain', '--no-configuration-cache', '-g', '/tmp/.gradle', '--project-cache-dir', '/tmp/.gradle/project-cache', '-Dorg.gradle.jvmargs=-Xmx768m', '--init-script', '/safer/safer.init.gradle',
    ]);
    expect(calls.at(-1)!.slice(0, 14)).toContain('--project-cache-dir');
    expect(GRADLE_PREFIX[0]).toBe('./gradlew');
  });

  it('resolves an override with -PsaferOverride and leaves the build files untouched', async () => {
    const t = tool();
    await t.init();
    const [a] = await t.listDirectDeps();
    const tree = await t.resolveTree([{ dep: a, version: '2.0' }]);
    expect(calls.at(-1)).toContain('-PsaferOverride=g:a:2.0');
    expect(tree).toContainEqual({ group: 'g', name: 'dep-of-a', version: '2.0' });
    expect(tree).not.toContainEqual(expect.objectContaining({ name: 'p' })); // runtime only
    expect([read('build.gradle'), read('gradle.properties'), read('gradle/libs.versions.toml')]).toEqual([BUILD, PROPS, CATALOG]);
    const baseline = await t.resolveTree();
    expect(calls.at(-1)!.some(x => x.startsWith('-PsaferOverride'))).toBe(false);
    expect(baseline).toContainEqual({ group: 'g', name: 'a', version: '1.0' });
  });

  it('refuses an empty tree, a missing override and a wrong version, keeping the log', async () => {
    let runtime: object[] = [];
    const exec: ContainerExec = async (args, opts) => {
      const file = path.join(dir, prop(args, 'saferOut')!);
      fs.mkdirSync(path.dirname(file), { recursive: true });
      fs.writeFileSync(file, JSON.stringify({ direct: [], runtime, compile: [], test: [] }));
      if (opts?.logFile) fs.writeFileSync(opts.logFile, 'BUILD SUCCESSFUL\n');
      return { code: 0, stdout: '', durationMs: 1 };
    };
    const t = tool({ exec });
    await t.init();
    const a = { group: 'g', name: 'a', version: '1.0', explicitVersion: true, scope: 'compile' };
    const empty = await t.resolveTree().catch(e => e);
    expect(empty).toBeInstanceOf(ResolveError);
    expect(empty.message).toBe('gradle saferDeps returned an empty runtime tree');
    expect(fs.existsSync(empty.logFile)).toBe(true);
    runtime = [{ group: 'g', name: 'a', version: '1.0' }];
    await expect(t.resolveTree([{ dep: a, version: '2.0' }])).rejects.toThrow('resolved tree has g:a at 1.0 instead of 2.0');
    runtime = [{ group: 'g', name: 'b', version: '1.0' }];
    await expect(t.resolveTree([{ dep: a, version: '2.0' }])).rejects.toThrow('resolved tree has g:a missing instead of 2.0');
    runtime = [{ group: 'g', name: 'a', version: '2.0' }];
    expect(await t.resolveTree([{ dep: a, version: '2.0' }])).toEqual([{ group: 'g', name: 'a', version: '2.0' }]);
  });

  it('a failed or timed-out resolution is a ResolveError carrying the log', async () => {
    const exec = (code: number, durationMs: number, log: string): ContainerExec => async (_args, opts) => {
      if (opts?.logFile) fs.writeFileSync(opts.logFile, log);
      return { code, stdout: '', durationMs };
    };
    const slow = tool({ exec: exec(137, RESOLVE_TIMEOUT_SEC * 1000, 'Downloading\n') });
    await slow.init();
    const err = await slow.resolveTree().catch(e => e);
    expect(err).toBeInstanceOf(ResolveError);
    expect(err.message).toBe(`gradle saferDeps timeout after ${RESOLVE_TIMEOUT_SEC}s`);
    expect(fs.existsSync(err.logFile)).toBe(true);
    const broken = tool({ exec: exec(1, 1000, "* What went wrong:\nExecution failed for task ':saferDeps'.\n   > Could not find g:a:9.9.\n") });
    await broken.init();
    await expect(broken.resolveTree()).rejects.toThrow("gradle saferDeps failed: Execution failed for task ':saferDeps'. > Could not find g:a:9.9.");
  });

  it('an unresolved runtime dependency fails saferDeps and becomes a ResolveError with the log', async () => {
    // the message format safer.init.gradle throws (GradleException) as Gradle prints it
    const log = [
      '> Task :saferDeps FAILED',
      '',
      'FAILURE: Build failed with an exception.',
      '',
      '* What went wrong:',
      "Execution failed for task ':saferDeps'.",
      '> Unresolved runtimeClasspath dependencies (1): io.minio:minio:99.0 (Could not find io.minio:minio:99.0.)',
      '',
      '* Try:',
    ].join('\n');
    const exec: ContainerExec = async (args, opts) => {
      calls.push(args);
      if (opts?.logFile) fs.writeFileSync(opts.logFile, log);
      return { code: 1, stdout: '', durationMs: 1000 };
    };
    const t = tool({ exec });
    await t.init();
    const minio = { group: 'io.minio', name: 'minio', version: '8.3.9', explicitVersion: true, scope: 'compile' };
    const err = await t.resolveTree([{ dep: minio, version: '99.0' }]).catch(e => e);
    expect(err).toBeInstanceOf(ResolveError);
    expect(err.message).toBe("gradle saferDeps failed: Execution failed for task ':saferDeps'. > Unresolved runtimeClasspath dependencies (1): io.minio:minio:99.0 (Could not find io.minio:minio:99.0.)");
    expect(fs.readFileSync(err.logFile, 'utf8')).toBe(log);
    expect(calls.some(c => c.includes('pkill'))).toBe(false); // not a timeout: the daemon is left alone
  });

  it('malformed or wrongly shaped saferDeps output is a ResolveError that keeps the log', async () => {
    let output = '';
    const exec: ContainerExec = async (args, opts) => {
      const file = path.join(dir, prop(args, 'saferOut')!);
      fs.mkdirSync(path.dirname(file), { recursive: true });
      fs.writeFileSync(file, output);
      if (opts?.logFile) fs.writeFileSync(opts.logFile, 'BUILD SUCCESSFUL\n');
      return { code: 0, stdout: '', durationMs: 1 };
    };
    const t = tool({ exec });
    await t.init();
    for (output of ['not json', '{"direct":[]}', '{"direct":{},"runtime":[]}', 'null']) {
      const err = await t.resolveTree().catch(e => e);
      expect(err).toBeInstanceOf(ResolveError);
      expect(err.message).toMatch(/^gradle saferDeps returned malformed output/);
      expect(fs.existsSync(err.logFile)).toBe(true);
    }
    output = '{"direct":[],"runtime":[{"group":"g","name":"a","version":"1.0"}]}'; // compile/test optional
    expect(await t.resolveTree()).toEqual([{ group: 'g', name: 'a', version: '1.0' }]);
    expect(await t.listDirectDeps()).toEqual([]);
  });

  it('stops the Gradle daemon after a timed-out resolution or build, ignoring failures to do so', async () => {
    const STOP = ['timeout', '-s', 'KILL', '30', 'pkill', '-KILL', '-f', 'GradleDaemon'];
    const exec: ContainerExec = async (args, opts) => {
      calls.push(args);
      if (args.includes('pkill')) throw new Error('docker exec failed');
      if (opts?.logFile) fs.writeFileSync(opts.logFile, '> Task :compileJava\n');
      return { code: 137, stdout: '', durationMs: 10_000 };
    };
    const t = tool({ exec, buildTimeoutSec: 10 });
    await t.init();
    expect(await t.build({ tests: true, logFile: path.join(dir, 'b.log') })).toMatchObject({ ok: false, firstError: 'timeout after 10s' });
    expect(calls.at(-1)).toEqual(STOP);
    calls.length = 0;
    const slow: ContainerExec = async (args, opts) => {
      calls.push(args);
      if (opts?.logFile) fs.writeFileSync(opts.logFile, 'Downloading\n');
      return { code: 137, stdout: '', durationMs: RESOLVE_TIMEOUT_SEC * 1000 };
    };
    const r = tool({ exec: slow });
    await r.init();
    await expect(r.resolveTree()).rejects.toThrow(`gradle saferDeps timeout after ${RESOLVE_TIMEOUT_SEC}s`);
    expect(calls.map(c => c[4])).toEqual(['./gradlew', 'pkill']);
    calls.length = 0;
    const early: ContainerExec = async (args, opts) => {
      calls.push(args);
      if (opts?.logFile) fs.writeFileSync(opts.logFile, '');
      return { code: 137, stdout: '', durationMs: 1_000 };
    };
    await tool({ exec: early, buildTimeoutSec: 10 }).build({ tests: true, logFile: path.join(dir, 'b.log') });
    expect(calls.some(c => c.includes('pkill'))).toBe(false); // an early kill (OOM) is not a timeout
  });

  it('reports an OOM-killed test worker in a failed build as killed (likely out of memory)', async () => {
    const exec: ContainerExec = async (_a, opts) => {
      if (opts?.logFile) fs.writeFileSync(opts.logFile, "* What went wrong:\nExecution failed for task ':test'.\n> Process 'Gradle Test Executor 2' finished with non-zero exit value 137\n");
      return { code: 1, stdout: '', durationMs: 1000 };
    };
    const t = tool({ exec });
    await t.init();
    const r = await t.build({ tests: true, logFile: path.join(dir, 'b.log') });
    expect(r.firstError).toMatch(/^killed \(likely out of memory\): /);
  });

  it('falls back to ./gradlew --stop when pkill is missing (exit 127)', async () => {
    const exec: ContainerExec = async (args, opts) => {
      calls.push(args);
      if (args.includes('pkill')) return { code: 127, stdout: '', durationMs: 1 };
      if (opts?.logFile) fs.writeFileSync(opts.logFile, '> Task :compileJava\n');
      return { code: 137, stdout: '', durationMs: 10_000 };
    };
    const t = tool({ exec, buildTimeoutSec: 10 });
    await t.init();
    await t.build({ tests: true, logFile: path.join(dir, 'b.log') });
    expect(calls.at(-2)![4]).toBe('pkill');
    expect(calls.at(-1)).toEqual(['timeout', '-s', 'KILL', '30', './gradlew', '--stop', '-g', '/tmp/.gradle']);
  });

  it('writes unresolved compile/test counts to gradle-discovery.log, nothing else', async () => {
    const exec: ContainerExec = async (args, opts) => {
      const file = path.join(dir, prop(args, 'saferOut')!);
      fs.mkdirSync(path.dirname(file), { recursive: true });
      fs.writeFileSync(file, JSON.stringify({ direct: [], runtime: [], unresolved: { compile: ['g:x:1', 'g:y:2'], test: ['g:z:3'], empty: [] } }));
      if (opts?.logFile) fs.writeFileSync(opts.logFile, '');
      return { code: 0, stdout: '', durationMs: 1 };
    };
    const t = tool({ exec });
    await t.init();
    await t.listDirectDeps();
    expect(fs.readFileSync(path.join(dir, 'gradle-discovery.log'), 'utf8')).toBe('unresolved compile: 2\nunresolved test: 1\n');
    const clean = tool();
    fs.rmSync(path.join(dir, 'gradle-discovery.log'));
    await clean.init();
    await clean.listDirectDeps();
    expect(fs.existsSync(path.join(dir, 'gradle-discovery.log'))).toBe(false);
  });

  it('resolves several overrides with one -PsaferOverride list and requires each in the tree', async () => {
    const t = tool();
    await t.init();
    const deps = await t.listDirectDeps();
    const a = deps.find(d => d.name === 'a')!;
    const c = deps.find(d => d.name === 'c')!;
    const tree = await t.resolveTree([{ dep: a, version: '2.0' }, { dep: c, version: '4.0' }]);
    expect(calls.at(-1)).toContain('-PsaferOverride=g:a:2.0,g:c:4.0');
    expect(tree).toContainEqual({ group: 'g', name: 'c', version: '4.0' });
    ignoreCOverride = true;
    const err = await t.resolveTree([{ dep: a, version: '2.0' }, { dep: c, version: '4.0' }]).catch(e => e);
    expect(err).toBeInstanceOf(ResolveError);
    expect(err.message).toBe('resolved tree has g:c at 3.0 instead of 4.0');
  });

  it('apply/restore/accept/dispose keep build.gradle, gradle.properties and the catalog consistent', async () => {
    const t = tool();
    await t.init();
    const deps = await t.listDirectDeps();
    const a = deps.find(d => d.name === 'a')!;
    const c = deps.find(d => d.name === 'c')!;
    const old = new Date(2000, 0, 1);
    fs.utimesSync(path.join(dir, 'build.gradle'), old, old);

    expect(await t.apply([{ dep: a, version: '2.0' }])).toEqual([{ via: 'property', property: 'aVersion' }]);
    expect(read('gradle.properties')).toBe('aVersion=2.0\n');
    expect(read('build.gradle')).toBe(BUILD);
    expect(fs.statSync(path.join(dir, 'build.gradle')).mtime).toEqual(old); // unchanged files are not rewritten
    await t.restore();
    expect(read('gradle.properties')).toBe(PROPS);

    await t.apply([{ dep: a, version: '2.0' }]);
    expect(await t.apply([{ dep: c, version: '4.0' }])).toEqual([{ via: 'catalog', property: 'c' }]);
    expect(read('gradle.properties')).toBe(PROPS); // each apply starts from the accepted state
    expect(read('gradle/libs.versions.toml')).toContain('c = "4.0"');
    await t.accept();
    await t.apply([{ dep: a, version: '5.0' }]);
    await t.dispose();
    expect(read('gradle.properties')).toBe(PROPS);
    expect(read('gradle/libs.versions.toml')).toContain('c = "4.0"');
    expect(read('build.gradle')).toBe(BUILD);
    expect(fs.existsSync(path.join(dir, 'build/safer'))).toBe(false);
  });

  it('resolveTrees resolves BATCH_SIZE versions per saferDeps call with -PsaferBatchFile', async () => {
    const t = tool();
    await t.init();
    const [a] = await t.listDirectDeps();
    calls = [];
    const versions = Array.from({ length: BATCH_SIZE + 2 }, (_, i) => `2.${i}`);
    const trees = await t.resolveTrees(singleUnit(a), versions.map(v => ({ version: v, versions: { 'g:a': v } })));
    expect(calls.map(c => Object.keys(JSON.parse(read(prop(c, 'saferBatchFile')!))))).toEqual([versions.slice(0, BATCH_SIZE), versions.slice(BATCH_SIZE)]);
    expect([...trees.keys()]).toEqual(versions);
    expect(trees.get('2.3')).toContainEqual({ group: 'g', name: 'a', version: '2.3' });
    expect(read('gradle.properties')).toBe(PROPS);
  });

  it('resolveTrees returns per-version failures as ResolveErrors without failing the others', async () => {
    const t = tool();
    await t.init();
    const [a] = await t.listDirectDeps();
    const trees = await t.resolveTrees(singleUnit(a), plansOf(['2.0', '99.0', '7.7']));
    expect(trees.get('2.0')).toContainEqual({ group: 'g', name: 'a', version: '2.0' });
    expect(trees.get('99.0')).toBeInstanceOf(ResolveError);
    expect((trees.get('99.0') as Error).message).toBe('gradle saferDeps failed: Unresolved productionRuntimeClasspath dependencies (1): g:a:99.0 (Could not find g:a:99.0.)');
    expect((trees.get('7.7') as Error).message).toBe('resolved tree has g:a at 7.6 instead of 7.7');
  });

  it('resolveTrees falls back to one call per version, for the rest of the run, when the control copy differs', async () => {
    const t = tool();
    await t.init();
    const [a] = await t.listDirectDeps();
    controlDiffers = true;
    calls = [];
    const trees = await t.resolveTrees(singleUnit(a), plansOf(['2.0', '3.0']));
    expect(trees.get('3.0')).toContainEqual({ group: 'g', name: 'a', version: '3.0' });
    expect(calls.map(c => (prop(c, 'saferBatchFile') ? Object.keys(JSON.parse(read(prop(c, 'saferBatchFile')!))).join(',') : prop(c, 'saferOverride')))).toEqual(['2.0,3.0', 'g:a:2.0', 'g:a:3.0']);
    expect(read('gradle-discovery.log')).toContain('batch resolution disabled (control copy differs from the shipped tree)');
    calls = [];
    await t.resolveTrees(singleUnit(a), plansOf(['4.0']));
    expect(calls.map(c => prop(c, 'saferBatchFile') ?? prop(c, 'saferOverride'))).toEqual(['g:a:4.0']);
    expect(calls[0].some(c => c.startsWith('-PsaferBatch'))).toBe(false);
  });

  it('resolveTrees reports a failed batch call as the error of every version in it', async () => {
    const t = tool({ exec: async (args, opts) => { calls.push(args); if (opts?.logFile) fs.writeFileSync(opts.logFile, "* What went wrong:\nExecution failed for task ':saferDeps'.\n> boom\n"); return { code: 1, stdout: '', durationMs: 1 }; } });
    await t.init();
    const a = { group: 'g', name: 'a', version: '1.0', explicitVersion: true, scope: 'compile' };
    const trees = await t.resolveTrees(singleUnit(a), plansOf(['2.0', '3.0']));
    expect((trees.get('2.0') as Error).message).toBe("gradle saferDeps failed: Execution failed for task ':saferDeps'. > boom");
    expect(trees.get('3.0')).toBe(trees.get('2.0'));
  });

  it('build runs clean build; tests off skips test execution and test compilation', async () => {
    const t = tool();
    await t.init();
    const [a] = await t.listDirectDeps();
    const ok = await t.build({ tests: true, logFile: path.join(dir, 'b1.log') });
    expect(ok.ok).toBe(true);
    expect(calls.at(-1)).toEqual(expect.arrayContaining(['clean', 'build']));
    expect(calls.at(-1)).not.toContain('-x');
    await t.apply([{ dep: a, version: '9.9' }]);
    const bad = await t.build({ tests: false, logFile: path.join(dir, 'b2.log') });
    expect(bad).toMatchObject({ ok: false, firstError: "Execution failed for task ':compileJava'. > Compilation failed; see the compiler error output for details." });
    expect(calls.at(-1)!.slice(-6)).toEqual(['clean', 'build', '-x', 'test', '-x', 'compileTestJava']);
  });

  it('wraps builds in timeout -s KILL and reports timeouts and early kills', async () => {
    const t = tool({ buildTimeoutSec: 42 });
    await t.init();
    await t.build({ tests: true, logFile: path.join(dir, 'b.log') });
    expect(calls.at(-1)!.slice(0, 5)).toEqual(['timeout', '-s', 'KILL', '42', './gradlew']);
    const exec = (code: number, durationMs: number): ContainerExec => async (args, opts) => {
      calls.push(args);
      if (opts?.logFile) fs.writeFileSync(opts.logFile, '> Task :compileJava\n');
      return { code, stdout: '', durationMs };
    };
    expect(await tool({ exec: exec(137, 10_000), buildTimeoutSec: 10 }).build({ tests: true, logFile: path.join(dir, 'b.log') })).toMatchObject({ ok: false, firstError: 'timeout after 10s' });
    expect(await tool({ exec: exec(124, 10_000), buildTimeoutSec: 10 }).build({ tests: true, logFile: path.join(dir, 'b.log') })).toMatchObject({ firstError: 'timeout after 10s' });
    expect(await tool({ exec: exec(137, 1_000), buildTimeoutSec: 10 }).build({ tests: true, logFile: path.join(dir, 'b.log') })).toMatchObject({ firstError: 'killed (exit 137, likely out of memory)' });
    expect(await tool({ exec: exec(1, 1_000), buildTimeoutSec: 10 }).build({ tests: true, logFile: path.join(dir, 'b.log') })).toMatchObject({ firstError: 'gradle exit 1' });
  });

  it('classpath returns the saferClasspath file content; classesDir and packagedArtifact', async () => {
    const t = tool();
    await t.init();
    expect(await t.classpath()).toBe('/app/build/classes/java/main:/app/build/resources/main:/tmp/.gradle/caches/a-1.0.jar');
    expect(calls.at(-1)).toContain('saferClasspath');
    expect(t.classesDir()).toBe('build/classes/java/main');
    expect(await t.packagedArtifact()).toBeNull();
    const libs = path.join(dir, 'build/libs');
    fs.mkdirSync(libs, { recursive: true });
    for (const [f, age] of [['demo-plain.jar', 0], ['demo.jar', 10], ['demo-sources.jar', 0]] as const) {
      fs.writeFileSync(path.join(libs, f), 'x');
      const when = new Date(Date.now() - age * 1000);
      fs.utimesSync(path.join(libs, f), when, when);
    }
    expect(await t.packagedArtifact()).toBe(path.join(libs, 'demo.jar'));
  });

  it('init makes gradlew executable and records the Gradle version; info() exposes java and gradle', async () => {
    fs.writeFileSync(path.join(dir, 'gradlew'), '#!/bin/sh\n', { mode: 0o644 });
    const exec: ContainerExec = async args => {
      calls.push(args);
      if (args.includes('--version'))
        return { code: 0, stdout: 'Picked up JAVA_TOOL_OPTIONS: -Xmx1024m\nWelcome to Gradle 8.10!\n\n------------------------------------------------------------\nGradle 8.10\n------------------------------------------------------------\n', durationMs: 1 };
      return { code: 0, stdout: '', durationMs: 1 };
    };
    const host: string[] = [];
    const t = tool({ exec, startContainer: undefined, runHost: async cmd => (host.push(cmd), 0) });
    await t.init();
    expect(t.info()).toEqual({ java: '17', gradle: 'Gradle 8.10' });
    expect(fs.statSync(path.join(dir, 'gradlew')).mode & 0o111).not.toBe(0);
    expect(host[0]).toMatch(/init-java-container\.sh 17 /);
    const offline = tool();
    await offline.init();
    expect(offline.info()).toEqual({ java: '17', gradle: 'unknown' });
    expect(t.name).toBe('gradle');
  });

  it('init reads build.gradle.kts and works without properties or catalog', async () => {
    fs.rmSync(path.join(dir, 'build.gradle'));
    fs.rmSync(path.join(dir, 'gradle.properties'));
    fs.rmSync(path.join(dir, 'gradle'), { recursive: true });
    fs.writeFileSync(path.join(dir, 'build.gradle.kts'), 'java { toolchain { languageVersion.set(JavaLanguageVersion.of(21)) } }\ndependencies {\n    implementation("g:a:1.0")\n}\n');
    const t = tool();
    await t.init();
    expect(t.info().java).toBe('21');
    const a = { group: 'g', name: 'a', version: '1.0', explicitVersion: true, scope: 'compile' };
    expect(await t.apply([{ dep: a, version: '2.0' }])).toEqual([{ via: 'literal' }]);
    expect(read('build.gradle.kts')).toContain('implementation("g:a:2.0")');
    await t.dispose();
    expect(read('build.gradle.kts')).toContain('implementation("g:a:1.0")');
    fs.rmSync(path.join(dir, 'build.gradle.kts'));
    await expect(tool().init()).rejects.toThrow(/no build.gradle/);
  });

  it('hasTests looks for @Test under src/test/java', () => {
    expect(tool().hasTests()).toBe(false);
    fs.mkdirSync(path.join(dir, 'src/test/java/x'), { recursive: true });
    fs.writeFileSync(path.join(dir, 'src/test/java/x/ATest.java'), 'class ATest { @Test void t() {} }');
    expect(tool().hasTests()).toBe(true);
  });

  it('dispose runs every cleanup step even when one fails, then rethrows the first error', async () => {
    const host: string[] = [];
    const t = tool({ startContainer: undefined, runHost: async cmd => (host.push(cmd), 0), exec: async () => ({ code: 0, stdout: '', durationMs: 1 }) });
    await t.init();
    host.length = 0;
    fs.mkdirSync(path.join(dir, 'build/safer'), { recursive: true });
    fs.writeFileSync(path.join(dir, 'build/safer/deps-1.json'), '{}');
    fs.rmSync(path.join(dir, 'build.gradle')); // restoring the build file now fails
    await expect(t.dispose()).rejects.toThrow(/ENOENT/);
    expect(fs.existsSync(path.join(dir, 'build/safer'))).toBe(false);
    expect(read('gradle.properties')).toBe(PROPS);
    expect(host).toEqual([`docker rm -f ${CONTAINER}`]);
  });
});
