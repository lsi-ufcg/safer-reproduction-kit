import { exec, ExecOptions } from 'child_process';
import * as path from 'path';
import * as dotenv from 'dotenv';

dotenv.config({
    path: path.resolve('.', '../.env'),
});
export const gradleProjectPath = process.env.PROJECT_ROOT_PATH;

export function runCommand(command: string, directory: string): Promise<string> {
    const options: ExecOptions = directory ? { cwd: directory } : {};

    return new Promise((resolve, reject) => {
        exec(command, options, (error, stdout, stderr) => {
            if (error && error.code !== 0) {
                reject(`Error: ${error.message}`);
                return;
            }

            /*if (stderr) {
                reject(`Stderr: ${stderr}`);
                return;
            }*/
            resolve(stdout.trim());
        });
    });
}

// limpa o texto da dependência removendo partes não necessárias
export function cleanDependency(depRawText: string): string {
    let cleanDep = depRawText.indexOf('(') !== -1 ? depRawText.slice(0, depRawText.indexOf('(') - 1) : depRawText;

    if (depRawText.includes('->') && depRawText.lastIndexOf(':') < depRawText.lastIndexOf('->')) {
        if (depRawText.split(':').length > 2) {
            cleanDep = depRawText.slice(0, depRawText.lastIndexOf(':') + 1) + depRawText.slice(depRawText.lastIndexOf('->') + 3);
        } else {
            cleanDep = depRawText.slice(0, depRawText.indexOf(' ') + 1) + depRawText.slice(depRawText.lastIndexOf('->') + 3);
        }
    }

    return cleanDep.replace(' ', ':');
}

// executa um comando Gradle em um diretório e captura o output
export async function executeGradleCommand(command: string, path: string): Promise<string> {
    try {
        return await runCommand(command, path);
    } catch (error) {
        console.error("Error executing Gradle command:", error);
        throw error;
    }
}
