import execCommand from '../../utils/execCommand';

import * as dotenv from 'dotenv';
import * as path from "path";

dotenv.config({
    path: path.resolve('.', '../.env'),
});

// define o executor para construir o projeto gradle
const saferPath = process.env.SAFER_ROOT_PATH;
export const GradleRunner = {
  runGradleBuild: (projectPath: string, projectTests: boolean, { verbose }: { verbose: boolean }) => {
    execCommand(`${saferPath}/src/runners/gradle/run-gradle-build.sh ${projectPath} ${!projectTests} ${verbose}`);
  },
};
