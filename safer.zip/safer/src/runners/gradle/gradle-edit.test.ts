import fs from 'fs';
import path from 'path';

import { describe, expect, it } from 'vitest';

import { detectJavaVersion, findDeclarations, GradleFiles, hasExplicitVersion, maskComments, setDependencyVersion, setDependencyVersions } from './gradle-edit';

const PORT = path.resolve('src/test-fixtures/gradle/port');
const port: GradleFiles = {
  buildFile: 'build.gradle',
  build: fs.readFileSync(path.join(PORT, 'build.gradle'), 'utf8'),
  properties: fs.readFileSync(path.join(PORT, 'gradle.properties'), 'utf8'),
  catalog: fs.readFileSync(path.join(PORT, 'gradle/libs.versions.toml'), 'utf8'),
};

const groovy = (build: string, extra: Partial<GradleFiles> = {}): GradleFiles => ({ buildFile: 'build.gradle', build, ...extra });
const kts = (build: string, extra: Partial<GradleFiles> = {}): GradleFiles => ({ buildFile: 'build.gradle.kts', build, ...extra });

const changedLines = (a: string, b: string) => {
  const x = a.split('\n');
  const y = b.split('\n');
  expect(y.length).toBe(x.length);
  return x.filter((line, i) => line !== y[i]).length;
};

describe('maskComments', () => {
  it('blanks // and /* */ comments in Gradle files, keeping length, newlines and strings', () => {
    const text = "a // c1\nb /* c2\nc3 */ d 'x // not' \"y /* no */\"";
    const masked = maskComments(text, 'gradle');
    expect(masked.length).toBe(text.length);
    expect(masked).toBe("a      \nb      \n      d 'x // not' \"y /* no */\"");
  });
  it('blanks # comments in TOML (not inside strings) and properties', () => {
    expect(maskComments('a = "x#y" # c\n# full\n', 'toml')).toBe('a = "x#y"    \n      \n');
    expect(maskComments('# c\na=1\n  ! d\n', 'properties')).toBe('   \na=1\n     \n');
  });
});

describe('findDeclarations on the port', () => {
  const decls = findDeclarations(port);
  it('returns every port dependency in build-file order', () => {
    expect(decls.map(d => `${d.configuration} ${d.group}:${d.name}`)).toEqual([
      'implementation io.opentelemetry:opentelemetry-api',
      'implementation org.springframework.boot:spring-boot-starter-actuator',
      'implementation org.springframework.boot:spring-boot-starter-data-jpa',
      'implementation org.springframework.boot:spring-boot-starter-web',
      'implementation org.springframework.cloud:spring-cloud-starter-bus-amqp',
      'implementation org.springframework.cloud:spring-cloud-starter-config',
      'implementation org.springframework.boot:spring-boot-starter-hateoas',
      'runtimeOnly com.oracle.database.jdbc:ojdbc8',
      'runtimeOnly io.micrometer:micrometer-registry-prometheus',
      'compileOnly org.projectlombok:lombok',
      'annotationProcessor org.projectlombok:lombok',
      'implementation io.minio:minio',
      'implementation com.squareup.okhttp3:okhttp',
      'implementation org.liquibase:liquibase-core',
      'testImplementation org.mockito:mockito-core',
      'testImplementation org.junit.jupiter:junit-jupiter-engine',
      'testImplementation junit:junit',
      'testImplementation org.junit.vintage:junit-vintage-engine',
      'testImplementation org.springframework.boot:spring-boot-starter-test',
      'implementation org.springframework.boot:spring-boot-starter-validation',
      'implementation com.tngtech.archunit:archunit',
      'implementation org.jacoco:jacoco-maven-plugin',
      'implementation org.springdoc:springdoc-openapi-starter-webmvc-ui',
      'implementation net.logstash.logback:logstash-logback-encoder',
      'implementation org.codehaus.janino:janino',
      'implementation com.thoughtworks.xstream:xstream',
      'implementation commons-beanutils:commons-beanutils',
      'implementation net.sf.flexjson:flexjson',
      'implementation com.fasterxml.jackson.dataformat:jackson-dataformat-xml',
      'implementation org.apache.commons:commons-csv',
      'implementation com.opencsv:opencsv',
    ]);
  });
  it('resolves property, catalog and BOM-managed versions', () => {
    const by = (name: string) => decls.find(d => d.name === name)!;
    expect(by('minio')).toEqual({ group: 'io.minio', name: 'minio', configuration: 'implementation', form: 'string', version: '8.3.9', versionSource: 'property', property: 'minioVersion' });
    expect(by('mockito-core')).toMatchObject({ version: '5.1.1', versionSource: 'property', property: 'mockitoVersion' });
    expect(by('opencsv')).toEqual({ group: 'com.opencsv', name: 'opencsv', configuration: 'implementation', form: 'catalog', version: '5.7.1', versionSource: 'catalog-ref', property: 'opencsv', alias: 'opencsv' });
    expect(by('okhttp')).toMatchObject({ form: 'string', version: '4.9.3', versionSource: 'literal' });
    for (const n of ['spring-boot-starter-web', 'spring-cloud-starter-config', 'liquibase-core']) {
      expect(by(n).versionSource).toBe('none');
      expect(by(n).version).toBeUndefined();
    }
  });
  it('does not report the dependencyManagement { dependencies { dependency ... } } entry', () => {
    expect(decls.some(d => d.name === 'maven-reporting-api')).toBe(false);
    expect(hasExplicitVersion(port, { group: 'org.apache.maven.reporting', name: 'maven-reporting-api' })).toBe(false);
    expect(() => setDependencyVersion(port, { group: 'org.apache.maven.reporting', name: 'maven-reporting-api' }, '3.1')).toThrow(/not found/);
  });
  it('hasExplicitVersion distinguishes versioned and BOM-managed dependencies', () => {
    expect(hasExplicitVersion(port, { group: 'io.minio', name: 'minio' })).toBe(true);
    expect(hasExplicitVersion(port, { group: 'com.opencsv', name: 'opencsv' })).toBe(true);
    expect(hasExplicitVersion(port, { group: 'org.liquibase', name: 'liquibase-core' })).toBe(false);
    expect(hasExplicitVersion(port, { group: 'no', name: 'such' })).toBe(false);
  });
});

describe('string-literal edits', () => {
  const build = `dependencies {
    implementation 'g:a:1.0'
    implementation "g:b:1.0"
    implementation('g:c:1.0')
    testImplementation("g:d:1.0:tests@jar") { transitive = false }
    implementation 'g:e:1.0'
}
`;
  it('parses classifier, extension and trailing closures', () => {
    const decls = findDeclarations(groovy(build));
    expect(decls.map(d => `${d.configuration} ${d.name} ${d.version} ${d.form}`)).toEqual([
      'implementation a 1.0 string',
      'implementation b 1.0 string',
      'implementation c 1.0 string',
      'testImplementation d 1.0 string',
      'implementation e 1.0 string',
    ]);
  });
  it.each([
    ['a', "    implementation 'g:a:2.0'"],
    ['b', '    implementation "g:b:2.0"'],
    ['c', "    implementation('g:c:2.0')"],
    ['d', '    testImplementation("g:d:2.0:tests@jar") { transitive = false }'],
  ])('edits only declaration %s', (name, expected) => {
    const r = setDependencyVersion(groovy(build), { group: 'g', name }, '2.0');
    expect(r.via).toBe('literal');
    expect(r.changed).toEqual(['build']);
    expect(changedLines(build, r.files.build)).toBe(1);
    expect(r.files.build.split('\n')).toContain(expected);
  });
});

describe('a dependency declared in two configurations', () => {
  it('edits the shared property once instead of inlining both declarations', () => {
    const build = `dependencies {
    implementation "g:a:$x"
    testImplementation "g:a:$x"
}
`;
    const r = setDependencyVersion(groovy(build, { properties: 'x=1.0\n' }), { group: 'g', name: 'a' }, '2.0');
    expect(r.via).toBe('property');
    expect(r.changed).toEqual(['properties']);
    expect(r.files.properties).toBe('x=2.0\n');
    expect(r.files.build).toBe(build);
  });
});

describe('map and named-argument edits', () => {
  it('edits a Groovy map declaration with keys in any order', () => {
    const build = `dependencies {
    implementation group: 'g', name: 'a', version: '1.0'
    implementation version: '1.0', name: 'b', group: 'g'
}
`;
    const decls = findDeclarations(groovy(build));
    expect(decls.map(d => [d.name, d.form, d.version])).toEqual([['a', 'map', '1.0'], ['b', 'map', '1.0']]);
    const r = setDependencyVersion(groovy(build), { group: 'g', name: 'b' }, '2.0');
    expect(r.via).toBe('literal');
    expect(r.files.build).toContain("implementation version: '2.0', name: 'b', group: 'g'");
    expect(r.files.build).toContain("implementation group: 'g', name: 'a', version: '1.0'");
  });
  it('resolves a bare-identifier map version as a property', () => {
    const build = `def fooVersion = '1.0'
dependencies {
    implementation group: 'g', name: 'a', version: fooVersion
}
`;
    expect(findDeclarations(groovy(build))[0]).toMatchObject({ version: '1.0', versionSource: 'property', property: 'fooVersion' });
    const r = setDependencyVersion(groovy(build), { group: 'g', name: 'a' }, '2.0');
    expect(r).toMatchObject({ via: 'property', property: 'fooVersion', changed: ['build'] });
    expect(r.files.build).toContain("def fooVersion = '2.0'");
    expect(r.files.build).toContain('version: fooVersion');
  });
  it('edits a Kotlin named-argument declaration', () => {
    const build = `dependencies {
    implementation(group = "g", name = "a", version = "1.0")
    implementation("g:b:1.0")
}
`;
    const decls = findDeclarations(kts(build));
    expect(decls.map(d => [d.name, d.form, d.version])).toEqual([['a', 'named', '1.0'], ['b', 'string', '1.0']]);
    const r = setDependencyVersion(kts(build), { group: 'g', name: 'a' }, '2.0');
    expect(r.files.build).toContain('implementation(group = "g", name = "a", version = "2.0")');
    expect(changedLines(build, r.files.build)).toBe(1);
  });
});

describe('property edits', () => {
  const props = 'minioVersion=8.3.9\nother=1\n';
  it('edits gradle.properties when the property has one user', () => {
    const files = groovy('dependencies {\n    implementation "io.minio:minio:${minioVersion}"\n}\n', { properties: props });
    const r = setDependencyVersion(files, { group: 'io.minio', name: 'minio' }, '8.4.0');
    expect(r).toMatchObject({ via: 'property', property: 'minioVersion', changed: ['properties'] });
    expect(r.files.properties).toBe('minioVersion=8.4.0\nother=1\n');
    expect(r.files.build).toBe(files.build);
  });
  it('inlines the version when the property has two users', () => {
    const files = groovy('dependencies {\n    implementation "io.minio:minio:${minioVersion}"\n    implementation "io.minio:other:$minioVersion"\n}\n', { properties: props });
    const r = setDependencyVersion(files, { group: 'io.minio', name: 'minio' }, '8.4.0');
    expect(r).toMatchObject({ via: 'property-inlined', property: 'minioVersion', changed: ['build'] });
    expect(r.files.properties).toBe(props);
    expect(r.files.build).toContain('implementation "io.minio:minio:8.4.0"');
    expect(r.files.build).toContain('implementation "io.minio:other:$minioVersion"');
  });
  it.each(['${project.v}', '${rootProject.ext.v}', '${property("v")}', '$v'])('recognises %s as property v', token => {
    const files = groovy(`ext { v = '1.0' }\ndependencies {\n    implementation "g:a:${token}"\n}\n`);
    expect(findDeclarations(files)[0]).toMatchObject({ version: '1.0', versionSource: 'property', property: 'v' });
  });
  it('edits an ext { } definition in the build file when it has one user', () => {
    const build = "ext {\n    mockitoVersion = '5.1.1'\n}\ndependencies {\n    testImplementation \"org.mockito:mockito-core:${mockitoVersion}\"\n}\n";
    const r = setDependencyVersion(groovy(build), { group: 'org.mockito', name: 'mockito-core' }, '5.2.0');
    expect(r).toMatchObject({ via: 'property', property: 'mockitoVersion', changed: ['build'] });
    expect(r.files.build).toContain("mockitoVersion = '5.2.0'");
    expect(r.files.build).toContain('${mockitoVersion}');
  });
  it('resolves Kotlin val and extra["x"] definitions', () => {
    const build = 'val a = "1.0"\nextra["b"] = "2.0"\ndependencies {\n    implementation("g:a:$a")\n    implementation("g:b:${property("b")}")\n}\n';
    expect(findDeclarations(kts(build)).map(d => [d.property, d.version])).toEqual([['a', '1.0'], ['b', '2.0']]);
    const r = setDependencyVersion(kts(build), { group: 'g', name: 'b' }, '3.0');
    expect(r.files.build).toContain('extra["b"] = "3.0"');
  });
  it('prefers gradle.properties over the build file', () => {
    const files = groovy("ext.v = '1.0'\ndependencies {\n    implementation \"g:a:${v}\"\n}\n", { properties: 'v=9.0\n' });
    expect(findDeclarations(files)[0].version).toBe('9.0');
  });
});

describe('catalog edits', () => {
  const catalog = `[versions]
shared = "1.0"
solo = "2.0"

[libraries]
lit-str = "g:lit:3.0"
lit-table = { module = "g:littab", version = "4.0" }
solo_lib = { module = "g:solo", version.ref = "solo" }
s1 = { group = "g", name = "s1", version.ref = "shared" }
s2 = { module = "g:s2", version.ref = "shared" }
nover = { module = "g:nover" }
`;
  const build = `dependencies {
    implementation libs.lit.str
    implementation(libs.lit.table)
    implementation libs.solo.lib
    implementation libs.s1
    implementation libs.s2
    implementation libs.nover
}
`;
  const files = groovy(build, { catalog });
  it('resolves every catalog form', () => {
    expect(findDeclarations(files).map(d => [d.alias, `${d.group}:${d.name}`, d.version, d.versionSource, d.property])).toEqual([
      ['lit-str', 'g:lit', '3.0', 'catalog-literal', undefined],
      ['lit-table', 'g:littab', '4.0', 'catalog-literal', undefined],
      ['solo_lib', 'g:solo', '2.0', 'catalog-ref', 'solo'],
      ['s1', 'g:s1', '1.0', 'catalog-ref', 'shared'],
      ['s2', 'g:s2', '1.0', 'catalog-ref', 'shared'],
      ['nover', 'g:nover', undefined, 'none', undefined],
    ]);
  });
  it('edits [versions] for a single-user ref', () => {
    const r = setDependencyVersion(files, { group: 'g', name: 'solo' }, '2.1');
    expect(r).toMatchObject({ via: 'catalog', property: 'solo', changed: ['catalog'] });
    expect(r.files.catalog).toContain('solo = "2.1"');
    expect(r.files.catalog).toContain('version.ref = "solo"');
    expect(r.files.build).toBe(build);
  });
  it('inlines a shared ref into that entry only', () => {
    const r = setDependencyVersion(files, { group: 'g', name: 's2' }, '1.5');
    expect(r).toMatchObject({ via: 'property-inlined', property: 'shared', changed: ['catalog'] });
    expect(r.files.catalog).toContain('s2 = { module = "g:s2", version = "1.5" }');
    expect(r.files.catalog).toContain('s1 = { group = "g", name = "s1", version.ref = "shared" }');
    expect(r.files.catalog).toContain('shared = "1.0"');
  });
  it('edits catalog literals', () => {
    expect(setDependencyVersion(files, { group: 'g', name: 'lit' }, '3.1').files.catalog).toContain('lit-str = "g:lit:3.1"');
    const r = setDependencyVersion(files, { group: 'g', name: 'littab' }, '4.1');
    expect(r).toMatchObject({ via: 'catalog', changed: ['catalog'] });
    expect(r.files.catalog).toContain('lit-table = { module = "g:littab", version = "4.1" }');
  });
  it('does not treat a ref also used by a plugin as single-user', () => {
    const withPlugin = catalog + '\n[plugins]\nsp = { id = "x.y", version.ref = "solo" }\n';
    const r = setDependencyVersion(groovy(build, { catalog: withPlugin }), { group: 'g', name: 'solo' }, '2.1');
    expect(r.via).toBe('property-inlined');
    expect(r.files.catalog).toContain('solo = "2.0"');
  });
});

describe('ignored regions', () => {
  it('ignores commented-out declarations and edits the real one', () => {
    const build = `dependencies {
    // implementation 'g:a:1.0'
    /* implementation 'g:a:1.0'
       implementation 'g:b:1.0' */
    implementation 'g:a:1.0'
}
`;
    expect(findDeclarations(groovy(build)).map(d => d.name)).toEqual(['a']);
    const r = setDependencyVersion(groovy(build), { group: 'g', name: 'a' }, '2.0');
    expect(r.files.build).toContain("    // implementation 'g:a:1.0'");
    expect(r.files.build).toContain("    /* implementation 'g:a:1.0'");
    expect(r.files.build).toContain("    implementation 'g:a:2.0'");
    expect(changedLines(build, r.files.build)).toBe(1);
  });
  it('ignores buildscript, constraints, platform and other non top-level blocks', () => {
    const build = `buildscript {
    dependencies { classpath 'g:cp:1.0' }
}
subprojects {
    dependencies {
        implementation 'g:sub:1.0'
    }
}
configurations {
    implementation 'g:conf:1.0'
}
dependencies {
    implementation platform('g:bom:1')
    implementation enforcedPlatform("g:bom2:1")
    constraints {
        implementation 'g:con:1.0'
    }
    implementation 'g:real:1.0'
}
`;
    expect(findDeclarations(groovy(build)).map(d => d.name)).toEqual(['real']);
    expect(() => setDependencyVersion(groovy(build), { group: 'g', name: 'con' }, '2')).toThrow(/not found/);
  });
  it('throws when not found or no version', () => {
    const files = groovy("dependencies {\n    implementation 'g:a'\n}\n");
    expect(() => setDependencyVersion(files, { group: 'g', name: 'x' }, '1')).toThrow(/not found/);
    expect(() => setDependencyVersion(files, { group: 'g', name: 'a' }, '1')).toThrow(/no version/);
  });
});

describe('detectJavaVersion', () => {
  it.each([
    ["java { toolchain { languageVersion = JavaLanguageVersion.of(21) } }", '21'],
    ['java { toolchain { languageVersion.set(JavaLanguageVersion.of(11)) } }', '11'],
    ['java { sourceCompatibility = JavaVersion.VERSION_1_8 }', '8'],
    ['java.sourceCompatibility = JavaVersion.VERSION_17', '17'],
    ["sourceCompatibility = '17'", '17'],
    ['sourceCompatibility = "11"', '11'],
    ['sourceCompatibility = 21', '21'],
    ["sourceCompatibility = '1.8'", '8'],
    ['tasks.withType<JavaCompile> { options.release.set(17) }', '17'],
    ['compileJava { options.release = 11 }', '11'],
    ["// sourceCompatibility = '11'\nplugins { id 'java' }", '17'],
    ["plugins { id 'java' }", '17'],
  ])('%s → %s', (build, expected) => {
    expect(detectJavaVersion(build)).toBe(expected);
  });
  it('reads the port', () => expect(detectJavaVersion(port.build)).toBe('17'));
});

describe('round trip on the port', () => {
  const all = (f: GradleFiles) => [f.build, f.properties ?? '', f.catalog ?? ''].join('\n');
  it.each([
    [{ group: 'com.squareup.okhttp3', name: 'okhttp' }, 'literal'],
    [{ group: 'io.minio', name: 'minio' }, 'property'],
    [{ group: 'org.mockito', name: 'mockito-core' }, 'property'],
    [{ group: 'com.opencsv', name: 'opencsv' }, 'catalog'],
  ] as const)('editing %o changes exactly one line', (dep, via) => {
    const r = setDependencyVersion(port, dep, '99.0');
    expect(r.via).toBe(via);
    expect(changedLines(all(port), all(r.files))).toBe(1);
    expect(findDeclarations(r.files).find(d => d.name === dep.name)!.version).toBe('99.0');
  });
});

describe('setDependencyVersions', () => {
  const files = (build: string, properties?: string, catalog?: string) => ({ buildFile: 'build.gradle' as const, build, ...(properties !== undefined && { properties }), ...(catalog !== undefined && { catalog }) });
  const a = { group: 'g', name: 'a' };
  const b = { group: 'g', name: 'b' };

  it('edits a shared gradle.properties property once when every user moves together', () => {
    const f = files('dependencies {\n    implementation "g:a:$libVersion"\n    implementation "g:b:$libVersion"\n}\n', 'libVersion=1.0\n');
    const r = setDependencyVersions(f, [{ dep: a, version: '2.0' }, { dep: b, version: '2.0' }]);
    expect(r.files.properties).toBe('libVersion=2.0\n');
    expect(r.files.build).toBe(f.build);
    expect(r.applied).toEqual([{ via: 'property', property: 'libVersion' }, { via: 'property', property: 'libVersion' }]);
    expect(r.changed).toEqual(['properties']);
  });
  it('inlines a shared property when only one user moves', () => {
    const f = files('dependencies {\n    implementation "g:a:$libVersion"\n    implementation "g:b:$libVersion"\n}\n', 'libVersion=1.0\n');
    const r = setDependencyVersions(f, [{ dep: a, version: '2.0' }]);
    expect(r.files.properties).toBe('libVersion=1.0\n');
    expect(r.files.build).toContain('implementation "g:a:2.0"');
    expect(r.applied).toEqual([{ via: 'property-inlined', property: 'libVersion' }]);
  });
  it('inlines when the users move to different versions', () => {
    const f = files('dependencies {\n    implementation "g:a:$libVersion"\n    implementation "g:b:$libVersion"\n}\n', 'libVersion=1.0\n');
    const r = setDependencyVersions(f, [{ dep: a, version: '2.0' }, { dep: b, version: '2.1' }]);
    expect(r.files.build).toContain('implementation "g:a:2.0"');
    expect(r.files.build).toContain('implementation "g:b:2.1"');
    expect(r.applied.map(x => x.via)).toEqual(['property-inlined', 'property-inlined']);
  });
  it('edits a shared catalog version.ref once when every library moves together', () => {
    const catalog = '[versions]\nlib = "1.0"\n\n[libraries]\na = { module = "g:a", version.ref = "lib" }\nb = { module = "g:b", version.ref = "lib" }\n';
    const f = files('dependencies {\n    implementation libs.a\n    implementation libs.b\n}\n', undefined, catalog);
    const r = setDependencyVersions(f, [{ dep: a, version: '2.0' }, { dep: b, version: '2.0' }]);
    expect(r.files.catalog).toContain('lib = "2.0"');
    expect(r.files.catalog).toContain('version.ref = "lib" }\nb');
    expect(r.applied.map(x => x.via)).toEqual(['catalog', 'catalog']);
  });
  it('mixes a literal and a property', () => {
    const f = files('dependencies {\n    implementation "g:a:1.0"\n    implementation "g:b:$bVersion"\n}\n', 'bVersion=1.0\n');
    const r = setDependencyVersions(f, [{ dep: a, version: '2.0' }, { dep: b, version: '2.0' }]);
    expect(r.files.build).toContain('implementation "g:a:2.0"');
    expect(r.files.properties).toBe('bVersion=2.0\n');
    expect(r.applied.map(x => x.via)).toEqual(['literal', 'property']);
    expect(r.changed.sort()).toEqual(['build', 'properties']);
  });
});
