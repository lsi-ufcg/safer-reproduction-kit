import { getJavaVersion } from './get-java-version';
import { getGradleDeps } from './get-gradle-dependencies';
import fs from "fs/promises";
import * as dotenv from 'dotenv';
import * as path from "path";
import { homedir } from "os";

dotenv.config({
    path: path.resolve('.', '../.env'),
});
export const gradleProjectPath = process.env.PROJECT_ROOT_PATH;

// adapter que obtém informações de versão java e dependências do projeto

export const GradleAdapter = {
  async getDeps(gradleProjectPath: string) {
    try {
      const javaVersion = await getJavaVersion(gradleProjectPath);
      const dependencies = await getGradleDeps(); 
      return { javaVersion, dependencies };
    } catch (error) {
      console.error('Error fetching project information:', error);
      throw error;
    }
  },

  async getBuildGradleReplacedDependencyVersion(
    currentBuildGradle: string,
    dependency: any,
    newVersion: string
  ){
    const stringNotationRegex = /(['"])([^'":]+):([^'":]+):([^'":]+)\1/g;
    let updatedGradle = currentBuildGradle.replace(
      stringNotationRegex,
      (match, quote, group, artifact, version) => {
        if (artifact === dependency.name) {
          return `${quote}${group}:${artifact}:${newVersion}${quote}`;
        }
        return match;
      }
    );
  
    const mapNotationRegex = /(\b(?:implementation|api|compile|testImplementation)\b\s*\(([^)]*)\))/g;
    updatedGradle = updatedGradle.replace(
      mapNotationRegex,
      (match, wholeBlock, innerContent) => {
        // Look for the name property in the dependency map.
        const nameMatch = innerContent.match(/name\s*:\s*['"]([^'"]+)['"]/);
        if (nameMatch && nameMatch[1] === dependency.name) {
          // Replace the version property with the new version.
          const updatedInnerContent = innerContent.replace(
            /(version\s*:\s*['"])([^'"]+)(['"])/,
            `$1${newVersion}$3`
          );
          // Replace the inner content in the original dependency block.
          return match.replace(innerContent, updatedInnerContent);
        }
        return match;
      }
    );
  
    return updatedGradle;
  },

  async writeBuildGradleFile(newBuildGradleContent) {
      // Path to the project’s build.gradle
      const buildGradlePath = path.join(gradleProjectPath, "build.gradle");
      
      console.log(`Writing to path ${buildGradlePath}`);
      console.log(`Current homedir: ${homedir()}`);
    
      // Basic sanity check for empty content
      if (!newBuildGradleContent || newBuildGradleContent.trim() === "") {
        throw new Error("Attempting to write empty or invalid Gradle build content.");
      }
    
      // Ensure the project directory exists
      if (await pathExist(gradleProjectPath)) {
        console.log("Attempting to write file...");
        await fs.writeFile(buildGradlePath, newBuildGradleContent, { encoding: "utf-8", flag: "w" });
        console.log("Write operation completed.");
      } else {
        console.log("Project path does not exist. Creating it...");
        await fs.mkdir(gradleProjectPath, { recursive: true });
        console.log("Path created, retrying file write...");
        await fs.writeFile(buildGradlePath, newBuildGradleContent, "utf-8");
        console.log("Write operation completed after creating the path.");
      }
    
      // Validate that the file is truly written (non-empty)
      const writtenContent = await fs.readFile(buildGradlePath, "utf-8");
      if (!writtenContent || writtenContent.trim() === "") {
        throw new Error("build.gradle content is empty after writing.");
      }
    
      console.log(`build.gradle content successfully written to ${buildGradlePath}`);
    },

  async getGradle(gradleProjectPath: any){
    return fs.readFile(`${gradleProjectPath}/build.gradle`, 'utf8');
  }
}

const pathExist = async (path: any) => {
    try{
        await fs.access(path)
        return true;
    }catch(e){
        return false;
    }
}

export default [GradleAdapter];