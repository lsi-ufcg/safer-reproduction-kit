import fs from "fs/promises";

import AhoCorasick from 'ahocorasick';

import { gradleProjectPath, cleanDependency, executeGradleCommand } from './utils';

// lê o conteúdo do arquivo de dependências especificado
async function readDependenciesFile(filePath: string): Promise<string> {
    return await fs.readFile(filePath, 'utf-8');
}

// filtra as dependências do texto gerado pela execução do comando Gradle
function filterDependencies(text: string): Set<string> {
    const ac = new AhoCorasick(['+---', '\\---']); 
    const results = ac.search(text);  // busca as ocorrências dos padrões no texto
    const set = new Set<string>();

    // processa cada dependência encontrada, limpando e armazenando no Set
    results.forEach(result => {
        const depRawText = text.slice(result[0] + 2).split('\n')[0];
        const cleanDep = cleanDependency(depRawText);
        if (cleanDep && Array.from(set).every(dep => !dep.includes(cleanDep.split(':')[0]))) {
            set.add(cleanDep);  // adiciona a dependência ao Set se não existir uma versão do mesmo grupo
        }
    });

    return set;
}

// função principal para obter as dependências do projeto Gradle
export async function getGradleDeps(): Promise<Array<any>> {
    const gradleCommand = `./gradlew -q dependencies --configuration compileClasspath`;

    try {
        const output = await executeGradleCommand(gradleCommand, gradleProjectPath);  // executa o comando Gradle para capturar dependências
        await fs.writeFile("deps.txt", output);  // escreve o output das dependências em um arquivo deps.txt

        const text = await readDependenciesFile('./deps.txt');  // lê o conteúdo do deps.txt
        const dependenciesSet = filterDependencies(text);  // filtra as dependências para um Set único

        const buildGradleContent = await readDependenciesFile(`${gradleProjectPath}/build.gradle`);  // lê o conteúdo do build.gradle
        const depSet: Array<any> = [];

        // adiciona dependências válidas em um array de objetos com grupo, nome e versão
        for (let dep of dependenciesSet) {
            const depName = dep.split(':')[1];
            if (buildGradleContent.includes(depName)) {
                const [group, name, version] = dep.split(':');
                depSet.push({ group, name, version });
            }
        }

        return depSet;
    } catch (error) {
        console.error("Error fetching Gradle dependencies:", error);
        throw error;
    }
}
