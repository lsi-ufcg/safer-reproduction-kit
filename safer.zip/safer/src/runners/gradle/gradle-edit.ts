export type GradleFiles = {
  buildFile: 'build.gradle' | 'build.gradle.kts';
  build: string; // build file text
  properties?: string; // gradle.properties text, if present
  catalog?: string; // gradle/libs.versions.toml text, if present
};
export type Declaration = {
  group: string;
  name: string;
  configuration: string;
  form: 'string' | 'map' | 'named' | 'catalog';
  version?: string; // literal version after resolving variables/catalog refs; undefined = no version (BOM)
  versionSource: 'literal' | 'property' | 'catalog-literal' | 'catalog-ref' | 'none';
  property?: string; // variable or catalog version key
  alias?: string; // catalog alias
};
type FileKey = 'build' | 'properties' | 'catalog';
export type EditResult = { files: GradleFiles; via: 'literal' | 'property' | 'property-inlined' | 'catalog'; property?: string; changed: FileKey[] };

type Span = { file: FileKey; start: number; end: number };
type Edit = Span & { text: string };
type Lib = { alias: string; group: string; name: string; version?: string; versionSpan?: Span; ref?: string; refSpan?: Span };
type Found = { decl: Declaration; token?: Span; lib?: Lib };

const esc = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

// ---------------------------------------------------------------- masking

/** Index just past the string literal opening at `i` (handles triple quotes, escapes and `${…}` in double quotes). */
function skipString(text: string, i: number): number {
  const q = text[i];
  if (text.startsWith(q.repeat(3), i)) {
    const e = text.indexOf(q.repeat(3), i + 3);
    return e < 0 ? text.length : e + 3;
  }
  for (let k = i + 1; k < text.length; k++) {
    const c = text[k];
    if (c === '\\') k++;
    else if (c === q) return k + 1;
    else if (c === '\n') return k;
    else if (q === '"' && c === '$' && text[k + 1] === '{') {
      let depth = 0;
      for (k++; k < text.length && text[k] !== '\n'; k++) {
        if (text[k] === '{') depth++;
        else if (text[k] === '}' && --depth === 0) break;
      }
    }
  }
  return text.length;
}

function blanker(text: string) {
  const out = text.split('');
  const blank = (s: number, e: number) => {
    for (let k = s; k < e; k++) if (out[k] !== '\n' && out[k] !== '\r') out[k] = ' ';
  };
  return { blank, result: () => out.join('') };
}

export function maskComments(text: string, kind: 'gradle' | 'toml' | 'properties'): string {
  const { blank, result } = blanker(text);
  if (kind === 'properties') {
    for (const m of text.matchAll(/^[ \t]*[#!].*$/gm)) blank(m.index!, m.index! + m[0].length);
    return result();
  }
  for (let i = 0; i < text.length; ) {
    const c = text[i];
    const lineComment = kind === 'gradle' ? c === '/' && text[i + 1] === '/' : c === '#';
    if (lineComment) {
      const e = text.indexOf('\n', i);
      const end = e < 0 ? text.length : e;
      blank(i, end);
      i = end;
    } else if (kind === 'gradle' && c === '/' && text[i + 1] === '*') {
      const e = text.indexOf('*/', i + 2);
      const end = e < 0 ? text.length : e + 2;
      blank(i, end);
      i = end;
    } else if (c === '"' || c === "'") i = skipString(text, i);
    else i++;
  }
  return result();
}

/** Masked text with string contents blanked too, so braces inside strings do not count. */
function structure(masked: string): string {
  const { blank, result } = blanker(masked);
  for (let i = 0; i < masked.length; ) {
    if (masked[i] === '"' || masked[i] === "'") {
      const end = skipString(masked, i);
      blank(i + 1, end - 1);
      i = end;
    } else i++;
  }
  return result();
}

function braceDepths(struct: string): number[] {
  const depths: number[] = [];
  let d = 0;
  for (const c of struct) {
    if (c === '}') d = Math.max(0, d - 1);
    depths.push(d);
    if (c === '{') d++;
  }
  return depths;
}

/** Inner ranges [start, end) of `name { … }` blocks whose keyword sits at brace depth `depth` (any depth if undefined). */
function blocks(struct: string, depths: number[], name: string, depth?: number): [number, number][] {
  const out: [number, number][] = [];
  for (const m of struct.matchAll(new RegExp(`\\b${name}\\s*\\{`, 'g'))) {
    if (depth !== undefined && depths[m.index!] !== depth) continue;
    const open = m.index! + m[0].length - 1;
    let end = struct.length;
    for (let k = open + 1; k < struct.length; k++) {
      if (struct[k] === '}' && depths[k] === depths[open]) {
        end = k;
        break;
      }
    }
    out.push([open + 1, end]);
  }
  return out;
}

// ---------------------------------------------------------------- properties

const QUOTED = `(?:'([^'\\n]*)'|"([^"\\n]*)")`;

function quotedMatch(text: string, re: RegExp, file: FileKey, from = 0, to = text.length) {
  re.lastIndex = from;
  const m = re.exec(text);
  if (!m || m.index >= to) return undefined;
  const g = m[1] !== undefined ? 1 : 2;
  const [start, end] = m.indices![g]!;
  return { value: m[g], span: { file, start, end } as Span };
}

function findProperty(files: GradleFiles, masked: string, name: string): { value: string; span: Span } | undefined {
  const n = esc(name);
  if (files.properties !== undefined) {
    const m = new RegExp(`^[ \\t]*${n}[ \\t]*[=:][ \\t]*(.*?)[ \\t\\r]*$`, 'md').exec(maskComments(files.properties, 'properties'));
    if (m) return { value: m[1], span: { file: 'properties', start: m.indices![1]![0], end: m.indices![1]![1] } };
  }
  const re = (src: string) => new RegExp(src, 'gd');
  const direct = quotedMatch(masked, re(`\\bext\\.${n}\\s*=\\s*${QUOTED}`), 'build');
  if (direct) return direct;
  const struct = structure(masked);
  for (const [s, e] of blocks(struct, braceDepths(struct), 'ext')) {
    const inExt = quotedMatch(masked, re(`(?:^|[;{\\s])${n}\\s*=\\s*${QUOTED}`), 'build', s, e);
    if (inExt) return inExt;
  }
  for (const src of [`\\bdef\\s+${n}\\s*=\\s*${QUOTED}`, `\\bval\\s+${n}\\s*=\\s*${QUOTED}`, `\\bextra\\[\\s*"${n}"\\s*\\]\\s*=\\s*${QUOTED}`]) {
    const found = quotedMatch(masked, re(src), 'build');
    if (found) return found;
  }
  return undefined;
}

/** `$x`, `${x}`, `${project.x}`, `${rootProject.ext.x}`, `${property("x")}` → x. */
const PROPERTY_TOKEN = /^\$(?:\{(?:project\.|rootProject\.ext\.|rootProject\.|ext\.)?(\w+)\}|\{property\(["'](\w+)["']\)\}|(\w+))$/;

function countUses(masked: string, name: string): number {
  const n = esc(name);
  const re = new RegExp(
    `\\$${n}(?!\\w)|\\$\\{(?:project\\.|rootProject\\.ext\\.|rootProject\\.|ext\\.)?${n}\\}|\\$\\{property\\(["']${n}["']\\)\\}|\\bversion\\s*[:=]\\s*${n}\\b`,
    'g',
  );
  return masked.match(re)?.length ?? 0;
}

// ---------------------------------------------------------------- version catalog

const normAlias = (s: string) => s.replace(/[-_.]/g, '.').toLowerCase();

function parseCatalog(catalog: string): { versions: Map<string, { value: string; span: Span }>; libraries: Lib[]; refUses: (k: string) => number } {
  const masked = maskComments(catalog, 'toml');
  const versions = new Map<string, { value: string; span: Span }>();
  const libraries: Lib[] = [];
  const span = (start: number, end: number): Span => ({ file: 'catalog', start, end });
  let section = '';
  let offset = 0;
  for (const line of masked.split('\n')) {
    const header = line.match(/^\s*\[\s*([\w.-]+)\s*\]/);
    const entry = /^\s*([\w.-]+)\s*=\s*(.*?)\s*$/d.exec(line);
    if (header) section = header[1];
    else if (entry && section === 'versions') {
      const v = /^"([^"]*)"/d.exec(entry[2]);
      const base = offset + entry.indices![2]![0];
      if (v) versions.set(entry[1], { value: v[1], span: span(base + v.indices![1]![0], base + v.indices![1]![1]) });
    } else if (entry && section === 'libraries') {
      const value = entry[2];
      const base = offset + entry.indices![2]![0];
      const lib: Lib = { alias: entry[1], group: '', name: '' };
      const coord = /^"([^"]*)"/.exec(value);
      if (coord) {
        const [g, a, v] = coord[1].split(':');
        Object.assign(lib, { group: g, name: a ?? '' });
        if (v) {
          const start = base + 1 + g.length + 1 + a.length + 1;
          Object.assign(lib, { version: v, versionSpan: span(start, start + v.length) });
        }
      } else if (value.startsWith('{')) {
        const field = (key: string) => new RegExp(`(?:^|[{,\\s])${key}\\s*=\\s*"([^"]*)"`, 'd').exec(value);
        const module = field('module')?.[1];
        if (module) [lib.group, lib.name = ''] = module.split(':');
        else Object.assign(lib, { group: field('group')?.[1] ?? '', name: field('name')?.[1] ?? '' });
        const v = field('version');
        const ref = field('version\\.ref');
        if (v) Object.assign(lib, { version: v[1], versionSpan: span(base + v.indices![1]![0], base + v.indices![1]![1]) });
        else if (ref) {
          const refStart = base + ref.index + ref[0].search(/version\.ref/);
          Object.assign(lib, { ref: ref[1], refSpan: span(refStart, base + ref.index + ref[0].length) });
        }
      }
      if (lib.group && lib.name) libraries.push(lib);
    }
    offset += line.length + 1;
  }
  for (const lib of libraries) if (lib.ref) lib.version = versions.get(lib.ref)?.value;
  const refUses = (k: string) => masked.match(new RegExp(`\\bversion\\.ref\\s*=\\s*"${esc(k)}"`, 'g'))?.length ?? 0;
  return { versions, libraries, refUses };
}

// ---------------------------------------------------------------- declarations

const NOT_CONFIGURATIONS = new Set(['platform', 'enforcedPlatform', 'constraints', 'dependencies', 'if', 'for', 'while', 'def', 'val', 'var']);
const STATEMENT = /(?:^|[;{])[ \t]*([A-Za-z_]\w*)\b/gm;
const STRING_ARG = /[ \t]*(?:\([ \t]*)?(?:'([^'\n]*)'|"((?:\$\{[^}\n]*\}|[^"\n])*)")/dy;
const MAP_ARGS = /[ \t]*\(?[ \t]*((?:\w+[ \t]*[:=][ \t]*(?:'[^'\n]*'|"[^"\n]*"|[\w.]+)[ \t]*,?\s*)+)/dy;
const MAP_PAIR = /(\w+)[ \t]*([:=])[ \t]*(?:'([^'\n]*)'|"([^"\n]*)"|([\w.]+))/dg;
const CATALOG_ARG = /[ \t]*\(?[ \t]*libs\.([\w.]+)/y;

function scan(files: GradleFiles): Found[] {
  const masked = maskComments(files.build, 'gradle');
  const struct = structure(masked);
  const depths = braceDepths(struct);
  const ranges = blocks(struct, depths, 'dependencies', 0);
  const catalog = files.catalog !== undefined ? parseCatalog(files.catalog) : undefined;
  const found: Found[] = [];
  const property = (decl: Declaration, name: string): Declaration => ({ ...decl, versionSource: 'property', property: name, version: findProperty(files, masked, name)?.value });

  for (const m of masked.matchAll(STATEMENT)) {
    const confAt = m.index! + m[0].length - m[1].length;
    const configuration = m[1];
    if (NOT_CONFIGURATIONS.has(configuration) || depths[confAt] !== 1 || !ranges.some(([s, e]) => confAt >= s && confAt < e)) continue;
    const at = m.index! + m[0].length;
    const base = { configuration };

    STRING_ARG.lastIndex = at;
    const str = STRING_ARG.exec(masked);
    if (str) {
      const doubleQuoted = str[2] !== undefined;
      const content = str[1] ?? str[2];
      const contentStart = str.indices![doubleQuoted ? 2 : 1]![0];
      const [coords] = content.split('@');
      const [group, name, version] = coords.split(':');
      if (!group || !name) continue;
      let decl: Declaration = { group, name, ...base, form: 'string', versionSource: 'none' };
      let token: Span | undefined;
      if (version) {
        const start = contentStart + group.length + name.length + 2;
        token = { file: 'build', start, end: start + version.length };
        const prop = doubleQuoted ? version.match(PROPERTY_TOKEN) : null;
        decl = prop ? property(decl, prop[1] ?? prop[2] ?? prop[3]) : { ...decl, version, versionSource: 'literal' };
      }
      found.push({ decl, token });
      continue;
    }

    MAP_ARGS.lastIndex = at;
    const map = MAP_ARGS.exec(masked);
    if (map) {
      const pairs = new Map<string, { value: string; bare: boolean; span: Span }>();
      let separator = ':';
      for (const p of map[1].matchAll(MAP_PAIR)) {
        const g = p[3] !== undefined ? 3 : p[4] !== undefined ? 4 : 5;
        const start = map.indices![1]![0] + p.indices![g]![0];
        separator = p[2];
        pairs.set(p[1], { value: p[g], bare: g === 5, span: { file: 'build', start, end: start + p[g].length } });
      }
      const group = pairs.get('group');
      const name = pairs.get('name');
      if (!group || !name) continue;
      let decl: Declaration = { group: group.value, name: name.value, ...base, form: separator === ':' ? 'map' : 'named', versionSource: 'none' };
      const v = pairs.get('version');
      if (v) decl = v.bare ? property(decl, v.value) : { ...decl, version: v.value, versionSource: 'literal' };
      found.push({ decl, token: v?.span });
      continue;
    }

    CATALOG_ARG.lastIndex = at;
    const accessor = CATALOG_ARG.exec(masked)?.[1];
    if (!accessor || !catalog || /^(plugins|bundles|versions)\./.test(accessor)) continue;
    const lib = catalog.libraries.find(l => normAlias(l.alias) === normAlias(accessor));
    if (!lib) continue;
    const decl: Declaration = { group: lib.group, name: lib.name, ...base, form: 'catalog', versionSource: 'none', alias: lib.alias };
    if (lib.ref) found.push({ decl: { ...decl, version: lib.version, versionSource: 'catalog-ref', property: lib.ref }, lib });
    else if (lib.version) found.push({ decl: { ...decl, version: lib.version, versionSource: 'catalog-literal' }, lib });
    else found.push({ decl, lib });
  }
  return found;
}

export const findDeclarations = (files: GradleFiles): Declaration[] => scan(files).map(f => f.decl);

const matching = (files: GradleFiles, dep: { group: string; name: string }) => scan(files).filter(f => f.decl.group === dep.group && f.decl.name === dep.name);

export const hasExplicitVersion = (files: GradleFiles, dep: { group: string; name: string }): boolean =>
  matching(files, dep).some(f => f.decl.versionSource !== 'none');

// ---------------------------------------------------------------- editing

/** `covered`: every use of the declaration's property / catalog ref is being moved to this version, so its definition can change. */
function planEdit(files: GradleFiles, f: Found, version: string, covered: boolean): { edit: Edit; via: EditResult['via']; property?: string } {
  const { decl } = f;
  if (decl.versionSource === 'literal') return { edit: { ...f.token!, text: version }, via: 'literal' };
  if (decl.versionSource === 'property') {
    const masked = maskComments(files.build, 'gradle');
    const definition = findProperty(files, masked, decl.property!);
    if (definition && covered) return { edit: { ...definition.span, text: version }, via: 'property', property: decl.property };
    const quote = files.buildFile === 'build.gradle.kts' ? '"' : "'";
    const text = decl.form === 'string' ? version : `${quote}${version}${quote}`;
    return { edit: { ...f.token!, text }, via: 'property-inlined', property: decl.property };
  }
  const lib = f.lib!;
  if (decl.versionSource === 'catalog-literal') return { edit: { ...lib.versionSpan!, text: version }, via: 'catalog' };
  const key = parseCatalog(files.catalog!).versions.get(lib.ref!);
  if (key && covered) return { edit: { ...key.span, text: version }, via: 'catalog', property: lib.ref };
  return { edit: { ...lib.refSpan!, text: `version = "${version}"` }, via: 'property-inlined', property: lib.ref };
}

type DepOverride = { dep: { group: string; name: string }; version: string };

/**
 * Sets the versions of several direct dependencies at once. A property or catalog `version.ref` is changed at its
 * definition only when all its uses are among the overrides, at one version; otherwise each declaration is inlined.
 */
export function setDependencyVersions(files: GradleFiles, overrides: DepOverride[]): { files: GradleFiles; applied: { via: EditResult['via']; property?: string }[]; changed: FileKey[] } {
  const perOverride = overrides.map(({ dep, version }) => {
    const found = matching(files, dep);
    if (found.length === 0) throw new Error(`${dep.group}:${dep.name} not found in the top-level dependencies { } blocks`);
    const versioned = found.filter(f => f.decl.versionSource !== 'none');
    if (versioned.length === 0) throw new Error(`${dep.group}:${dep.name} has no version (managed by a platform/BOM)`);
    return versioned.map(f => ({ f, version }));
  });
  const keyOf = (f: Found) => (f.decl.versionSource === 'property' ? `property:${f.decl.property}` : f.decl.versionSource === 'catalog-ref' ? `catalog:${f.lib!.ref}` : undefined);
  const groups = new Map<string, { versions: Set<string>; users: Set<string> }>();
  for (const { f, version } of perOverride.flat()) {
    const key = keyOf(f);
    if (!key) continue;
    const g = groups.get(key) ?? { versions: new Set<string>(), users: new Set<string>() };
    g.versions.add(version);
    // a property use is one declaration (its token); a catalog ref use is one library entry
    g.users.add(key.startsWith('catalog:') ? f.lib!.alias : `${f.token!.file}:${f.token!.start}`);
    groups.set(key, g);
  }
  const masked = maskComments(files.build, 'gradle');
  const catalog = files.catalog !== undefined ? parseCatalog(files.catalog) : undefined;
  const covered = (key: string) => {
    const g = groups.get(key)!;
    const name = key.slice(key.indexOf(':') + 1);
    const uses = key.startsWith('property:') ? countUses(masked, name) : catalog?.refUses(name) ?? 0;
    return g.versions.size === 1 && g.users.size === uses;
  };
  const plans = perOverride.map(list => list.map(({ f, version }) => planEdit(files, f, version, keyOf(f) ? covered(keyOf(f)!) : false)));
  const edits = plans.flat().map(p => p.edit).filter((e, i, all) => all.findIndex(o => o.file === e.file && o.start === e.start) === i);
  const out: GradleFiles = { ...files };
  const changed: FileKey[] = [];
  for (const file of ['build', 'properties', 'catalog'] as const) {
    const mine = edits.filter(e => e.file === file).sort((a, b) => b.start - a.start);
    if (mine.length === 0) continue;
    let text = out[file]!;
    for (const e of mine) text = text.slice(0, e.start) + e.text + text.slice(e.end);
    out[file] = text;
    changed.push(file);
  }
  const applied = plans.map(list => ({ via: list[0].via, ...(list[0].property !== undefined && { property: list[0].property }) }));
  return { files: out, applied, changed };
}

export function setDependencyVersion(files: GradleFiles, dep: { group: string; name: string }, version: string): EditResult {
  const r = setDependencyVersions(files, [{ dep, version }]);
  return { files: r.files, ...r.applied[0], changed: r.changed };
}

export function detectJavaVersion(build: string): string {
  const masked = maskComments(build, 'gradle');
  const toolchain = masked.match(/JavaLanguageVersion\.of\(\s*(\d+)\s*\)/);
  if (toolchain) return toolchain[1];
  const constant = masked.match(/JavaVersion\.VERSION_(\d+)(?:_(\d+))?/);
  if (constant) return constant[1] === '1' && constant[2] ? constant[2] : constant[1];
  const compat = masked.match(/\bsourceCompatibility\s*=\s*['"]?(?:1\.(\d+)|(\d+))/);
  if (compat) return compat[1] ?? compat[2];
  const release = masked.match(/\brelease(?:\.set\(\s*|\s*=\s*)(\d+)/);
  if (release) return release[1];
  return '17';
}
