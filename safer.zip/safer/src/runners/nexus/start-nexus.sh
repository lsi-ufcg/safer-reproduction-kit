#!/bin/bash
# Starts (or reuses) a local Nexus used as a cache/proxy of Maven Central.
# The container and its volume persist between Safer runs, so the cache is kept.

container_name="nexus-safer"
volume_name="nexus-safer-data"
NEXUS_PORT=8081  # keep in sync with settings.xml
NEXUS_URL="http://localhost:${NEXUS_PORT}"
TIMEOUT=${NEXUS_START_TIMEOUT:-300}

is_up() {
    [ "$(curl -s -o /dev/null -w '%{http_code}' "${NEXUS_URL}/service/rest/v1/status/writable")" = "200" ]
}

if ! is_up; then
    if [ -n "$(docker ps -aq -f name=^${container_name}$)" ]; then
        echo "Starting existing Nexus container..."
        docker start ${container_name} > /dev/null || exit 1
    else
        echo "Creating Nexus container (first run may take a few minutes)..."
        docker run -d --name ${container_name} \
            -p ${NEXUS_PORT}:8081 \
            -v ${volume_name}:/nexus-data \
            -e INSTALL4J_ADD_VM_PARAMS="-Xms1g -Xmx1g -XX:MaxDirectMemorySize=1g -Djava.util.prefs.userRoot=/nexus-data/javaprefs" \
            --restart unless-stopped \
            sonatype/nexus3 > /dev/null || exit 1
    fi

    echo "Waiting for Nexus to be ready..."
    elapsed=0
    until is_up; do
        if [ $elapsed -ge $TIMEOUT ]; then
            echo "Nexus did not become ready within ${TIMEOUT}s."
            exit 1
        fi
        sleep 5
        elapsed=$((elapsed + 5))
    done
fi

# Initial setup (idempotent): while the initial admin password exists, make sure anonymous
# access is on and the EULA is accepted, so Maven can download without credentials.
admin_password=$(docker exec ${container_name} cat /nexus-data/admin.password 2>/dev/null)
if [ -n "$admin_password" ]; then
    curl -s -o /dev/null -u "admin:${admin_password}" -X PUT \
        -H "Content-Type: application/json" \
        -d '{"enabled": true, "userId": "anonymous", "realmName": "NexusAuthorizingRealm"}' \
        "${NEXUS_URL}/service/rest/v1/security/anonymous"

    # Nexus Community Edition serves artifacts only after its EULA is accepted
    # (https://links.sonatype.com/products/nxrm/ce-eula).
    eula=$(curl -s -u "admin:${admin_password}" "${NEXUS_URL}/service/rest/v1/system/eula")
    if echo "$eula" | grep -q '"accepted" *: *false'; then
        echo "Accepting Nexus Community Edition EULA..."
        echo "$eula" | sed 's/"accepted" *: *false/"accepted" : true/' | \
            curl -s -o /dev/null -u "admin:${admin_password}" -X POST \
                -H "Content-Type: application/json" --data-binary @- \
                "${NEXUS_URL}/service/rest/v1/system/eula"
    fi
fi

echo "Nexus ready at ${NEXUS_URL}"
