#!/bin/bash
# $1 = container-absolute runtime classpath (the tool classes dir first: target/classes or build/classes/java/main), $2 = time limit (s),
# $3 = this run's Safer container
CLASS_PATH=$1
TIME_LIMIT=$2
CONTAINER=${3:-java-container-safer}
set -e
docker exec "$CONTAINER" java -classpath "${CLASS_PATH}:/app/randoop-all-4.3.2.jar" randoop.main.Main gentests \
  --classlist=/app/myclasses.txt --no-error-revealing-tests=true --time-limit=${TIME_LIMIT} --junit-output-dir=/app/randoopTests
docker exec "$CONTAINER" sh -c "javac -cp '${CLASS_PATH}:/app/randoopTests:/app/junit-4.13.2.jar' /app/randoopTests/*.java"
