#!/bin/bash

CLASS_PATH=$1
TIME_LIMIT=$2

echo "Construindo imagem Docker para os testes Randoop"
echo "Class path: $CLASS_PATH"
echo "Time limit: $TIME_LIMIT"

docker exec java-container-safer java -classpath /app/${CLASS_PATH}:/app/randoop-all-4.3.2.jar randoop.main.Main gentests --classlist=myclasses.txt  --no-error-revealing-tests=true --time-limit=${TIME_LIMIT} --junit-output-dir="/app/randoopTests"
docker exec java-container-safer sh -c "javac -cp '$CLASS_PATH:randoopTests:junit-4.13.2.jar' randoopTests/*.java"
