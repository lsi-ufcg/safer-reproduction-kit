#!/bin/bash

CLASS_PATH=$1

echo "Class path: $CLASS_PATH"

docker exec java-container-safer java -cp "${CLASS_PATH}:junit-4.13.2.jar:hamcrest-core-1.3.jar:randoopTests" org.junit.runner.JUnitCore RegressionTest
