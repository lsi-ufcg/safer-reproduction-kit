#!/bin/bash
# $1 = container-absolute runtime classpath of the candidate, $2 = this run's Safer container
CLASS_PATH=$1
CONTAINER=${2:-java-container-safer}
docker exec "$CONTAINER" java -cp "${CLASS_PATH}:/app/junit-4.13.2.jar:/app/hamcrest-core-1.3.jar:/app/randoopTests" org.junit.runner.JUnitCore RegressionTest
