#!/bin/bash

container_name="java-container-safer"
directory="randoopTests"

container_exists=$(docker ps -aq -f name=^${container_name}$)
if [ ! -z "$container_exists" ]; then
    echo "Attempting to delete Randoop test files..."
    docker exec ${container_name} sh -c "rm -rf ${directory} || echo 'Directory ${directory} not found, nothing to delete.'"
else
    echo "Container ${container_name} does not exist, cannot delete ${directory}, if it exists."
fi
