import fs from 'fs';
import path from 'path';

import { RandoopHooks } from '../../core/update-planner';
import { CONTAINER, firstError, runHost } from '../container';
import { copyRandoopFilesToProject, deleteRandoopFiles, generateClassList } from './randoop-scripts';

export type RandoopHookOptions = {
  projectPath: string;
  saferRoot: string;
  timeLimitSec: number;
  /** Compiled main classes relative to the project root (BuildTool.classesDir()); Randoop tests every class in it. */
  classesDir: string;
  runHost?: typeof runHost; // injectable for tests
};

export function makeRandoopHooks(opts: RandoopHookOptions): RandoopHooks {
  const host = opts.runHost ?? runHost;
  const script = (name: string) => path.join(opts.saferRoot, 'src/runners/randoop', name);
  const step = async (command: string, logFile: string) => {
    fs.mkdirSync(path.dirname(logFile), { recursive: true });
    const started = Date.now();
    const code = await host(command, { cwd: opts.projectPath, logFile });
    const log = fs.readFileSync(logFile, 'utf8');
    const failed = code !== 0 || /^FAILURES!!!/m.test(log);
    return { ok: !failed, logFile, durationMs: Date.now() - started, firstError: failed ? firstError(log) ?? log.match(/^Tests run: .*Failures: \d+.*$/m)?.[0] ?? `exit ${code}` : undefined };
  };
  return {
    generate: async (classpath, logFile) => {
      generateClassList(opts.projectPath, opts.classesDir);
      copyRandoopFilesToProject(opts.projectPath, opts.saferRoot);
      return step(`${script('generate-randoop-tests.sh')} '${classpath}' ${opts.timeLimitSec} ${CONTAINER}`, logFile);
    },
    run: (classpath, logFile) => step(`${script('run-randoop-tests.sh')} '${classpath}' ${CONTAINER}`, logFile),
    cleanup: async () => {
      deleteRandoopFiles(opts.projectPath);
    },
  };
}
