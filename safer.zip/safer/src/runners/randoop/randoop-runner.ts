import { ExploratoryTestingParamsType, ProjectType } from '#types/config';

import { constants } from '../../utils/contants';
import { copyRandoopFilesToProject, deleteRandoopFiles, generateClassListMaven } from './randoop-scripts';
import execCommand from '../../utils/execCommand';

export const RandoopRunner = {
  generateRandoopTests: (exporatoryTestingParams: ExploratoryTestingParamsType, projectAbsolutePath: string, projectType: ProjectType, dependencyClasspath: string) => {
    generateClassListMaven(projectAbsolutePath);
    copyRandoopFilesToProject(projectAbsolutePath);
    execCommand(`./src/runners/randoop/generate-randoop-tests.sh '${constants.getClassPath[projectType]}:${dependencyClasspath}' ${exporatoryTestingParams.timeLimitGeneratingTests}`);
  },
  runRandoopTests: (projectType: ProjectType, dependencyClasspath: string) => {
    execCommand(`./src/runners/randoop/run-randoop-tests.sh ${constants.getClassPath[projectType]}:${dependencyClasspath}`);
  },
  deleteRandoopFiles: (projectAbsolutePath: string) => {
    deleteRandoopFiles(projectAbsolutePath);
    execCommand(`./src/runners/randoop/delete-randoop-tests.sh`);
  },
};
