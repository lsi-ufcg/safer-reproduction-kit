import fs from 'fs';
import os from 'os';
import path from 'path';

import { describe, expect, it } from 'vitest';

import { makeRandoopHooks } from './randoop-runner';
import { generateClassList } from './randoop-scripts';

const saferRoot = path.resolve(__dirname, '../../..');

const projectWithClasses = (classesDir: string) => {
  const project = fs.mkdtempSync(path.join(os.tmpdir(), 'safer-randoop-'));
  fs.mkdirSync(path.join(project, classesDir, 'com/acme/util'), { recursive: true });
  fs.writeFileSync(path.join(project, classesDir, 'com/acme/App.class'), '');
  fs.writeFileSync(path.join(project, classesDir, 'com/acme/util/Strings.class'), '');
  fs.writeFileSync(path.join(project, classesDir, 'com/acme/util/notes.txt'), '');
  return project;
};

describe('Randoop class list', () => {
  it('generateClassList lists the classes under the given classes dir', () => {
    const project = projectWithClasses('build/classes/java/main');
    generateClassList(project, 'build/classes/java/main');
    const list = fs.readFileSync(path.join(project, 'myclasses.txt'), 'utf8').split('\n').sort();
    expect(list).toEqual(['com.acme.App', 'com.acme.util.Strings']);
  });

  it('the generate hook builds the class list from the tool classesDir', async () => {
    const project = projectWithClasses('build/classes/java/main');
    let classList = '';
    const commands: string[] = [];
    const hooks = makeRandoopHooks({
      projectPath: project,
      saferRoot,
      timeLimitSec: 5,
      classesDir: 'build/classes/java/main',
      runHost: async (command, opts) => {
        commands.push(command);
        classList = fs.readFileSync(path.join(project, 'myclasses.txt'), 'utf8');
        fs.writeFileSync(opts.logFile, 'OK (3 tests)\n');
        return 0;
      },
    });
    const r = await hooks.generate('/app/build/classes/java/main:/tmp/.gradle/x.jar', path.join(project, 'logs', 'gen.log'));
    expect(r.ok).toBe(true);
    expect(classList.split('\n').sort()).toEqual(['com.acme.App', 'com.acme.util.Strings']);
    expect(commands[0]).toContain("'/app/build/classes/java/main:/tmp/.gradle/x.jar' 5");
    await hooks.cleanup();
    expect(fs.existsSync(path.join(project, 'myclasses.txt'))).toBe(false);
    expect(fs.existsSync(path.join(project, 'randoop-all-4.3.2.jar'))).toBe(false);
  });
});
