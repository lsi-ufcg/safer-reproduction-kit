import fs from 'fs';
import * as path from 'path';

import { constants } from '../../utils/contants';
import loggerSync from '../../utils/logger';

function getClassFiles(directory: string, fileList: string[] = []): string[] {
  const files = fs.readdirSync(directory);
  files.forEach(file => {
    const absolutePath = path.join(directory, file);
    if (fs.statSync(absolutePath).isDirectory()) {
      getClassFiles(absolutePath, fileList);
    } else if (file.endsWith('.class')) {
      fileList.push(absolutePath);
    }
  });
  return fileList;
}

function toJavaClassName(classFilePath: string, baseDirectory: string): string {
  return classFilePath
    .substring(baseDirectory.length + path.sep.length)
    .replace(new RegExp(`\\${path.sep}`, 'g'), '.')
    .replace('.class', '');
}

export function generateClassListMaven(mavenProjectDirectory: string): void {
  const outputFile = path.join(mavenProjectDirectory, 'myclasses.txt');
  if (fs.existsSync(outputFile)) {
    loggerSync({
      level: 'info',
      message: `${outputFile} already exists. No new file generated.`,
    });
    return;
  }
  const targetDir = path.join(mavenProjectDirectory, 'target', 'classes');
  const classFiles = getClassFiles(targetDir);
  const classListText = classFiles.map(file => toJavaClassName(file, targetDir)).join('\n');
  fs.writeFileSync(outputFile, classListText);
  loggerSync({
    level: 'info',
    message: `${outputFile} has been generated.`,
  });
}

export function copyRandoopFilesToProject(mavenProjectDirectory: string): void {
  const filesToCopy = constants.randoopCommonFiles;

  filesToCopy.forEach(file => {
    const origin = `src/runners/randoop/files/${file}`;
    const destination = path.join(mavenProjectDirectory, path.basename(file));
    fs.copyFileSync(origin, destination);
    loggerSync({
      level: 'info',
      message: `Copied ${origin} to ${destination}`,
    });
  });
}

export function deleteRandoopFiles(mavenProjectDirectory: string): void {
  const filesToDelete = [...constants.randoopCommonFiles, 'myclasses.txt', 'DependencyClasspath.txt'];

  filesToDelete.forEach(file => {
    const filePath = path.join(mavenProjectDirectory, file);
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
      loggerSync({
        level: 'info',
        message: `Removed ${filePath}`,
      });
    }
  });

  const randoopTestsDir = path.join(mavenProjectDirectory, 'randoopTests');
  if (fs.existsSync(randoopTestsDir)) {
    fs.rmSync(randoopTestsDir, { recursive: true, force: true });
    loggerSync({
      level: 'info',
      message: `Removed directory ${randoopTestsDir}`,
    });
  }
}
