import fs from 'fs';
import * as path from 'path';

import { constants } from '../../utils/contants';

function getClassFiles(directory: string, fileList: string[] = []): string[] {
  const files = fs.readdirSync(directory);
  files.forEach(file => {
    const absolutePath = path.join(directory, file);
    if (fs.statSync(absolutePath).isDirectory()) {
      getClassFiles(absolutePath, fileList);
    } else if (file.endsWith('.class')) {
      fileList.push(absolutePath);
    }
  });
  return fileList;
}

function toJavaClassName(classFilePath: string, baseDirectory: string): string {
  return classFilePath
    .substring(baseDirectory.length + path.sep.length)
    .replace(new RegExp(`\\${path.sep}`, 'g'), '.')
    .replace(/\.class$/, '');
}

/** Writes myclasses.txt (one fully qualified class per line) from the compiled classes under `classesDir` (relative to the project). */
export function generateClassList(projectDirectory: string, classesDir: string): void {
  const outputFile = path.join(projectDirectory, 'myclasses.txt');
  const targetDir = path.join(projectDirectory, classesDir);
  const classFiles = getClassFiles(targetDir);
  const classListText = classFiles.map(file => toJavaClassName(file, targetDir)).join('\n');
  fs.writeFileSync(outputFile, classListText);
}

export function copyRandoopFilesToProject(projectDirectory: string, saferRoot = process.env.SAFER_ROOT_PATH ?? path.resolve('..')): void {
  const filesToCopy = constants.randoopCommonFiles;

  filesToCopy.forEach(file => {
    const origin = path.join(saferRoot, 'src/runners/randoop/files', file);
    const destination = path.join(projectDirectory, path.basename(file));
    fs.copyFileSync(origin, destination);
  });
}

export function deleteRandoopFiles(projectDirectory: string): void {
  const filesToDelete = [...constants.randoopCommonFiles, 'myclasses.txt', 'DependencyClasspath.txt'];

  filesToDelete.forEach(file => {
    const filePath = path.join(projectDirectory, file);
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }
  });

  const randoopTestsDir = path.join(projectDirectory, 'randoopTests');
  if (fs.existsSync(randoopTestsDir)) {
    fs.rmSync(randoopTestsDir, { recursive: true, force: true });
  }
}
