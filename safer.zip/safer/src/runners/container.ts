import { spawn } from 'child_process';
import fs from 'fs';

/** Prefix of every Safer build container; the suffix is the Safer process id, so concurrent runs never share one. */
export const CONTAINER_PREFIX = 'java-container-safer';
export const CONTAINER = `${CONTAINER_PREFIX}-${process.pid}`;

export type ExecResult = { code: number; stdout: string; durationMs: number };
export type ContainerExec = (args: string[], opts?: { env?: Record<string, string>; logFile?: string; timeoutMs?: number }) => Promise<ExecResult>;

const NOISE = [/^\s*$/, /COMPILATION ERROR\s*:?\s*$/, /^-> \[Help/, /^To see the full stack trace/, /^Re-run Maven/, /^For more information/, /^\[Help \d\]/, /^After correcting the problems/, /^\s*mvn <args>/];

/** First [ERROR] line that says something specific (compiler message, failing test, missing artifact). */
export function firstError(log: string): string | undefined {
  for (const line of log.split('\n')) {
    const m = line.match(/^\[ERROR\]\s?(.*)$/);
    if (!m) continue;
    const msg = m[1].trim();
    if (NOISE.some(re => re.test(msg))) continue;
    return msg.length > 400 ? `${msg.slice(0, 400)}…` : msg;
  }
  return undefined;
}

const clip = (msg: string) => (msg.length > 400 ? `${msg.slice(0, 400)}…` : msg);

/**
 * Most specific failure in a Gradle log: the first javac error, else the first failing test
 * (`<Class> > <method> FAILED` plus its exception line), else the `* What went wrong:` line with its deepest `> cause`.
 */
export function gradleFirstError(log: string): string | undefined {
  const lines = log.split('\n').map(l => l.replace(/\r$/, ''));
  // an OOM kill of the test worker or the daemon is reported by Gradle as an ordinary failure (the client exits 1)
  const oom = lines.find(l => /Process 'Gradle Test Executor \d+' finished with non-zero exit value 137|Gradle build daemon disappeared unexpectedly/.test(l));
  if (oom) return clip(`killed (likely out of memory): ${oom.trim()}`);
  const javac = lines.find(l => /^\S.*\.(java|kt):\d+: error: /.test(l));
  if (javac) return clip(javac.trim());
  const test = lines.findIndex(l => /^\S.* > .+ FAILED$/.test(l));
  if (test >= 0) {
    const cause = lines[test + 1]?.match(/^\s+(\S.*)$/)?.[1];
    return clip(cause ? `${lines[test]}: ${cause.trim()}` : lines[test]);
  }
  const wrong = lines.findIndex(l => l.startsWith('* What went wrong:'));
  if (wrong >= 0 && lines[wrong + 1]?.trim()) {
    let cause: string | undefined;
    for (let k = wrong + 2; k < lines.length && /^\s*> /.test(lines[k]); k++) cause = lines[k].trim();
    return clip(cause ? `${lines[wrong + 1].trim()} ${cause}` : lines[wrong + 1].trim());
  }
  return undefined;
}

/**
 * Wraps an in-container command in coreutils `timeout -s KILL`, so the JVM itself is killed (killing the
 * docker client would leave it running). The docker client gets a backstop a minute later.
 */
export const withTimeout = (sec: number, args: string[]) => ({ args: ['timeout', '-s', 'KILL', String(sec), ...args], timeoutMs: (sec + 60) * 1000 });

/** GNU timeout exits 124 (or 137 with -s KILL) when the limit is hit; a 137 well before the limit is another SIGKILL (e.g. OOM). */
export const timedOut = (code: number, durationMs: number, sec: number) => code === 124 || (code === 137 && durationMs >= (sec - 5) * 1000);
export const killedEarly = (code: number) => (code === 137 ? 'killed (exit 137, likely out of memory)' : undefined);

/** `docker exec` in the Safer container. Output goes to logFile (if given) and is returned in full only without one. */
export function dockerExec(container = CONTAINER): ContainerExec {
  return (args, opts = {}) =>
    new Promise((resolve, reject) => {
      const envFlags = Object.entries(opts.env ?? {}).flatMap(([k, v]) => ['-e', `${k}=${v}`]);
      const started = Date.now();
      const child = spawn('docker', ['exec', ...envFlags, container, ...args], { stdio: ['ignore', 'pipe', 'pipe'] });
      const sink = opts.logFile ? fs.createWriteStream(opts.logFile) : null;
      let stdout = '';
      const onData = (chunk: Buffer) => {
        sink?.write(chunk);
        if (!sink) stdout += chunk.toString();
      };
      child.stdout.on('data', onData);
      child.stderr.on('data', onData);
      const timer = opts.timeoutMs ? setTimeout(() => child.kill('SIGKILL'), opts.timeoutMs) : null;
      child.on('error', reject);
      child.on('close', code => {
        if (timer) clearTimeout(timer);
        const done = () => resolve({ code: code ?? -1, stdout, durationMs: Date.now() - started });
        if (sink) sink.end(done);
        else done();
      });
    });
}

/** Runs a host shell command with all output in logFile; resolves on process exit (background children may keep the file open). */
export function runHost(command: string, opts: { cwd: string; logFile: string; env?: NodeJS.ProcessEnv }): Promise<number> {
  return new Promise((resolve, reject) => {
    const fd = fs.openSync(opts.logFile, 'a');
    const child = spawn('bash', ['-c', command], { cwd: opts.cwd, env: opts.env ?? process.env, stdio: ['ignore', fd, fd] });
    child.on('error', err => {
      fs.closeSync(fd);
      reject(err);
    });
    child.on('exit', code => {
      fs.closeSync(fd);
      resolve(code ?? -1);
    });
  });
}
