import { describe, expect, it } from 'vitest';

import { gradleFirstError } from './container';

describe('gradleFirstError', () => {
  it('reports the first javac error before the generic "What went wrong"', () => {
    const log = [
      '> Task :compileJava FAILED',
      '/app/src/main/java/br/A.java:10: error: cannot find symbol',
      '        Foo x;',
      '        ^',
      '  symbol:   class Foo',
      '1 error',
      '',
      'FAILURE: Build failed with an exception.',
      '',
      '* What went wrong:',
      "Execution failed for task ':compileJava'.",
      '> Compilation failed; see the compiler error output for details.',
    ].join('\n');
    expect(gradleFirstError(log)).toBe('/app/src/main/java/br/A.java:10: error: cannot find symbol');
  });
  it('reports the first failing test with its exception line', () => {
    const log = [
      '> Task :test',
      '',
      'br.com.FooTest > testBar FAILED',
      '    org.opentest4j.AssertionFailedError at FooTest.java:12',
      '',
      'br.com.FooTest > testBaz FAILED',
      '    java.lang.NullPointerException at FooTest.java:20',
      '',
      '2 tests completed, 2 failed',
      '',
      '> Task :test FAILED',
      '',
      'FAILURE: Build failed with an exception.',
      '',
      '* What went wrong:',
      "Execution failed for task ':test'.",
      '> There were failing tests. See the report at: file:///app/build/reports/tests/test/index.html',
    ].join('\n');
    expect(gradleFirstError(log)).toBe('br.com.FooTest > testBar FAILED: org.opentest4j.AssertionFailedError at FooTest.java:12');
  });
  it('reports "What went wrong" with its most specific cause', () => {
    const log = [
      '> Task :saferDeps FAILED',
      '',
      'FAILURE: Build failed with an exception.',
      '',
      '* What went wrong:',
      "Execution failed for task ':saferDeps'.",
      '> Unresolved runtimeClasspath dependencies (2): io.minio:minio:99.0 (Could not find io.minio:minio:99.0.); g:gone:1.0 (Could not resolve g:gone:1.0.)',
      '',
      '* Try:',
    ].join('\n');
    expect(gradleFirstError(log)).toBe(
      "Execution failed for task ':saferDeps'. > Unresolved runtimeClasspath dependencies (2): io.minio:minio:99.0 (Could not find io.minio:minio:99.0.); g:gone:1.0 (Could not resolve g:gone:1.0.)",
    );
    // a nested cause (e.g. saferClasspath resolving files): the deepest "> " line is the specific one
    const nested = "* What went wrong:\nExecution failed for task ':saferClasspath'.\n> Could not resolve all files for configuration ':runtimeClasspath'.\n   > Could not find io.minio:minio:99.0.\n     Required by:\n";
    expect(gradleFirstError(nested)).toBe("Execution failed for task ':saferClasspath'. > Could not find io.minio:minio:99.0.");
    expect(gradleFirstError("* What went wrong:\nA problem occurred evaluating root project 'x'.\n")).toBe("A problem occurred evaluating root project 'x'.");
  });
  it('maps an OOM-killed test worker or daemon to "killed (likely out of memory)"', () => {
    const worker = "* What went wrong:\nExecution failed for task ':test'.\n> Process 'Gradle Test Executor 3' finished with non-zero exit value 137\n";
    expect(gradleFirstError(worker)).toBe("killed (likely out of memory): > Process 'Gradle Test Executor 3' finished with non-zero exit value 137");
    const daemon = 'Gradle build daemon disappeared unexpectedly (it may have been killed or may have crashed)\n';
    expect(gradleFirstError(daemon)).toBe('killed (likely out of memory): Gradle build daemon disappeared unexpectedly (it may have been killed or may have crashed)');
  });
  it('undefined when the build succeeded', () => expect(gradleFirstError('> Task :build\n\nBUILD SUCCESSFUL in 3s\n')).toBeUndefined());
});
