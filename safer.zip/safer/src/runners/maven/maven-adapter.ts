import { exec } from 'child_process';
import { promisify } from 'util';
import * as fs from 'fs';
import * as path from 'path';

const execAsync = promisify(exec);

import convert from 'xml-js';

import { SEMANTIC_VERSIONING_REGEX } from '#regex/regex';
import { Dependencies, Dependency } from '#types/models';
import { PomJs, XmlElement } from '#types/xml-js';

export const MavenAdapter = {
  getFromPomXml: (pomXml: string): { javaVersion: string; dependencies: Dependencies } => {
    const pomJs = convert.xml2js(pomXml, { compact: true }) as PomJs;

    return {
      javaVersion: pomJs.project.properties['java.version']._text,
      dependencies: MavenAdapter._getDependencies(pomXml),
    };
  },
  async getFromMvn(projectPath: string): Promise<{ javaVersion: string; dependencies: Dependency[] }> {
    const pomString = (await MavenAdapter._execMvnCommand("mvn help:effective-pom | sed -n '/<project /,/<\\/project>/p'", projectPath)).trim();
    const javaVersion = await MavenAdapter._getJavaVersion(pomString);

    const dependenciesOutput = await MavenAdapter._execMvnCommand('mvn dependency:list -DexcludeTransitive=true', projectPath);
    const lines = dependenciesOutput.split('\n');
    // eslint-disable-next-line no-useless-escape
    const regex = /([\w\.-]+):([\w\.-]+):(jar|maven-plugin|war|ear|pom):([\w\.-]+)(?::([\w\.-]+))?:(\w+)/;
    const dependencies = lines
      .filter(line => regex.test(line))
      .map(line => {
        const match = line.match(regex);
        return match ? { group: match[1], name: match[2], version: match[4] } : { group: 'unknown', name: 'unknown', version: 'unknown' };
      });

    return { javaVersion, dependencies };
  },
  _getJavaVersion: async (pomString: string): Promise<string> => {
    let pomJs: XmlElement;
    try {
      pomJs = convert.xml2js(pomString, { compact: false }) as XmlElement;
    } catch (err) {
      if (err instanceof Error) {
        if (err.message.includes('Text data outside of root node')) {
          console.error(`Error trying to retrieve Java version, likely due to multiple projects found in the pom. Check the absolute path to the project: ${err.message}`);
          process.exit(1);
        }
      }

      console.error(`Error trying to retrieve Java version: ${err}`);
      process.exit(1);
    }

    let javaVersion = MavenAdapter._extractVersionFromProperties(pomString);
    if (!javaVersion) {
      javaVersion = await MavenAdapter._extractVersionFromPlugin(pomJs);
    }
    return MavenAdapter._identifyJavaVersion(javaVersion);
  },
  _extractVersionFromProperties: (pomString: string): string | null => {
    const targetMatch = pomString.match(/<maven\.compiler\.target>([\d.]+)<\/maven\.compiler\.target>/);
    if (targetMatch) return targetMatch[1];

    const sourceMatch = pomString.match(/<maven\.compiler\.source>([\d.]+)<\/maven\.compiler\.source>/);
    if (sourceMatch) return sourceMatch[1];

    return null;
  },
  _extractVersionFromPlugin: async (pomJs: XmlElement): Promise<string | null> => {
    const projectElement = pomJs.elements?.find(e => e.name === 'project');
    const buildElement = projectElement?.elements?.find(e => e.name === 'build');
    const pluginsElement = buildElement?.elements?.find(e => e.name === 'plugins');
    if (!pluginsElement || !pluginsElement.elements) return null;
    for (const plugin of pluginsElement.elements) {
      const artifactIdElement = plugin.elements?.find(e => e.name === 'artifactId');
      const artifactId = artifactIdElement?.elements?.find(e => e.text === 'maven-compiler-plugin');
      if (artifactId) {
        const configuration = plugin.elements?.find(e => e.name === 'configuration')?.elements;
        if (!configuration) continue;
        const targetElement = configuration.find(e => e.name === 'target')?.elements;
        const targetValue = targetElement?.[0].text;
        if (targetValue) return targetValue;
      }
    }
    return null;
  },
  _identifyJavaVersion: (javaVersion: string | null): string => {
    if (javaVersion === null) {
      return '17';
    }
    const match = javaVersion.match(/^1\.(\d+)$/) || javaVersion.match(/^(\d+)$/);
    if (match && match[1]) {
      return match[1];
    }
    console.error(`Java version not identified: '${javaVersion}'`);
    process.exit(1);
  },
  async _execMvnCommand(command: string, projectPath: string): Promise<string> {
    try {
      const { stdout } = await execAsync(command, { cwd: projectPath, maxBuffer: 1024 * 1024 * 30 });
      return stdout;
    } catch (err) {
      console.error(`Error executing mvn command '${command}': ${err}`);
      process.exit(1);
    }
  },
  _getDependencies: (pomXml: string): Dependencies => {
    const pomJs = convert.xml2js(pomXml, { compact: true }) as PomJs;
    const { dependency: allDependencies } = pomJs.project.dependencies;
    const parentDependency = pomJs.project.parent;

    const standardDependencies = allDependencies
      .filter(dependency => {
        if (dependency.version) {
          return SEMANTIC_VERSIONING_REGEX.test(dependency.version._text);
        }
        return false;
      })
      .map(dependency => ({
        group: dependency.groupId._text,
        name: dependency.artifactId._text,
        version: dependency.version!._text,
      }));

    return {
      parent: {
        group: parentDependency.groupId._text,
        name: parentDependency.artifactId._text,
        version: parentDependency.version!._text,
      },
      standard: standardDependencies,
    };
  },
  getPomXmlReplacedDependencyVersion: (currentPomXml: string, dependency: Dependency, newVersion: string) => {
    const pomJs = convert.xml2js(currentPomXml, { compact: true }) as PomJs;
    const newPomJsDependency = pomJs.project.dependencies.dependency.map(pomDependency => {
      if (pomDependency.artifactId._text === dependency.name) {
        return {
          ...pomDependency,
          version: {
            _text: newVersion,
          },
        };
      }
      return pomDependency;
    });

    pomJs.project.dependencies.dependency = newPomJsDependency;
    const newPomXml = convert.js2xml(pomJs, { compact: true });
    return newPomXml;
  },
  async getClassPathFromMvn(projectPath: string): Promise<{ dependencyClasspath: string }> {
    const classPathString = (
      await MavenAdapter._execMvnCommand(
        'mvn dependency:build-classpath -Dmdep.outputFile=DependencyClasspath.txt > /dev/null 2>&1; cat DependencyClasspath.txt | sed "s|/home/$USER|/root|g"',
        projectPath,
      )
    ).trim();
    return { dependencyClasspath: classPathString };
  },

  hasTests(projectPath: string): boolean {
    const testDir = path.join(projectPath, 'src', 'test', 'java');

    function containsJavaTestFile(dir: string): boolean {
      if (!fs.existsSync(dir)) return false;

      const items = fs.readdirSync(dir);
      for (const item of items) {
        const fullPath = path.join(dir, item);
        const stat = fs.statSync(fullPath);

        if (stat.isDirectory()) {
          if (containsJavaTestFile(fullPath)) return true;
        } else if (item.endsWith('.java')) {
          const content = fs.readFileSync(fullPath, 'utf-8');
          if (content.includes('@Test')) return true;
        }
      }
      return false;
    }

    return containsJavaTestFile(testDir);
  },
};
