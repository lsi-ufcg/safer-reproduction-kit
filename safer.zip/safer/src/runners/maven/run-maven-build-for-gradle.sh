#!/bin/bash
docker exec java-container-safer mvn clean install -DskipTests=true