#!/bin/bash
docker exec java-container-safer mvn clean install -U -DskipTests=true