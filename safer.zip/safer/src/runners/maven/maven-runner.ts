import execCommand from '../../utils/execCommand';

import * as path from 'path';
import * as dotenv from 'dotenv';

dotenv.config({
    path: path.resolve('.', '../../../.env'),
});
const saferPath = process.env.SAFER_ROOT_PATH;


export const MavenRunner = {
  runMavenBuild: (projectTests: boolean, { verbose }: { verbose: boolean }) => {
    execCommand(`${saferPath}/src/runners/maven/run-maven-build.sh ${!projectTests} ${verbose}`);
  },
};
