#!/bin/bash

PROJECT_TESTS=$1
PROJECT_PATH=$2
VERBOSE=$3
container_name="java-container-safer-$(basename $PROJECT_PATH)"


if [ $VERBOSE = "true" ]; then
    docker exec $container_name mvn clean install -DskipTests=${PROJECT_TESTS} -Dmaven.test.skip=${PROJECT_TESTS} -Ddependency-check.skip=true
else
    docker exec $container_name mvn clean install -DskipTests=${PROJECT_TESTS} -Dmaven.test.skip=${PROJECT_TESTS} -Ddependency-check.skip=true > /dev/null
fi


