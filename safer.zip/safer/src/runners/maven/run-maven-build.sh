#!/bin/bash

PROJECT_TESTS=$1
VERBOSE=$2

if [ $VERBOSE = "true" ]; then
    docker exec java-container-safer mvn clean install -DskipTests=${PROJECT_TESTS} -Dmaven.test.skip=${PROJECT_TESTS} -Ddependency-check.skip=true
else
    docker exec java-container-safer mvn clean install -DskipTests=${PROJECT_TESTS} -Dmaven.test.skip=${PROJECT_TESTS} -Ddependency-check.skip=true > /dev/null
fi


