import { Gav } from '../../core/model';

export type PomDependencyBlock = { group: string; name: string; text: string; start: number; end: number; version?: string };

const BLOCK = /<dependency>(?:(?!<\/dependency>)[\s\S])*<\/dependency>/g;
const EXCLUDED_SECTIONS = [/<dependencyManagement>[\s\S]*?<\/dependencyManagement>/g, /<plugin>[\s\S]*?<\/plugin>/g, /<profiles>[\s\S]*?<\/profiles>/g];

const tag = (text: string, name: string): string | undefined => text.match(new RegExp(`<${name}>\\s*([^<]*?)\\s*</${name}>`))?.[1];

/** Strips <exclusions> so an exclusion's groupId/artifactId is never mistaken for the dependency's own. */
const ownPart = (block: string) => block.replace(/<exclusions>[\s\S]*?<\/exclusions>/g, '');

export function projectDependencyBlocks(pom: string): PomDependencyBlock[] {
  const excluded: [number, number][] = [];
  for (const re of EXCLUDED_SECTIONS) for (const m of pom.matchAll(re)) excluded.push([m.index!, m.index! + m[0].length]);
  const blocks: PomDependencyBlock[] = [];
  for (const m of pom.matchAll(BLOCK)) {
    const start = m.index!;
    if (excluded.some(([s, e]) => start >= s && start < e)) continue;
    const own = ownPart(m[0]);
    blocks.push({ group: tag(own, 'groupId') ?? '', name: tag(own, 'artifactId') ?? '', text: m[0], start, end: start + m[0].length, version: tag(own, 'version') });
  }
  return blocks;
}

const findBlock = (pom: string, dep: { group: string; name: string }) => projectDependencyBlocks(pom).find(b => b.group === dep.group && b.name === dep.name);

export const hasExplicitVersion = (pom: string, dep: { group: string; name: string }): boolean => findBlock(pom, dep)?.version !== undefined;

export type Via = 'literal' | 'property' | 'property-inlined';
type DepOverride = { dep: { group: string; name: string }; version: string };

const propertyOf = (block: PomDependencyBlock) => block.version?.match(/^\$\{([^}]+)\}$/)?.[1];
const definitionOf = (prop: string) => {
  const escaped = prop.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  return new RegExp(`(<properties>[\\s\\S]*?<${escaped}>\\s*)[^<]*?(\\s*</${escaped}>)`);
};

/**
 * Sets the versions of several direct dependencies at once. A `${prop}` version is changed at its definition only when
 * every use of the property is among the overrides, all at one version (so nothing else moves); otherwise the version
 * is written as a literal in each overridden block.
 */
export function setDependencyVersions(pom: string, overrides: DepOverride[]): { pom: string; applied: { via: Via; property?: string }[] } {
  const blocks = overrides.map(({ dep }) => {
    const block = findBlock(pom, dep);
    if (!block) throw new Error(`${dep.group}:${dep.name} not found in the project <dependencies>`);
    if (block.version === undefined) throw new Error(`${dep.group}:${dep.name} has no <version> (managed by parent/BOM)`);
    return block;
  });
  const byProperty = new Map<string, { versions: Set<string>; count: number }>();
  overrides.forEach((o, i) => {
    const prop = propertyOf(blocks[i]);
    if (!prop) return;
    const entry = byProperty.get(prop) ?? { versions: new Set<string>(), count: 0 };
    entry.versions.add(o.version);
    entry.count++;
    byProperty.set(prop, entry);
  });
  const covered = new Map<string, string>(); // property → version written at its definition
  for (const [prop, { versions, count }] of byProperty) {
    const uses = pom.split('${' + prop + '}').length - 1;
    if (versions.size === 1 && count === uses && definitionOf(prop).test(pom)) covered.set(prop, [...versions][0]);
  }
  const applied = overrides.map((_, i) => {
    const prop = propertyOf(blocks[i]);
    if (!prop) return { via: 'literal' as const };
    return { via: covered.has(prop) ? ('property' as const) : ('property-inlined' as const), property: prop };
  });
  let out = pom;
  const inlined = overrides.map((o, i) => ({ block: blocks[i], version: o.version, prop: propertyOf(blocks[i]) })).filter(x => !x.prop || !covered.has(x.prop));
  for (const { block, version } of inlined.sort((a, b) => b.block.start - a.block.start)) {
    const own = block.text.replace(/(<version>\s*)[^<]*?(\s*<\/version>)/, `$1${version}$2`);
    out = out.slice(0, block.start) + own + out.slice(block.end);
  }
  for (const [prop, version] of covered) out = out.replace(definitionOf(prop), `$1${version}$2`);
  return { pom: out, applied };
}

export function setDependencyVersion(pom: string, dep: { group: string; name: string }, version: string): { pom: string; via: Via; property?: string } {
  const r = setDependencyVersions(pom, [{ dep, version }]);
  return { pom: r.pom, ...r.applied[0] };
}

export function detectJavaVersion(pom: string): string {
  for (const name of ['maven.compiler.release', 'java.version', 'maven.compiler.target', 'maven.compiler.source']) {
    const v = tag(pom, name.replace(/\./g, '\\.'));
    const m = v?.match(/^1\.(\d+)$/) ?? v?.match(/^(\d+)$/);
    if (m) return m[1];
  }
  return '17';
}

/** Parses `mvn dependency:list -DoutputFile=…` output: group:artifact:type[:classifier]:version:scope [-- module …]. */
export function parseDependencyList(text: string): (Gav & { scope: string })[] {
  const out: (Gav & { scope: string })[] = [];
  for (const raw of text.split('\n')) {
    const line = raw.replace(/\s+--\s+module.*$/, '').trim();
    const parts = line.split(':');
    if (parts.length !== 5 && parts.length !== 6) continue;
    if (!/^[\w.-]+$/.test(parts[0])) continue;
    const [group, name] = parts;
    const version = parts[parts.length - 2];
    const scope = parts[parts.length - 1];
    out.push({ group, name, version, scope });
  }
  return out;
}
