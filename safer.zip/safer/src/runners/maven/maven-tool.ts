import fs from 'fs';
import path from 'path';

import { BuildTool } from '../../core/build-tool';
import { ResolveError } from '../../core/errors';
import { limiter } from '../../core/limit';
import { DirectDep, Gav, Override, StepResult, depKey } from '../../core/model';
import { CONTAINER, ContainerExec, dockerExec, firstError, killedEarly, runHost, timedOut, withTimeout } from '../container';
import { detectJavaVersion, parseDependencyList, projectDependencyBlocks, setDependencyVersions } from './pom-edit';

const LIGHT_ENV = { JAVA_TOOL_OPTIONS: '-Xmx384m', MAVEN_OPTS: '-Xmx384m -Duser.home=/tmp' };
/** Resolution/classpath calls (dependency:list, build-classpath) are killed after this many seconds. */
export const RESOLVE_TIMEOUT_SEC = 600;
const DEFAULT_BUILD_TIMEOUT_SEC = 3600;

export { timedOut }; // historical export location

export type MavenToolOptions = {
  projectPath: string;
  saferRoot: string;
  logDir: string; // container.log and discovery logs go here
  exec?: ContainerExec;
  resolveConcurrency?: number;
  startContainer?: boolean; // false in unit tests
  buildTimeoutSec?: number; // per `mvn clean verify`, default 3600
  runHost?: typeof runHost; // host commands (container start/removal); injectable for tests
};

export class MavenTool implements BuildTool {
  readonly name = 'maven' as const;
  private readonly exec: ContainerExec;
  private readonly host: typeof runHost;
  private readonly pomPath: string;
  private accepted = '';
  private seq = 0;
  private javaVersion = 'unknown';
  private mavenVersion = 'unknown';
  // single shared limiter so concurrent resolveTree callers never exceed n Maven JVMs
  private readonly resolveSlots: <T>(fn: () => Promise<T>) => Promise<T>;

  constructor(private readonly opts: MavenToolOptions) {
    this.exec = opts.exec ?? dockerExec();
    this.host = opts.runHost ?? runHost;
    this.pomPath = path.join(opts.projectPath, 'pom.xml');
    this.resolveSlots = limiter(opts.resolveConcurrency ?? 2);
  }

  projectName(): string {
    return path.basename(this.opts.projectPath);
  }

  hasTests(): boolean {
    const walk = (dir: string): boolean =>
      fs.existsSync(dir) &&
      fs.readdirSync(dir, { withFileTypes: true }).some(e =>
        e.isDirectory() ? walk(path.join(dir, e.name)) : e.name.endsWith('.java') && fs.readFileSync(path.join(dir, e.name), 'utf8').includes('@Test'),
      );
    return walk(path.join(this.opts.projectPath, 'src', 'test', 'java'));
  }

  info(): Record<string, string> {
    return { java: this.javaVersion, maven: this.mavenVersion };
  }

  async init(): Promise<void> {
    this.accepted = fs.readFileSync(this.pomPath, 'utf8');
    const javaVersion = detectJavaVersion(this.accepted);
    this.javaVersion = javaVersion;
    if (this.opts.startContainer === false) return;
    const logFile = path.join(this.opts.logDir, 'container.log');
    const script = path.join(this.opts.saferRoot, 'src/runners/java/init-java-container.sh');
    const code = await this.host(`${script} ${javaVersion} ${this.opts.projectPath} ${this.opts.saferRoot} ${CONTAINER}`, {
      cwd: path.join(this.opts.saferRoot, 'src/runners/java'),
      logFile,
    });
    if (code !== 0) throw new Error(`Java ${javaVersion} container failed to start (see ${logFile})`);
    let ready = false;
    for (let i = 0; i < 60 && !ready; i++) {
      ready = (await this.exec(['true'])).code === 0;
      if (!ready) await new Promise(r => setTimeout(r, 1000));
    }
    if (!ready) throw new Error(`container ${CONTAINER} not ready after 60s (see ${logFile})`);
    this.mavenVersion = await this.detectMavenVersion();
  }

  /** First line of `mvn -v` in the container (for run.json); 'unknown' when it cannot be read. */
  private async detectMavenVersion(): Promise<string> {
    try {
      const r = await this.exec(['mvn', '-v'], { timeoutMs: 120_000 });
      const lines = r.stdout
        .replace(/\x1b\[[0-9;]*m/g, '') // eslint-disable-line no-control-regex -- strips ANSI colour codes
        .split('\n')
        .map(l => l.trim())
        .filter(l => l && !l.startsWith('Picked up '));
      return (r.code === 0 && lines[0]) || 'unknown';
    } catch {
      return 'unknown';
    }
  }

  private tempName(ext: string): string {
    return `.safer-${process.pid}-${++this.seq}.${ext}`;
  }

  /** Runs a resolution goal writing to a temp output file; `check` may reject the output (the log is then kept). */
  private async mvnToFile(goalArgs: string[], pomFile = 'pom.xml', check?: (text: string) => string | undefined): Promise<string> {
    const out = this.tempName('txt');
    const outFlag = goalArgs[0] === 'dependency:build-classpath' ? `-Dmdep.outputFile=${out}` : `-DoutputFile=${out}`;
    const logFile = path.join(this.opts.logDir, `mvn-${out.slice(1, -4)}.log`);
    try {
      const cmd = withTimeout(RESOLVE_TIMEOUT_SEC, ['mvn', '-B', '-q', '-f', pomFile, ...goalArgs, outFlag]);
      const r = await this.resolveSlots(() => this.exec(cmd.args, { env: LIGHT_ENV, logFile, timeoutMs: cmd.timeoutMs }));
      if (timedOut(r.code, r.durationMs, RESOLVE_TIMEOUT_SEC)) throw new ResolveError(`mvn ${goalArgs[0]} timeout after ${RESOLVE_TIMEOUT_SEC}s`, logFile);
      const outPath = path.join(this.opts.projectPath, out);
      if (r.code !== 0 || !fs.existsSync(outPath)) {
        const log = fs.existsSync(logFile) ? fs.readFileSync(logFile, 'utf8') : '';
        throw new ResolveError(`mvn ${goalArgs[0]} failed: ${firstError(log) ?? killedEarly(r.code) ?? `exit ${r.code}`}`, logFile);
      }
      const text = fs.readFileSync(outPath, 'utf8');
      const problem = check?.(text);
      if (problem) throw new ResolveError(problem, logFile);
      fs.rmSync(logFile, { force: true }); // keep logs only for failures
      return text;
    } finally {
      fs.rmSync(path.join(this.opts.projectPath, out), { force: true });
    }
  }

  async listDirectDeps(): Promise<DirectDep[]> {
    const resolved = parseDependencyList(await this.mvnToFile(['dependency:list', '-DexcludeTransitive=true']));
    const byKey = new Map(resolved.map(d => [depKey(d), d]));
    const deps: DirectDep[] = [];
    for (const block of projectDependencyBlocks(this.accepted)) {
      const r = byKey.get(depKey(block));
      if (!r) continue; // e.g. a dependency only active in a profile
      const versionProperty = block.version?.match(/^\$\{([^}]+)\}$/)?.[1];
      deps.push({ group: r.group, name: r.name, version: r.version, scope: r.scope, explicitVersion: block.version !== undefined, ...(versionProperty && { versionProperty }) });
      byKey.delete(depKey(block));
    }
    for (const r of byKey.values()) deps.push({ ...r, explicitVersion: false }); // inherited from the parent's <dependencies>
    return deps;
  }

  async resolveTree(overrides?: Override[]): Promise<Gav[]> {
    let pomFile = 'pom.xml';
    let tempPom: string | null = null;
    if (overrides?.length) {
      tempPom = this.tempName('xml');
      fs.writeFileSync(path.join(this.opts.projectPath, tempPom), setDependencyVersions(this.accepted, overrides).pom);
      pomFile = tempPom;
    }
    // an empty tree, or one without the requested override, would be scored as clean: refuse it
    const check = (text: string) => {
      const tree = parseDependencyList(text);
      if (tree.length === 0) return 'mvn dependency:list returned an empty runtime tree';
      for (const o of overrides ?? []) {
        if (!tree.some(g => depKey(g) === depKey(o.dep) && g.version === o.version)) {
          const found = tree.find(g => depKey(g) === depKey(o.dep));
          return `resolved tree has ${depKey(o.dep)} ${found ? `at ${found.version}` : 'missing'} instead of ${o.version}`;
        }
      }
      return undefined;
    };
    try {
      return parseDependencyList(await this.mvnToFile(['dependency:list', '-DincludeScope=runtime'], pomFile, check)).map(({ group, name, version }) => ({ group, name, version }));
    } finally {
      if (tempPom) fs.rmSync(path.join(this.opts.projectPath, tempPom), { force: true });
    }
  }

  async apply(overrides: Override[]) {
    const r = setDependencyVersions(this.accepted, overrides);
    if (r.pom !== fs.readFileSync(this.pomPath, 'utf8')) fs.writeFileSync(this.pomPath, r.pom);
    return r.applied;
  }

  async restore(): Promise<void> {
    if (fs.readFileSync(this.pomPath, 'utf8') !== this.accepted) fs.writeFileSync(this.pomPath, this.accepted);
  }

  async accept(): Promise<void> {
    this.accepted = fs.readFileSync(this.pomPath, 'utf8');
  }

  async build({ tests, logFile }: { tests: boolean; logFile: string }): Promise<StepResult> {
    fs.mkdirSync(path.dirname(logFile), { recursive: true });
    const skip = tests ? [] : ['-DskipTests', '-Dmaven.test.skip=true'];
    const sec = this.opts.buildTimeoutSec ?? DEFAULT_BUILD_TIMEOUT_SEC;
    const cmd = withTimeout(sec, ['mvn', '-B', 'clean', 'verify', '-Ddependency-check.skip=true', ...skip]);
    const r = await this.exec(cmd.args, { logFile, timeoutMs: cmd.timeoutMs });
    const ok = r.code === 0;
    if (!ok && timedOut(r.code, r.durationMs, sec)) return { ok, logFile, durationMs: r.durationMs, firstError: `timeout after ${sec}s` };
    const log = fs.existsSync(logFile) ? fs.readFileSync(logFile, 'utf8') : '';
    return { ok, logFile, durationMs: r.durationMs, firstError: ok ? undefined : firstError(log) ?? killedEarly(r.code) ?? `mvn exit ${r.code}` };
  }

  async classpath(): Promise<string> {
    const deps = (await this.mvnToFile(['dependency:build-classpath', '-Dmdep.includeScope=runtime'])).trim();
    return ['/app/target/classes', deps].filter(Boolean).join(':');
  }

  classesDir(): string {
    return 'target/classes';
  }

  async packagedArtifact(): Promise<string | null> {
    const target = path.join(this.opts.projectPath, 'target');
    if (!fs.existsSync(target)) return null;
    const jars = fs
      .readdirSync(target)
      .filter(f => /\.(jar|war)$/.test(f) && !/-(sources|javadoc|tests)\.jar$/.test(f))
      .map(f => path.join(target, f))
      .sort((a, b) => fs.statSync(b).mtimeMs - fs.statSync(a).mtimeMs);
    return jars[0] ?? null;
  }

  /** Each cleanup step runs even if an earlier one fails; the first error is rethrown at the end. */
  async dispose(): Promise<void> {
    const errors: unknown[] = [];
    const step = async (fn: () => unknown) => {
      try {
        await fn();
      } catch (err) {
        errors.push(err);
      }
    };
    await step(() => {
      if (this.accepted && fs.readFileSync(this.pomPath, 'utf8') !== this.accepted) fs.writeFileSync(this.pomPath, this.accepted);
    });
    await step(() => {
      for (const f of fs.readdirSync(this.opts.projectPath)) if (f.startsWith('.safer-')) fs.rmSync(path.join(this.opts.projectPath, f), { force: true });
    });
    if (this.opts.startContainer !== false) {
      await step(() => this.host(`docker rm -f ${CONTAINER}`, { cwd: this.opts.projectPath, logFile: path.join(this.opts.logDir, 'container.log') }));
    }
    if (errors.length) throw errors[0];
  }
}
