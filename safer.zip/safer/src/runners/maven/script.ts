import fs from 'fs';
import * as path from 'path';

import { SemanticVersioningHelper } from '#helpers/semantic-versioning-helper';
import { JavaRunner } from '#runners/java/java-runner';
import { RandoopRunner } from '#runners/randoop/randoop-runner';
import { makeGetDependencyNewerVersionsService } from '#services/get-dependency-newer-versions';
import { makeGetDependencyVulnerabilitiesService } from '#services/get-dependency-vulnerabilities';
import { ReportMaven } from '#services/impl/report/maven';
import { ConfigType, ExecutionsType, WeightVulnerabilityType } from '#types/config';
import { Dependency, DependencyVulnerability, VersionVulnerability } from '#types/models';

import { MavenAdapter } from './maven-adapter';
import { MavenRunner } from './maven-runner';
import loggerSync from '../../utils/logger';
import execCommand from '../../utils/execCommand';

const getDependencyVulnerabilitiesService = makeGetDependencyVulnerabilitiesService();
const getDependencyNewerVersionsService = makeGetDependencyNewerVersionsService();
const reportMaven = new ReportMaven('maven');

export const runForMaven = async (config: ConfigType) => {
  const { projectAbsolutePath, weightVulnerability, executions, exploratoryTestingParams } = config;
  const { javaVersion, dependencies } = await MavenAdapter.getFromMvn(projectAbsolutePath);
  loggerSync({ level: 'info', message: `Required Java version: ${javaVersion}` });
  if (Number(javaVersion) < 8) {
    loggerSync({ level: 'error', message: `We do not support Java versions lower than 8; if necessary, please manually modify the Docker image.` });
    return;
  }

  if (executions.buildProject) {
    const hasTests = MavenAdapter.hasTests(projectAbsolutePath);

    if (hasTests) {
      try {
        JavaRunner.initJavaContainer(javaVersion, projectAbsolutePath);
        MavenRunner.runMavenBuild(true, { verbose: true });
        executions.projectTests = true;
        loggerSync({ level: 'info', message: 'Maven build completed successfully.' });
      } catch (error) {
        try {
          MavenRunner.runMavenBuild(false, { verbose: true });
        } catch (error) {
          loggerSync({ level: 'error', message: 'Error during Maven build.' });
          return;
        }
      }
    } else {
      try {
        JavaRunner.initJavaContainer(javaVersion, projectAbsolutePath);
        MavenRunner.runMavenBuild(false, { verbose: true });
        loggerSync({ level: 'info', message: 'Maven build completed successfully.' });
      } catch (error) {
        loggerSync({ level: 'error', message: 'Error during Maven build.' });
        return;
      }
    }
  }

  const dependenciesNewerVersions = await getDependenciesNewerVersions(dependencies);
  loggerSync({ level: 'info', message: '\n\n\n========= DEPENDENCIES NEWER VERSIONS ==========\n' });
  loggerSync({ level: 'dir', object: dependenciesNewerVersions });

  const dependenciesVersionsRank = await getDependenciesVersionsRank(dependenciesNewerVersions, weightVulnerability);
  loggerSync({ level: 'info', message: '\n\n\n========= DEPENDENCIES VERSIONS RANK ==========\n' });
  loggerSync({ level: 'dir', object: dependenciesVersionsRank });

  const { dependencyClasspath } = await MavenAdapter.getClassPathFromMvn(projectAbsolutePath);
  if (executions.exploratoryTesting) {
    RandoopRunner.generateRandoopTests(exploratoryTestingParams!, projectAbsolutePath, 'maven', dependencyClasspath);
  }

  const appliedDependencies = updateDependenciesInPom(dependenciesVersionsRank, projectAbsolutePath, executions, dependencyClasspath);
  reportMaven.execute({ dependenciesVersionsRank, appliedDependencies, executions });
};

//execCommand(`./gradlew clean build publishToMavenLocal -x compileTestJava`);

const updateDependenciesInPom = (
  dependenciesVersionsRank: {
    dependency: Dependency;
    rank: VersionVulnerability[];
  }[],
  projectAbsolutePath: string,
  executions: ExecutionsType,
  dependencyClasspath: string,
): { dependency: Dependency; version: string }[] => {
  const appliedDependencies: { dependency: Dependency; version: string }[] = [];
  for (const dependencyVersionsRank of dependenciesVersionsRank) {
    for (const possibleVersion of dependencyVersionsRank.rank) {
      const { dependency } = dependencyVersionsRank;
      const dependencyApplied = { dependency, version: possibleVersion.version };
      loggerSync({
        level: 'info',
        message: `Applying version ${possibleVersion.version} with vulnerability rate ${possibleVersion.detailsDependencyVulnerability.rate} of ${dependency.name} dependency in pom.xml`,
      });
      const currentPomXml = fs.readFileSync(path.join(projectAbsolutePath, 'pom.xml'), 'utf-8');
      const newPomXml = MavenAdapter.getPomXmlReplacedDependencyVersion(currentPomXml, dependency, possibleVersion.version);
      writePomXmlFile(projectAbsolutePath, newPomXml);
      if (possibleVersion.version === dependency.version) {
        loggerSync({
          level: 'info',
          message: `Keeping the current version ${possibleVersion.version} of ${dependency.name}\n\n`,
        });
        appliedDependencies.push(dependencyApplied);
        break;
      }

      if (!executions.buildProject) {
        appliedDependencies.push(dependencyApplied);
        break;
      }

      try {
        loggerSync({
          level: 'info',
          message: `Running maven build for version ${possibleVersion.version} of ${dependency.name} dependency`,
        });
        MavenRunner.runMavenBuild(executions.projectTests, { verbose: true });
        loggerSync({
          level: 'info',
          message: 'Maven build executed successfully\n\n',
        });
        if (!executions.exploratoryTesting) {
          appliedDependencies.push(dependencyApplied);
          break;
        }
      } catch (error) {
        loggerSync({
          level: 'info',
          message: "Error on maven build. Let's try a new version.\n",
          object: error,
        });
        continue;
      }

      if (executions.exploratoryTesting) {
        try {
          RandoopRunner.runRandoopTests('maven', dependencyClasspath);
          loggerSync({
            level: 'info',
            message: 'Exploratory tests executed successfully\n\n',
          });
          appliedDependencies.push(dependencyApplied);
          break;
        } catch (error) {
          loggerSync({
            level: 'info',
            message: "Error on randoop testing. Let's try a new version.\n",
            object: error,
          });
          continue;
        }
      }
    }
  }
  return appliedDependencies;
};

const getDependenciesNewerVersions = async (dependencies: Dependency[]) => {
  const dependenciesNewerVersions: { dependency: Dependency; newerVersions: string[] }[] = await Promise.all(
    dependencies.map(async dependency => ({
      dependency,
      newerVersions: await getDependencyNewerVersionsService.execute(dependency),
    })),
  );

  return dependenciesNewerVersions;
};

const getDependenciesVersionsRank = async (
  dependenciesNewerVersions: {
    dependency: Dependency;
    newerVersions: string[];
  }[],
  weightVulnerability: WeightVulnerabilityType,
) => {
  const dependenciesVersionsRank: { dependency: Dependency; rank: VersionVulnerability[] }[] = await Promise.all(
    dependenciesNewerVersions.map(async dependencyNewerVersions => ({
      dependency: dependencyNewerVersions.dependency,
      rank: await getVersionsRank(dependencyNewerVersions.dependency, dependencyNewerVersions.newerVersions, weightVulnerability),
    })),
  );
  return dependenciesVersionsRank;
};

const getVersionsRank = async (dependency: Dependency, newerVersions: string[], weightVulnerability: WeightVulnerabilityType): Promise<VersionVulnerability[]> => {
  const versionsVulnerability: VersionVulnerability[] = await Promise.all(
    newerVersions.map(async version => ({
      version,
      detailsDependencyVulnerability: await calculateVulnerabilityRate(dependency, version, weightVulnerability),
    })),
  );

  const versionsRank = versionsVulnerability.sort((a, b) => {
    if (a.detailsDependencyVulnerability.rate !== b.detailsDependencyVulnerability.rate) {
      return a.detailsDependencyVulnerability.rate - b.detailsDependencyVulnerability.rate;
    }

    return SemanticVersioningHelper.compareVersions(a.version, b.version);
  });

  return versionsRank;
};

const calculateVulnerabilityRate = async (dependency: Dependency, version: string, weightVulnerability: WeightVulnerabilityType): Promise<{ details: DependencyVulnerability[]; rate: number }> => {
  const vulnerabilities = await getDependencyVulnerabilitiesService.execute({ dependency, version });
  const rate = vulnerabilities.reduce((rate, { severityScore, severity }) => rate + severityScore * weightVulnerability[severity], 0);
  return { details: vulnerabilities, rate };
};

const writePomXmlFile = (pomPath: string, newPomXml: string) => {
  fs.writeFileSync(path.join(pomPath, 'pom.xml'), newPomXml);
};
