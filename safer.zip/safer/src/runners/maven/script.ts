import { ConfigType } from '../../types/config';
import { createRunLog, runSafer, saferRootPath } from '../run-safer';
import { MavenTool } from './maven-tool';

export const runForMaven = async (config: ConfigType): Promise<void> => {
  const saferRoot = saferRootPath();
  const log = createRunLog(config, saferRoot);
  const tool = new MavenTool({ projectPath: config.projectAbsolutePath, saferRoot, logDir: log.runDir, buildTimeoutSec: config.buildTimeoutSec ?? 3600 });
  await runSafer(config, tool, log, { saferRoot });
};
