import fs from 'fs';
import path from 'path';

import { describe, expect, it } from 'vitest';

import { detectJavaVersion, hasExplicitVersion, parseDependencyList, projectDependencyBlocks, setDependencyVersion, setDependencyVersions } from './pom-edit';

const pom = fs.readFileSync(path.resolve('src/test-fixtures/integration-api.pom.xml'), 'utf8');

const SMALL = `<project>
  <properties>
    <java.version>17</java.version>
    <foo.version>1.0</foo.version>
    <shared.version>2.0</shared.version>
  </properties>
  <dependencies>
    <dependency><groupId>g</groupId><artifactId>foo</artifactId><version>\${foo.version}</version></dependency>
    <dependency><groupId>g</groupId><artifactId>s1</artifactId><version>\${shared.version}</version></dependency>
    <dependency><groupId>g</groupId><artifactId>s2</artifactId><version>\${shared.version}</version></dependency>
    <dependency><groupId>g</groupId><artifactId>lit</artifactId><version>3.0</version><exclusions><exclusion><groupId>x</groupId><artifactId>y</artifactId></exclusion></exclusions></dependency>
    <dependency><groupId>g</groupId><artifactId>managed</artifactId></dependency>
  </dependencies>
  <dependencyManagement><dependencies>
    <dependency><groupId>g</groupId><artifactId>managed</artifactId><version>9</version></dependency>
  </dependencies></dependencyManagement>
  <build><plugins><plugin><artifactId>p</artifactId><dependencies>
    <dependency><groupId>g</groupId><artifactId>lit</artifactId><version>0.1</version></dependency>
  </dependencies></plugin></plugins></build>
</project>`;

describe('projectDependencyBlocks', () => {
  it('lists only project dependencies, in order', () => {
    expect(projectDependencyBlocks(SMALL).map(b => b.name)).toEqual(['foo', 's1', 's2', 'lit', 'managed']);
  });
  it('finds the 32-ish blocks of the integration-api pom without the BOM imports', () => {
    const names = projectDependencyBlocks(pom).map(b => b.name);
    expect(names).toContain('minio');
    expect(names).not.toContain('spring-cloud-dependencies');
    expect(names).not.toContain('aws-java-sdk-bom');
  });
});

describe('hasExplicitVersion', () => {
  it('is false for managed deps even if dependencyManagement pins them', () => {
    expect(hasExplicitVersion(SMALL, { group: 'g', name: 'managed' })).toBe(false);
    expect(hasExplicitVersion(SMALL, { group: 'g', name: 'lit' })).toBe(true);
  });
});

describe('setDependencyVersion', () => {
  it('replaces a literal only inside the right block (not the plugin dependency)', () => {
    const r = setDependencyVersion(SMALL, { group: 'g', name: 'lit' }, '3.1');
    expect(r.via).toBe('literal');
    expect(r.pom).toContain('<artifactId>lit</artifactId><version>3.1</version><exclusions>');
    expect(r.pom).toContain('<version>0.1</version>');
    expect(r.pom.length - SMALL.length).toBe(0);
  });
  it('edits an exclusive property instead of the reference', () => {
    const r = setDependencyVersion(SMALL, { group: 'g', name: 'foo' }, '1.1');
    expect(r).toMatchObject({ via: 'property', property: 'foo.version' });
    expect(r.pom).toContain('<foo.version>1.1</foo.version>');
    expect(r.pom).toContain('<version>${foo.version}</version>');
  });
  it('inlines a literal when the property is shared', () => {
    const r = setDependencyVersion(SMALL, { group: 'g', name: 's1' }, '2.1');
    expect(r).toMatchObject({ via: 'property-inlined', property: 'shared.version' });
    expect(r.pom).toContain('<artifactId>s1</artifactId><version>2.1</version>');
    expect(r.pom).toContain('<artifactId>s2</artifactId><version>${shared.version}</version>');
    expect(r.pom).toContain('<shared.version>2.0</shared.version>');
  });
  it('throws for managed or missing deps', () => {
    expect(() => setDependencyVersion(SMALL, { group: 'g', name: 'managed' }, '1')).toThrow(/no <version>/);
    expect(() => setDependencyVersion(SMALL, { group: 'g', name: 'nope' }, '1')).toThrow(/not found/);
  });
  it('round-trips the real pom (only the minio version changes)', () => {
    const r = setDependencyVersion(pom, { group: 'io.minio', name: 'minio' }, '8.5.99');
    const changed = r.pom.split('\n').filter((l, i) => l !== pom.split('\n')[i]);
    expect(changed).toEqual([expect.stringContaining('<version>8.5.99</version>')]);
  });
});

describe('misc', () => {
  it('detectJavaVersion', () => {
    expect(detectJavaVersion(SMALL)).toBe('17');
    expect(detectJavaVersion('<project><properties><maven.compiler.release>21</maven.compiler.release></properties></project>')).toBe('21');
    expect(detectJavaVersion('<project><properties><maven.compiler.source>1.8</maven.compiler.source></properties></project>')).toBe('8');
    expect(detectJavaVersion('<project/>')).toBe('17');
  });
  it('parseDependencyList', () => {
    const text = `
The following files have been resolved:
   com.fasterxml.jackson.core:jackson-databind:jar:2.14.2:compile -- module com.fasterxml.jackson.databind
   io.netty:netty-transport-native-epoll:jar:linux-x86_64:4.1.89.Final:runtime -- module io.netty.transport.epoll [auto]
   org.projectlombok:lombok:jar:1.18.26:provided
`;
    expect(parseDependencyList(text)).toEqual([
      { group: 'com.fasterxml.jackson.core', name: 'jackson-databind', version: '2.14.2', scope: 'compile' },
      { group: 'io.netty', name: 'netty-transport-native-epoll', version: '4.1.89.Final', scope: 'runtime' },
      { group: 'org.projectlombok', name: 'lombok', version: '1.18.26', scope: 'provided' },
    ]);
  });
});

describe('setDependencyVersions', () => {
  const shared = `<project><properties><jackson.version>2.14.2</jackson.version></properties><dependencies>
<dependency><groupId>com.fasterxml.jackson.core</groupId><artifactId>jackson-core</artifactId><version>\${jackson.version}</version></dependency>
<dependency><groupId>com.fasterxml.jackson.core</groupId><artifactId>jackson-databind</artifactId><version>\${jackson.version}</version></dependency>
<dependency><groupId>io.minio</groupId><artifactId>minio</artifactId><version>8.5.2</version></dependency>
</dependencies></project>`;
  const core = { group: 'com.fasterxml.jackson.core', name: 'jackson-core' };
  const databind = { group: 'com.fasterxml.jackson.core', name: 'jackson-databind' };
  const minio = { group: 'io.minio', name: 'minio' };

  it('edits a shared property once when every user moves to the same version', () => {
    const r = setDependencyVersions(shared, [{ dep: core, version: '2.18.2' }, { dep: databind, version: '2.18.2' }]);
    expect(r.pom).toContain('<jackson.version>2.18.2</jackson.version>');
    expect(r.pom.match(/\$\{jackson\.version\}/g)).toHaveLength(2);
    expect(r.applied).toEqual([{ via: 'property', property: 'jackson.version' }, { via: 'property', property: 'jackson.version' }]);
  });
  it('inlines when the members of a shared property move to different versions', () => {
    const r = setDependencyVersions(shared, [{ dep: core, version: '2.18.2' }, { dep: databind, version: '2.18.1' }]);
    expect(r.pom).toContain('<jackson.version>2.14.2</jackson.version>');
    expect(r.pom).toContain('<artifactId>jackson-core</artifactId><version>2.18.2</version>');
    expect(r.pom).toContain('<artifactId>jackson-databind</artifactId><version>2.18.1</version>');
    expect(r.applied.map(a => a.via)).toEqual(['property-inlined', 'property-inlined']);
  });
  it('inlines when only part of a shared property is overridden (today\'s single-dep behaviour)', () => {
    const r = setDependencyVersions(shared, [{ dep: core, version: '2.18.2' }]);
    expect(r.pom).toContain('<jackson.version>2.14.2</jackson.version>');
    expect(r.applied).toEqual([{ via: 'property-inlined', property: 'jackson.version' }]);
  });
  it('mixes literal and property edits', () => {
    const r = setDependencyVersions(shared, [{ dep: minio, version: '8.5.10' }, { dep: core, version: '2.18.2' }, { dep: databind, version: '2.18.2' }]);
    expect(r.pom).toContain('<artifactId>minio</artifactId><version>8.5.10</version>');
    expect(r.pom).toContain('<jackson.version>2.18.2</jackson.version>');
    expect(r.applied.map(a => a.via)).toEqual(['literal', 'property', 'property']);
  });
  it('throws for a missing or managed member', () => {
    expect(() => setDependencyVersions(shared, [{ dep: { group: 'x', name: 'y' }, version: '1' }])).toThrow('not found');
  });
});
