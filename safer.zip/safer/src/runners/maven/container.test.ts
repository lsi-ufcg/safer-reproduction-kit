import { describe, expect, it } from 'vitest';

import { firstError } from './container';

describe('firstError', () => {
  it('returns the first meaningful [ERROR] line', () => {
    const log = [
      '[INFO] Building',
      '[ERROR] COMPILATION ERROR : ',
      '[ERROR] /app/src/main/java/A.java:[10,5] cannot find symbol',
      '[ERROR] ',
      '[ERROR] -> [Help 1]',
    ].join('\n');
    expect(firstError(log)).toBe('/app/src/main/java/A.java:[10,5] cannot find symbol');
  });
  it('reports failing tests', () => {
    const log = '[INFO] x\n[ERROR] Tests run: 5, Failures: 1, Errors: 0, Skipped: 0, Time elapsed: 1 s <<< FAILURE! - in a.BTest\n[ERROR] Failed to execute goal';
    expect(firstError(log)).toMatch(/Tests run: 5, Failures: 1.*a\.BTest/);
  });
  it('undefined when there is no error', () => expect(firstError('[INFO] BUILD SUCCESS')).toBeUndefined());
});
