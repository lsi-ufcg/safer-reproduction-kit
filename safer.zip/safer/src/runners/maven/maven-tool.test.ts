import fs from 'fs';
import os from 'os';
import path from 'path';

import { beforeEach, describe, expect, it } from 'vitest';

import { ResolveError } from '../../core/errors';
import { CONTAINER, ContainerExec } from './container';
import { MavenTool, RESOLVE_TIMEOUT_SEC } from './maven-tool';

const POM = `<project><artifactId>demo</artifactId><properties><java.version>17</java.version></properties><dependencies>
<dependency><groupId>g</groupId><artifactId>a</artifactId><version>1.0</version></dependency>
<dependency><groupId>g</groupId><artifactId>t</artifactId><version>1.0</version><scope>test</scope></dependency>
<dependency><groupId>g</groupId><artifactId>m</artifactId></dependency>
</dependencies></project>`;

let dir: string;
let calls: string[][];

const fakeExec = (): ContainerExec => async (args, opts) => {
  calls.push(args);
  const outFlag = args.find(a => a.startsWith('-DoutputFile=') || a.startsWith('-Dmdep.outputFile='));
  if (outFlag) {
    const file = path.join(dir, outFlag.split('=')[1]);
    if (args.includes('-DexcludeTransitive=true')) {
      fs.writeFileSync(file, '   g:a:jar:1.0:compile\n   g:t:jar:1.0:test\n   g:m:jar:5.0:compile\n');
    } else if (args.includes('dependency:build-classpath')) {
      fs.writeFileSync(file, '/tmp/.m2/repository/g/a/1.0/a-1.0.jar');
    } else {
      const pomFile = args[args.indexOf('-f') + 1];
      const version = fs.readFileSync(path.join(dir, pomFile), 'utf8').match(/<artifactId>a<\/artifactId><version>([^<]+)/)![1];
      fs.writeFileSync(file, `   g:a:jar:${version}:compile\n   g:dep-of-a:jar:${version}:runtime\n`);
    }
  }
  if (opts?.logFile) fs.writeFileSync(opts.logFile, args.includes('verify') && fs.readFileSync(path.join(dir, 'pom.xml'), 'utf8').includes('<version>9.9</version>') ? '[ERROR] boom\n' : '[INFO] BUILD SUCCESS\n');
  const failed = args.includes('verify') && fs.readFileSync(path.join(dir, 'pom.xml'), 'utf8').includes('<version>9.9</version>');
  return { code: failed ? 1 : 0, stdout: '', durationMs: 1 };
};

beforeEach(() => {
  dir = fs.mkdtempSync(path.join(os.tmpdir(), 'safer-mvn-'));
  fs.writeFileSync(path.join(dir, 'pom.xml'), POM);
  calls = [];
});

const tool = () => new MavenTool({ projectPath: dir, saferRoot: '/x', logDir: dir, exec: fakeExec(), startContainer: false });

describe('MavenTool', () => {
  it('lists direct deps in pom order with scope and explicitness', async () => {
    const t = tool();
    await t.init();
    expect(await t.listDirectDeps()).toEqual([
      { group: 'g', name: 'a', version: '1.0', explicitVersion: true, scope: 'compile' },
      { group: 'g', name: 't', version: '1.0', explicitVersion: true, scope: 'test' },
      { group: 'g', name: 'm', version: '5.0', explicitVersion: false, scope: 'compile' },
    ]);
  });
  it('resolves an override from a temp pom in the project root and cleans it up', async () => {
    const t = tool();
    await t.init();
    const [a] = await t.listDirectDeps();
    const tree = await t.resolveTree([{ dep: a, version: '2.0' }]);
    expect(tree).toContainEqual({ group: 'g', name: 'dep-of-a', version: '2.0' });
    expect(fs.readdirSync(dir).filter(f => f.startsWith('.safer-'))).toEqual([]);
    expect(fs.readFileSync(path.join(dir, 'pom.xml'), 'utf8')).toBe(POM);
  });
  it('apply/restore/accept/dispose keep the pom consistent', async () => {
    const t = tool();
    await t.init();
    const [a] = await t.listDirectDeps();
    await t.apply([{ dep: a, version: '2.0' }]);
    expect(fs.readFileSync(path.join(dir, 'pom.xml'), 'utf8')).toContain('<version>2.0</version>');
    await t.restore();
    expect(fs.readFileSync(path.join(dir, 'pom.xml'), 'utf8')).toBe(POM);
    await t.apply([{ dep: a, version: '3.0' }]);
    await t.accept();
    await t.apply([{ dep: a, version: '4.0' }]);
    await t.dispose();
    expect(fs.readFileSync(path.join(dir, 'pom.xml'), 'utf8')).toContain('<version>3.0</version>');
  });
  it('build reports ok/firstError and uses verify; tests flag toggles skip properties', async () => {
    const t = tool();
    await t.init();
    const [a] = await t.listDirectDeps();
    const ok = await t.build({ tests: true, logFile: path.join(dir, 'b1.log') });
    expect(ok.ok).toBe(true);
    expect(calls.at(-1)).not.toContain('-DskipTests');
    await t.apply([{ dep: a, version: '9.9' }]);
    const bad = await t.build({ tests: false, logFile: path.join(dir, 'b2.log') });
    expect(bad).toMatchObject({ ok: false, firstError: 'boom' });
    expect(calls.at(-1)).toEqual(expect.arrayContaining(['clean', 'verify', '-DskipTests', '-Dmaven.test.skip=true']));
  });
  it('classpath is container-absolute and starts with target/classes', async () => {
    const t = tool();
    await t.init();
    expect(await t.classpath()).toBe('/app/target/classes:/tmp/.m2/repository/g/a/1.0/a-1.0.jar');
  });

  it('wraps builds and resolution in coreutils timeout -s KILL', async () => {
    const t = new MavenTool({ projectPath: dir, saferRoot: '/x', logDir: dir, exec: fakeExec(), startContainer: false, buildTimeoutSec: 42 });
    await t.init();
    await t.build({ tests: true, logFile: path.join(dir, 'b.log') });
    expect(calls.at(-1)!.slice(0, 5)).toEqual(['timeout', '-s', 'KILL', '42', 'mvn']);
    await t.listDirectDeps();
    expect(calls.at(-1)!.slice(0, 5)).toEqual(['timeout', '-s', 'KILL', String(RESOLVE_TIMEOUT_SEC), 'mvn']);
  });
  it('reports a build killed by the timeout as "timeout after Ns", an early 137 as a kill', async () => {
    const exec = (code: number, durationMs: number): ContainerExec => async (args, opts) => {
      calls.push(args);
      if (opts?.logFile) fs.writeFileSync(opts.logFile, '[INFO] Building\n');
      return { code, stdout: '', durationMs };
    };
    const slow = new MavenTool({ projectPath: dir, saferRoot: '/x', logDir: dir, exec: exec(137, 10_000), startContainer: false, buildTimeoutSec: 10 });
    expect(await slow.build({ tests: true, logFile: path.join(dir, 'b.log') })).toMatchObject({ ok: false, firstError: 'timeout after 10s' });
    const t124 = new MavenTool({ projectPath: dir, saferRoot: '/x', logDir: dir, exec: exec(124, 10_000), startContainer: false, buildTimeoutSec: 10 });
    expect(await t124.build({ tests: true, logFile: path.join(dir, 'b.log') })).toMatchObject({ firstError: 'timeout after 10s' });
    const oom = new MavenTool({ projectPath: dir, saferRoot: '/x', logDir: dir, exec: exec(137, 1_000), startContainer: false, buildTimeoutSec: 10 });
    expect(await oom.build({ tests: true, logFile: path.join(dir, 'b.log') })).toMatchObject({ firstError: 'killed (exit 137, likely out of memory)' });
  });
  it('a resolution timeout is a ResolveError carrying the log', async () => {
    const exec: ContainerExec = async (_args, opts) => {
      if (opts?.logFile) fs.writeFileSync(opts.logFile, '[INFO] Downloading\n');
      return { code: 137, stdout: '', durationMs: RESOLVE_TIMEOUT_SEC * 1000 };
    };
    const t = new MavenTool({ projectPath: dir, saferRoot: '/x', logDir: dir, exec, startContainer: false });
    await t.init();
    const err = await t.resolveTree().catch(e => e);
    expect(err).toBeInstanceOf(ResolveError);
    expect(err.message).toBe(`mvn dependency:list timeout after ${RESOLVE_TIMEOUT_SEC}s`);
    expect(fs.existsSync(err.logFile)).toBe(true);
  });
  it('refuses an empty tree and a tree without the overridden version, keeping the log', async () => {
    let listing = '';
    const exec: ContainerExec = async (args, opts) => {
      const out = args.find(a => a.startsWith('-DoutputFile='))!.split('=')[1];
      fs.writeFileSync(path.join(dir, out), listing);
      if (opts?.logFile) fs.writeFileSync(opts.logFile, '[INFO] ok\n');
      return { code: 0, stdout: '', durationMs: 1 };
    };
    const t = new MavenTool({ projectPath: dir, saferRoot: '/x', logDir: dir, exec, startContainer: false });
    await t.init();
    const a = { group: 'g', name: 'a', version: '1.0', explicitVersion: true, scope: 'compile' };
    listing = 'The following files have been resolved:\n   none\n';
    const empty = await t.resolveTree().catch(e => e);
    expect(empty).toBeInstanceOf(ResolveError);
    expect(empty.message).toBe('mvn dependency:list returned an empty runtime tree');
    expect(fs.existsSync(empty.logFile)).toBe(true);
    listing = '   g:a:jar:1.0:compile\n';
    await expect(t.resolveTree([{ dep: a, version: '2.0' }])).rejects.toThrow('resolved tree has g:a at 1.0 instead of 2.0');
    listing = '   g:b:jar:1.0:compile\n';
    await expect(t.resolveTree([{ dep: a, version: '2.0' }])).rejects.toThrow('resolved tree has g:a missing instead of 2.0');
    listing = '   g:a:jar:2.0:compile\n';
    expect(await t.resolveTree([{ dep: a, version: '2.0' }])).toEqual([{ group: 'g', name: 'a', version: '2.0' }]);
  });
  it('resolves several overrides together and requires each in the tree', async () => {
    let listing = '';
    const poms: string[] = [];
    const exec: ContainerExec = async (args, opts) => {
      poms.push(fs.readFileSync(path.join(dir, args[args.indexOf('-f') + 1]), 'utf8'));
      const out = args.find(a => a.startsWith('-DoutputFile='))!.split('=')[1];
      fs.writeFileSync(path.join(dir, out), listing);
      if (opts?.logFile) fs.writeFileSync(opts.logFile, '[INFO] ok\n');
      return { code: 0, stdout: '', durationMs: 1 };
    };
    fs.writeFileSync(path.join(dir, 'pom.xml'), POM.replace('<dependency><groupId>g</groupId><artifactId>t</artifactId><version>1.0</version><scope>test</scope></dependency>', '<dependency><groupId>g</groupId><artifactId>b</artifactId><version>1.0</version></dependency>'));
    const t = new MavenTool({ projectPath: dir, saferRoot: '/x', logDir: dir, exec, startContainer: false });
    await t.init();
    const a = { group: 'g', name: 'a', version: '1.0', explicitVersion: true, scope: 'compile' };
    const b = { ...a, name: 'b' };
    listing = '   g:a:jar:2.0:compile\n   g:b:jar:2.1:compile\n';
    expect(await t.resolveTree([{ dep: a, version: '2.0' }, { dep: b, version: '2.1' }])).toHaveLength(2);
    expect(poms.at(-1)).toContain('<artifactId>a</artifactId><version>2.0</version>');
    expect(poms.at(-1)).toContain('<artifactId>b</artifactId><version>2.1</version>');
    listing = '   g:a:jar:2.0:compile\n   g:b:jar:1.0:compile\n';
    await expect(t.resolveTree([{ dep: a, version: '2.0' }, { dep: b, version: '2.1' }])).rejects.toThrow('resolved tree has g:b at 1.0 instead of 2.1');
  });
  it('reports the version property of a direct dependency', async () => {
    fs.writeFileSync(path.join(dir, 'pom.xml'), POM.replace('<properties>', '<properties><a.version>1.0</a.version>').replace('<artifactId>a</artifactId><version>1.0</version>', '<artifactId>a</artifactId><version>${a.version}</version>'));
    const t = tool();
    await t.init();
    expect((await t.listDirectDeps())[0]).toEqual({ group: 'g', name: 'a', version: '1.0', explicitVersion: true, scope: 'compile', versionProperty: 'a.version' });
  });
  it('init records the Maven version from mvn -v; info() exposes java and maven', async () => {
    const exec: ContainerExec = async args => {
      calls.push(args);
      if (args[0] === 'mvn' && args[1] === '-v') return { code: 0, stdout: 'Picked up JAVA_TOOL_OPTIONS: -Xmx1024m\nApache Maven 3.9.16 (abc)\nMaven home: /usr/share/maven\n', durationMs: 1 };
      return { code: 0, stdout: '', durationMs: 1 };
    };
    const t = new MavenTool({ projectPath: dir, saferRoot: '/x', logDir: dir, exec, runHost: async () => 0 });
    await t.init();
    expect(t.info()).toEqual({ java: '17', maven: 'Apache Maven 3.9.16 (abc)' });
    expect(calls.filter(c => c[0] === 'mvn' && c[1] === '-v')).toHaveLength(1);
    const offline = tool();
    await offline.init();
    expect(offline.info()).toEqual({ java: '17', maven: 'unknown' });
  });
  it('dispose runs every cleanup step even when one fails, then rethrows the first error', async () => {
    const host: string[] = [];
    const disposing = new MavenTool({ projectPath: dir, saferRoot: '/x', logDir: dir, exec: fakeExec(), runHost: async cmd => { host.push(cmd); return 0; } });
    await disposing.init();
    host.length = 0;
    fs.writeFileSync(path.join(dir, '.safer-1-1.xml'), 'x');
    fs.rmSync(path.join(dir, 'pom.xml')); // restoring the pom now fails
    await expect(disposing.dispose()).rejects.toThrow(/ENOENT/);
    expect(fs.existsSync(path.join(dir, '.safer-1-1.xml'))).toBe(false);
    expect(host).toEqual([`docker rm -f ${CONTAINER}`]);
  });
});
