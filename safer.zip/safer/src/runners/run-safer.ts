import path from 'path';

import { BuildTool } from '../core/build-tool';
import { mavenMetadataVersionSource, sonatypeVersionSource, withFallback } from '../core/candidates';
import { BaselineError, InfrastructureError } from '../core/errors';
import { EventLog } from '../core/event-log';
import { infraFailure } from '../core/infra';
import { OsvClient } from '../core/osv-client';
import { saferRevision } from '../core/run-info';
import { scoreTree } from '../core/scoring';
import { runPlanner } from '../core/update-planner';
import { ConfigType } from '../types/config';
import { makeRandoopHooks } from './randoop/randoop-runner';

/** Signals that stop a run cleanly (SIGHUP: the terminal or SSH session went away). */
export const ABORT_SIGNALS: NodeJS.Signals[] = ['SIGINT', 'SIGTERM', 'SIGHUP'];

/** Safer's own root directory (SAFER_ROOT_PATH, or the parent of the working directory: Safer is started from src/). */
export const saferRootPath = (): string => process.env.SAFER_ROOT_PATH ?? path.resolve('..');

/** A new run directory under $SAFER_ROOT_PATH/.temp/runs/<stamp>-<project>/. */
export const createRunLog = (config: ConfigType, saferRoot = saferRootPath()): EventLog =>
  EventLog.create(path.join(saferRoot, '.temp', 'runs'), path.basename(config.projectAbsolutePath));

export type RunSaferOptions = {
  saferRoot?: string;
  planner?: typeof runPlanner; // injectable for tests
  exit?: (code: number) => void; // process.exit, injectable for tests
};

/** Runs the shared planner for any build tool: OSV client, signal handling, report path and exit code. */
export async function runSafer(config: ConfigType, tool: BuildTool, log: EventLog, opts: RunSaferOptions = {}): Promise<void> {
  const saferRoot = opts.saferRoot ?? saferRootPath();
  const planner = opts.planner ?? runPlanner;
  const exit = opts.exit ?? ((code: number) => process.exit(code));
  const projectPath = config.projectAbsolutePath;
  const osv = new OsvClient({ concurrency: config.osv?.concurrency ?? 8, retries: config.osv?.retries ?? 3, cacheDir: path.join(log.runDir, 'osv') });
  const buildFiles = tool.name === 'maven' ? 'pom.xml' : 'the build files';

  let aborted = false;
  let running: Promise<unknown> = Promise.resolve();
  const onSignal = async (sig: NodeJS.Signals) => {
    if (aborted) return;
    aborted = true; // the planner stops before its next apply/resolve/validate step and emits no further decisions
    if (sig === 'SIGHUP') {
      // the terminal is gone: writes to it must not crash the cleanup
      process.stdout.on('error', () => undefined);
      process.stderr.on('error', () => undefined);
    }
    console.log(`\n${sig} received: stopping, restoring ${buildFiles} and removing the container…`);
    // the planner's finally block restores the accepted build files, cleans up Randoop and disposes the tool
    await running.catch(() => undefined);
    try {
      await tool.dispose(); // idempotent: sweeps temporary files and the container again
    } catch (err) {
      console.error(`cleanup failed: ${err instanceof Error ? err.message : err}`);
    }
    osv.flush();
    exit(130);
  };
  for (const sig of ABORT_SIGNALS) process.once(sig, onSignal);

  console.log(`Safer run dir: ${log.runDir}`);
  try {
    running = planner(
      {
        projectPath,
        weights: config.weightVulnerability,
        buildProject: config.executions.buildProject,
        projectTests: config.executions.projectTests,
        exploratoryTesting: config.executions.exploratoryTesting,
        allowPrerelease: config.allowPrerelease ?? false,
        alignmentCheck: config.alignmentCheck ?? true,
        smokeTest: config.smokeTest,
      },
      {
        tool,
        log,
        scoreTree: tree => scoreTree(tree, osv, config.weightVulnerability),
        versionSource: withFallback(sonatypeVersionSource(), mavenMetadataVersionSource()),
        randoop: config.executions.exploratoryTesting
          ? makeRandoopHooks({
              projectPath,
              saferRoot,
              timeLimitSec: config.exploratoryTestingParams?.timeLimitGeneratingTests ?? 60,
              classesDir: tool.classesDir(),
            })
          : undefined,
        isAborted: () => aborted,
        infraCheck: text => infraFailure(text),
        saferRevision: saferRevision(saferRoot),
      },
    );
    await running;
    console.log(`Report: ${path.join(log.runDir, 'report.md')}`);
  } catch (err) {
    if (aborted) return; // the signal handler finishes cleanup and exits 130
    console.error(err instanceof BaselineError || err instanceof InfrastructureError ? `Aborted: ${err.message}` : `Safer failed: ${err instanceof Error ? err.stack : err}`);
    process.exitCode = 1;
  } finally {
    osv.flush();
    for (const sig of ABORT_SIGNALS) process.removeListener(sig, onSignal);
  }
}
