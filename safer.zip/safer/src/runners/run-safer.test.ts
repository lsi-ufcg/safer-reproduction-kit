import fs from 'fs';
import os from 'os';
import path from 'path';

import { afterEach, describe, expect, it, vi } from 'vitest';

import { BuildTool } from '../core/build-tool';
import { BaselineError } from '../core/errors';
import { EventLog } from '../core/event-log';
import { ConfigType } from '../types/config';
import { ABORT_SIGNALS, runSafer } from './run-safer';

const config = (projectAbsolutePath: string): ConfigType => ({
  projectType: 'gradle',
  projectAbsolutePath,
  weightVulnerability: { low: 1, medium: 2, high: 3, critical: 5 },
  executions: { buildProject: false, projectTests: false, exploratoryTesting: false, clearLastLogs: false, clearLastReport: false },
});

const fakeTool = (): BuildTool & { dispose: ReturnType<typeof vi.fn> } =>
  ({
    name: 'gradle',
    projectName: () => 'p',
    hasTests: () => false,
    init: async () => undefined,
    listDirectDeps: async () => [],
    resolveTree: async () => [],
    apply: async () => ({ via: 'literal' }),
    restore: async () => undefined,
    accept: async () => undefined,
    build: async () => ({ ok: true, logFile: '', durationMs: 0 }),
    classpath: async () => '',
    classesDir: () => 'build/classes/java/main',
    packagedArtifact: async () => null,
    dispose: vi.fn(async () => undefined),
  }) as never;

const setup = () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'safer-run-'));
  const log = EventLog.create(path.join(dir, 'runs'), 'p', { console: () => undefined });
  return { dir, log };
};

describe('runSafer', () => {
  afterEach(() => {
    process.exitCode = undefined;
    vi.restoreAllMocks();
  });

  it('handles SIGHUP like SIGINT and SIGTERM', () => {
    expect(ABORT_SIGNALS).toEqual(['SIGINT', 'SIGTERM', 'SIGHUP']);
  });

  it('a BaselineError sets exit code 1 and removes the signal handlers', async () => {
    vi.spyOn(console, 'log').mockImplementation(() => undefined);
    const errors = vi.spyOn(console, 'error').mockImplementation(() => undefined);
    const { dir, log } = setup();
    const before = process.listenerCount('SIGTERM');
    await runSafer(config(dir), fakeTool(), log, { saferRoot: dir, planner: async () => Promise.reject(new BaselineError('baseline build failed')) });
    expect(process.exitCode).toBe(1);
    expect(errors).toHaveBeenCalledWith('Aborted: baseline build failed');
    expect(process.listenerCount('SIGTERM')).toBe(before);
  });

  it('passes the tool, its classesDir and the abort flag to the planner, and stops on a signal', async () => {
    vi.spyOn(console, 'log').mockImplementation(() => undefined);
    const { dir, log } = setup();
    const tool = fakeTool();
    const exit = vi.fn();
    let finish!: () => void;
    let seen: { tool?: BuildTool; isAborted?: () => boolean; randoop?: unknown } = {};
    const run = runSafer({ ...config(dir), executions: { ...config(dir).executions, buildProject: true, exploratoryTesting: true } }, tool, log, {
      saferRoot: dir,
      exit,
      planner: (_cfg, d) => {
        seen = d;
        return new Promise(resolve => (finish = () => resolve(undefined as never)));
      },
    });
    await new Promise(r => setTimeout(r, 10));
    expect(seen.tool).toBe(tool);
    expect(seen.randoop).toBeDefined();
    expect(seen.isAborted!()).toBe(false);

    const handlers = process.listeners('SIGTERM');
    const ours = handlers[handlers.length - 1] as (sig: NodeJS.Signals) => Promise<void>;
    const handled = ours('SIGTERM');
    expect(seen.isAborted!()).toBe(true);
    finish(); // the planner returns once it sees the abort
    await handled;
    await run;
    expect(tool.dispose).toHaveBeenCalled();
    expect(exit).toHaveBeenCalledWith(130);
  });
});
