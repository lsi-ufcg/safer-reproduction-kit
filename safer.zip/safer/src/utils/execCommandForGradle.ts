import os from 'os';
import { execSync } from 'child_process';
import loggerSync from './logger';
import * as path from 'path';
import * as dotenv from 'dotenv';

dotenv.config({
    path: path.resolve('.', '../../../.env'),
});

const saferPath = process.env.SAFER_ROOT_PATH;

function execCommand(command: string) {
  try {
    execSync(command, {stdio: 'inherit', encoding: 'utf-8' });
  } catch (error) {
    loggerSync({ level: 'error', message: 'Error executing command:', object: error });
    throw error;
  }
}

export default execCommand;

console.log(`${saferPath}/src/runners/maven/run-maven-build-for-gradle.sh`);
execCommand(`${saferPath}/src/runners/maven/run-maven-build-for-gradle.sh`);