import winston, { format } from 'winston';

import { constants } from './contants';

type LogLevel = 'info' | 'error' | 'dir';

interface LoggerOptions {
  level: LogLevel;
  message?: string;
  object?: any;
}

const consoleFormat = format.combine(format.printf(info => `[${info.level.toUpperCase()}] ${info.timestamp}: ${info.message}`));

const LOGGER = winston.createLogger({
  level: 'info',
  format: format.combine(winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }), winston.format.errors({ stack: true }), winston.format.splat(), winston.format.json()),
  transports: [
    //   new winston.transports.File({ filename: `${constants.tempDir}/logs/error.log`, level: 'error' }),
    //   new winston.transports.File({ filename: `${constants.tempDir}/logs/combined.log` }),
    new winston.transports.Console({ format: consoleFormat }),
  ],
});

const logWithConsoleFallback = (level: LogLevel, message: string, object?: any) => {
  const logFunctions = {
    info: { logger: (m: string, o?: any) => LOGGER.info(m, o), console: console.log },
    error: { logger: (m: string, o?: any) => LOGGER.error(m, o), console: console.error },
  };

  if (level !== 'dir') {
    if (object !== undefined) {
      // logFunctions[level].logger(message, object);
      logFunctions[level].console(message, object);
    } else {
      // logFunctions[level].logger(message);
      logFunctions[level].console(message);
    }
  } else {
    // LOGGER.info(JSON.stringify(object, null, 2));
    console.dir(object, { depth: null });
  }
};

const loggerSync = ({ level, message = '', object }: LoggerOptions) => {
  const supportedLevels: LogLevel[] = ['info', 'error', 'dir'];

  if (supportedLevels.includes(level)) {
    logWithConsoleFallback(level, message, object);
  } else {
    console.error(`Level not supported: ${level}.`);
  }
};

export default loggerSync;
