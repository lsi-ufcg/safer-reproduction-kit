export const constants = {
  randoopCommonFiles: ['randoop-all-4.3.2.jar', 'junit-4.13.2.jar', 'hamcrest-core-1.3.jar'],
};
