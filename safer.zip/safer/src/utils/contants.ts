import path from 'path';

import { ProjectType } from '#types/config';

export const constants = {
  getClassPath: {
    gradle: 'build/classes',
    maven: 'target/classes',
  } as Record<ProjectType, string>,
  randoopCommonFiles: ['randoop-all-4.3.2.jar', 'junit-4.13.2.jar', 'hamcrest-core-1.3.jar'],
  tempDir: path.join(process.cwd(), '.temp'),
};
