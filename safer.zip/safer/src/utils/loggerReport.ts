import winston, { format } from 'winston';
import chalk from 'chalk';

// import { constants } from './contants';

type ColorKey = 'red' | 'blue' | 'green' | 'yellow' | 'bold' | 'bold.underline';

const colors: { [key in ColorKey]: (text: string) => string } = {
  red: chalk.red,
  blue: chalk.blue,
  green: chalk.green,
  yellow: chalk.yellow,
  bold: chalk.bold,
  'bold.underline': chalk.bold.underline,
};

const colorizeDynamic = format(info => {
  const color: string | undefined = info.metadata?.color;
  if (color && colors[color as ColorKey]) {
    const colorize = colors[color as ColorKey];
    info.message = colorize(info.message);
  }

  if (info.metadata) {
    delete info.metadata.color;
  }
  return info;
});

const consoleFormat = format.combine(
  format.colorize(),
  colorizeDynamic(),
  format.printf(info => info.message),
);

// const fileFormat = format.combine(format.printf(info => info.message));

const LOGGER_REPORT = winston.createLogger({
  level: 'info',
  format: format.combine(format.timestamp(), format.metadata({ fillExcept: ['message', 'level', 'timestamp', 'label'] })),
  transports: [
    // new winston.transports.File({
    //   filename: `${constants.tempDir}/report/maven.log`,
    //   format: fileFormat,
    // }),
    new winston.transports.Console({
      format: consoleFormat,
    }),
  ],
});

export default LOGGER_REPORT;
