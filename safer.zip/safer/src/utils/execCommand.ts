import { execSync } from 'child_process';

import loggerSync from './logger';

function execCommand(command: string) {
  try {
    execSync(command, { stdio: 'inherit', encoding: 'utf-8' });
  } catch (error) {
    loggerSync({ level: 'error', message: 'Error executing command:', object: error });
    throw error;
  }
}

export default execCommand;
