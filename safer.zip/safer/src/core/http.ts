import { LookupError } from './errors';

export type RetryOptions = {
  retries: number;
  backoffMs: number;
  timeoutMs: number;
  fetchImpl?: typeof fetch;
  source: 'osv' | 'sonatype' | 'maven-central';
  target: string;
};

const RETRYABLE = (status: number) => status === 429 || status >= 500;

/** JSON fetch (a non-JSON body is returned as text) that retries 429/5xx/network errors with exponential backoff. Other statuses are returned to the caller. */
export async function fetchJsonWithRetry(url: string, init: RequestInit, opts: RetryOptions): Promise<{ status: number; body: any }> {
  const doFetch = opts.fetchImpl ?? fetch;
  let lastProblem = '';
  for (let attempt = 0; attempt <= opts.retries; attempt++) {
    if (attempt > 0) await new Promise(r => setTimeout(r, opts.backoffMs * 2 ** (attempt - 1)));
    try {
      const res = await doFetch(url, { ...init, signal: AbortSignal.timeout(opts.timeoutMs) });
      if (RETRYABLE(res.status)) {
        lastProblem = `HTTP ${res.status}`;
        continue;
      }
      const text = await res.text();
      let body: any = null;
      try {
        body = text ? JSON.parse(text) : null;
      } catch {
        body = text;
      }
      return { status: res.status, body };
    } catch (err) {
      lastProblem = err instanceof Error ? err.message : String(err);
    }
  }
  throw new LookupError(opts.source, opts.target, `${lastProblem} after ${opts.retries + 1} attempts`);
}
