import { describe, expect, it } from 'vitest';

import { LookupError } from './errors';
import { OsvClient, toOsvRecord } from './osv-client';

const json = (status: number, body: unknown) => new Response(JSON.stringify(body), { status });

function fakeFetch(routes: (url: string, body: any) => Response) {
  const calls: { url: string; body: any }[] = [];
  const f = (async (url: string, init?: RequestInit) => {
    const body = init?.body ? JSON.parse(String(init.body)) : undefined;
    calls.push({ url, body });
    return routes(url, body);
  }) as unknown as typeof fetch;
  return { f, calls };
}

describe('OsvClient.vulnIds', () => {
  it('batches unknown GAVs, follows page tokens and caches', async () => {
    const { f, calls } = fakeFetch((url, body) => {
      if (url.endsWith('/querybatch')) {
        return json(200, { results: body.queries.map((q: any) => (q.package.name === 'g:a' ? { vulns: [{ id: 'GHSA-1' }], next_page_token: 't1' } : {})) });
      }
      if (url.endsWith('/query')) return json(200, { vulns: [{ id: 'GHSA-2' }] });
      return json(404, {});
    });
    const osv = new OsvClient({ fetchImpl: f, backoffMs: 1 });
    const gavs = [{ group: 'g', name: 'a', version: '1' }, { group: 'g', name: 'b', version: '1' }];
    const ids = await osv.vulnIds(gavs);
    expect(ids.get('g:a:1')).toEqual(['GHSA-1', 'GHSA-2']);
    expect(ids.get('g:b:1')).toEqual([]);
    await osv.vulnIds(gavs);
    expect(calls.filter(c => c.url.endsWith('/querybatch'))).toHaveLength(1);
  });
  it('throws LookupError instead of returning empty data', async () => {
    const { f } = fakeFetch(() => json(503, {}));
    const osv = new OsvClient({ fetchImpl: f, backoffMs: 1, retries: 1 });
    await expect(osv.vulnIds([{ group: 'g', name: 'a', version: '1' }])).rejects.toBeInstanceOf(LookupError);
  });
});

describe('OsvClient.vulnIds rejects malformed 200 responses', () => {
  const gav = { group: 'g', name: 'a', version: '1' };
  it('malformed page while paging', async () => {
    const { f } = fakeFetch(url =>
      url.endsWith('/querybatch') ? json(200, { results: [{ vulns: [{ id: 'GHSA-1' }], next_page_token: 't' }] }) : json(200, { vulns: 'oops' }),
    );
    await expect(new OsvClient({ fetchImpl: f, backoffMs: 1 }).vulnIds([gav])).rejects.toBeInstanceOf(LookupError);
  });
  it('null batch result', async () => {
    const { f } = fakeFetch(() => json(200, { results: [null] }));
    await expect(new OsvClient({ fetchImpl: f, backoffMs: 1 }).vulnIds([gav])).rejects.toBeInstanceOf(LookupError);
  });
  it('results length mismatch', async () => {
    const { f } = fakeFetch(() => json(200, { results: [{}, {}] }));
    await expect(new OsvClient({ fetchImpl: f, backoffMs: 1 }).vulnIds([gav])).rejects.toBeInstanceOf(LookupError);
  });
  it('page body that is not an object', async () => {
    const { f } = fakeFetch(url => (url.endsWith('/querybatch') ? json(200, { results: [{ next_page_token: 't' }] }) : json(200, null)));
    await expect(new OsvClient({ fetchImpl: f, backoffMs: 1 }).vulnIds([gav])).rejects.toBeInstanceOf(LookupError);
  });
});

describe('OsvClient.records', () => {
  it('fetches each id once; 404 is a LookupError', async () => {
    const { f, calls } = fakeFetch(url =>
      url.endsWith('/vulns/GHSA-1') ? json(200, { id: 'GHSA-1', aliases: ['CVE-1'], database_specific: { severity: 'HIGH' } }) : json(404, {}),
    );
    const osv = new OsvClient({ fetchImpl: f, backoffMs: 1 });
    const recs = await osv.records(['GHSA-1', 'GHSA-1']);
    expect(recs.get('GHSA-1')?.aliases).toEqual(['CVE-1']);
    expect(calls).toHaveLength(1);
    await expect(osv.records(['GHSA-404'])).rejects.toBeInstanceOf(LookupError);
  });
});

describe('toOsvRecord', () => {
  it('prefers top-level CVSS_V3, falls back to affected[].severity', () => {
    expect(toOsvRecord({ id: 'x', severity: [{ type: 'CVSS_V3', score: 'CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H' }] }).cvssV3).toMatch(/^CVSS:3\.1/);
    expect(toOsvRecord({ id: 'x', affected: [{ severity: [{ type: 'CVSS_V3', score: 'CVSS:3.0/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N' }] }] }).cvssV3).toMatch(/^CVSS:3\.0/);
    expect(toOsvRecord({ id: 'x', severity: [{ type: 'CVSS_V4', score: 'CVSS:4.0/AV:N' }] }).cvssV3).toBeUndefined();
  });
});
