import fs from 'fs';
import os from 'os';
import path from 'path';

import { describe, expect, it } from 'vitest';

import { EventLog, formatConsoleLine } from './event-log';

const ts = '2026-10-05T15:00:01.000Z';

describe('formatConsoleLine', () => {
  it('formats decisions and hides candidates/scored', () => {
    const t = new Date(ts);
    const hh = `${String(t.getHours()).padStart(2, '0')}:00:01`;
    expect(formatConsoleLine({ type: 'adopted', ts, dep: 'io.minio:minio', from: '8.5.2', version: '8.5.17', rate: 1401, currentRate: 1450.2, added: [], removed: ['a', 'b', 'c'] }))
      .toBe(`${hh} ADOPT     io.minio:minio 8.5.2 → 8.5.17 · rate 1450.2 → 1401.0 · fixed 3, introduced 0`);
    expect(formatConsoleLine({ type: 'rejected', ts, dep: 'g:a', version: '2', step: 'smoke', firstError: 'exit 1', logFile: 'attempts/g_a/2/smoke.log' }))
      .toBe(`${hh} REJECT    g:a 2 · smoke: exit 1 (log: attempts/g_a/2/smoke.log)`);
    expect(formatConsoleLine({ type: 'scored', ts, dep: 'g:a', version: '2' })).toBeNull();
  });
  it('names a group and its lagging members on ADOPT and REJECT lines', () => {
    const members = [{ dep: 'io.springfox:springfox-swagger-ui', from: '2.9.2', to: '2.10.4' }, { dep: 'io.springfox:springfox-swagger2', from: '2.9.2', to: '2.10.5' }];
    const ts = new Date().toISOString();
    const adopt = formatConsoleLine({ type: 'adopted', ts, dep: 'io.springfox [springfox-swagger-ui, springfox-swagger2]', from: '2.9.2', version: '2.10.5', currentRate: 45, rate: 22.5, removed: ['F1'], added: [], members, groupReason: 'family' })!;
    expect(adopt).toContain('ADOPT     io.springfox [springfox-swagger-ui, springfox-swagger2] 2.9.2 → 2.10.5 (springfox-swagger-ui 2.10.4) · rate 45.0 → 22.5');
    const reject = formatConsoleLine({ type: 'rejected', ts, dep: 'io.springfox [springfox-swagger-ui, springfox-swagger2]', version: '2.10.5', step: 'build', firstError: 'cannot find symbol', members })!;
    expect(reject).toContain('REJECT    io.springfox [springfox-swagger-ui, springfox-swagger2] 2.10.5 (springfox-swagger-ui 2.10.4) · build: cannot find symbol');
  });
  it('formats randoop generation failure as non-fatal, run-failed, and excluded with a log', () => {
    const t = new Date(ts);
    const hh = `${String(t.getHours()).padStart(2, '0')}:00:01`;
    expect(formatConsoleLine({ type: 'baseline', ts, step: 'randoop', firstError: 'javac error', logFile: 'baseline/randoop-generate.log', data: { ok: false } }))
      .toBe(`${hh} BASELINE  Randoop unusable, continuing without it · javac error (log: baseline/randoop-generate.log)`);
    expect(formatConsoleLine({ type: 'baseline', ts, step: 'build', firstError: 'boom', logFile: 'baseline/build.log', data: { ok: false } }))
      .toBe(`${hh} BASELINE  FAILED · build: boom (log: baseline/build.log)`);
    expect(formatConsoleLine({ type: 'run-failed', ts, step: 'resolve', reason: 'mvn failed' })).toBe(`${hh} RUN FAILED · resolve: mvn failed`);
    expect(formatConsoleLine({ type: 'excluded', ts, dep: 'g:a', version: '2', step: 'resolve', reason: 'empty tree', logFile: 'mvn-1.log' }))
      .toBe(`${hh} EXCLUDE   g:a 2 · resolve: empty tree (log: mvn-1.log)`);
  });
});

describe('EventLog', () => {
  it('creates the run dir, appends jsonl and makes attempt dirs', () => {
    const base = fs.mkdtempSync(path.join(os.tmpdir(), 'safer-log-'));
    const lines: string[] = [];
    const log = EventLog.create(base, 'integration-api', { now: new Date(2026, 9, 5, 12, 0, 0), console: l => lines.push(l) });
    expect(path.basename(log.runDir)).toBe('20261005-120000-integration-api');
    log.emit({ type: 'kept', dep: 'g:a', version: '1', reason: 'no candidate scores lower than current (rate 10.0)' });
    log.emit({ type: 'scored', dep: 'g:a', version: '2', rate: 12 });
    const jsonl = fs.readFileSync(path.join(log.runDir, 'decisions.jsonl'), 'utf8').trim().split('\n').map(l => JSON.parse(l));
    expect(jsonl.map(e => e.type)).toEqual(['kept', 'scored']);
    expect(lines).toHaveLength(1);
    expect(fs.existsSync(log.attemptDir('com.x:y', '1.0'))).toBe(true);
    expect(log.attemptDir('com.x:y', '1.0')).toBe(path.join(log.runDir, 'attempts', 'com.x_y', '1.0'));
  });
  it('writes sorted, de-duplicated trees', () => {
    const log = EventLog.create(fs.mkdtempSync(path.join(os.tmpdir(), 'safer-log-')), 'p', { console: () => {} });
    log.writeTree('baseline', [{ group: 'z', name: 'b', version: '1' }, { group: 'a', name: 'c', version: '2' }, { group: 'z', name: 'b', version: '1' }]);
    expect(fs.readFileSync(path.join(log.runDir, 'trees', 'baseline.txt'), 'utf8')).toBe('a:c:2\nz:b:1\n');
  });
});
