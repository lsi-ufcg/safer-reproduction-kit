import { describe, expect, it } from 'vitest';

import { listCandidates, mavenMetadataVersionSource, planOverrides, selectCandidates, selectGroupCandidates, sonatypeVersionSource, withFallback } from './candidates';
import { LookupError } from './errors';

describe('selectCandidates', () => {
  const available = ['2.8.17', '2.8.0', '2.7.0', '2.7.0-RC1', '2.1.0', '2.0.4', '2.0.2', '1.6.0', '20051005'];
  it('keeps only strictly newer, non-pre-release, non-date versions, ascending', () => {
    const r = selectCandidates('2.0.2', available, { allowPrerelease: false });
    expect(r.candidates).toEqual(['2.0.4', '2.1.0', '2.7.0', '2.8.0', '2.8.17']);
    expect(r.currentFound).toBe(true);
    expect(r.olderCount).toBe(1);
    expect(r.dropped.prerelease).toEqual(['2.7.0-RC1']);
    expect(r.dropped.dateStyle).toEqual(['20051005']);
  });
  it('allows pre-releases when asked or when current is one', () => {
    expect(selectCandidates('2.0.2', available, { allowPrerelease: true }).candidates).toContain('2.7.0-RC1');
    expect(selectCandidates('2.7.0-RC1', available, { allowPrerelease: false }).candidates).toEqual(['2.7.0', '2.8.0', '2.8.17']);
  });
  it('never offers downgrades when current is missing', () => {
    const r = selectCandidates('2.0.3', available, { allowPrerelease: false });
    expect(r.currentFound).toBe(false);
    expect(r.candidates).toEqual([]);
  });
  it('drops other flavors', () => {
    const r = selectCandidates('32.1.2-jre', ['33.0.0-android', '33.0.0-jre', '32.1.2-jre'], { allowPrerelease: false });
    expect(r.candidates).toEqual(['33.0.0-jre']);
    expect(r.dropped.flavor).toEqual(['33.0.0-android']);
  });
});

describe('sonatypeVersionSource', () => {
  const page = (versions: string[], pageCount: number) =>
    new Response(JSON.stringify({ components: versions.map(version => ({ version })), pageCount }), { status: 200 });

  it('pages until the current version is found', async () => {
    const pages = [page(['3.0', '2.9'], 3), page(['2.8', '2.7'], 3), page(['2.6'], 3)];
    let calls = 0;
    const source = sonatypeVersionSource({ fetchImpl: (async () => pages[calls++]) as unknown as typeof fetch, backoffMs: 1 });
    const versions = await source({ group: 'g', name: 'a', version: '2.7' });
    expect(versions).toEqual(['3.0', '2.9', '2.8', '2.7']);
    expect(calls).toBe(2);
  });
  it('turns a failing lookup into LookupError', async () => {
    const source = sonatypeVersionSource({ fetchImpl: (async () => new Response('', { status: 404 })) as unknown as typeof fetch, backoffMs: 1 });
    await expect(source({ group: 'g', name: 'a', version: '1' })).rejects.toBeInstanceOf(LookupError);
  });
  it('listCandidates combines source and selection', async () => {
    const r = await listCandidates({ group: 'g', name: 'a', version: '1.0' }, { allowPrerelease: false }, async () => ['1.1', '1.0', '0.9']);
    expect(r.candidates).toEqual(['1.1']);
  });
});

describe('mavenMetadataVersionSource', () => {
  const fetchOf = (res: () => Response, urls: string[] = []) => (async (url: string) => (urls.push(url), res())) as unknown as typeof fetch;

  it('reads every <version> of the artifact from maven-metadata.xml', async () => {
    const xml = '<metadata><versioning><latest>2.0</latest><versions>\n<version>1.0</version>\n<version> 2.0 </version></versions></versioning></metadata>';
    const urls: string[] = [];
    const source = mavenMetadataVersionSource({ fetchImpl: fetchOf(() => new Response(xml, { status: 200 }), urls), backoffMs: 1 });
    expect(await source({ group: 'com.example.lib', name: 'core', version: '1.0' })).toEqual(['1.0', '2.0']);
    expect(urls).toEqual(['https://repo1.maven.org/maven2/com/example/lib/core/maven-metadata.xml']);
  });
  it('treats 404 as "not on Maven Central" and other failures as LookupError', async () => {
    const notFound = mavenMetadataVersionSource({ fetchImpl: fetchOf(() => new Response('', { status: 404 })), backoffMs: 1 });
    expect(await notFound({ group: 'g', name: 'a', version: '1' })).toEqual([]);
    const forbidden = mavenMetadataVersionSource({ fetchImpl: fetchOf(() => new Response('', { status: 403 })), backoffMs: 1 });
    await expect(forbidden({ group: 'g', name: 'a', version: '1' })).rejects.toBeInstanceOf(LookupError);
  });
});

describe('withFallback', () => {
  const dep = { group: 'g', name: 'a', version: '1' };
  const failing = async () => {
    throw new LookupError('sonatype', 'g:a', 'HTTP 500');
  };

  it('uses the fallback only when the primary lookup fails', async () => {
    let fallbackCalls = 0;
    const fallback = async () => (fallbackCalls++, ['2']);
    expect(await withFallback(async () => ['1'], fallback)(dep)).toEqual(['1']);
    expect(fallbackCalls).toBe(0);
    expect(await withFallback(failing, fallback)(dep)).toEqual(['2']);
  });
  it('keeps the primary error when both fail', async () => {
    const otherFailure = async () => {
      throw new LookupError('maven-central', 'g:a', 'HTTP 503');
    };
    await expect(withFallback(failing, otherFailure)(dep)).rejects.toThrow('sonatype lookup failed for g:a: HTTP 500');
  });
});

describe('selectGroupCandidates', () => {
  const member = (name: string, current: string, available: string[]) => ({ dep: { group: 'g', name, version: current }, list: selectCandidates(current, available, { allowPrerelease: false }) });

  it('moves every member to the same target', () => {
    const r = selectGroupCandidates([member('a', '2.9.2', ['2.9.2', '2.10.0', '3.0.0']), member('b', '2.9.2', ['2.9.2', '2.10.0', '3.0.0'])]);
    expect(r.plans).toEqual([
      { version: '2.10.0', versions: { 'g:a': '2.10.0', 'g:b': '2.10.0' } },
      { version: '3.0.0', versions: { 'g:a': '3.0.0', 'g:b': '3.0.0' } },
    ]);
  });
  it('gives a lagging member its newest release in the target major.minor', () => {
    const r = selectGroupCandidates([member('core', '2.14.2', ['2.14.2', '2.15.0', '2.15.1']), member('annotations', '2.14.2', ['2.14.2', '2.15.0'])]);
    expect(r.plans).toEqual([
      { version: '2.15.0', versions: { 'g:core': '2.15.0', 'g:annotations': '2.15.0' } },
      { version: '2.15.1', versions: { 'g:core': '2.15.1', 'g:annotations': '2.15.0' } },
    ]);
  });
  it('drops a target that some member cannot follow', () => {
    const r = selectGroupCandidates([member('a', '1.0', ['1.0', '1.1', '2.0']), member('b', '1.0', ['1.0', '1.1'])]);
    expect(r.plans.map(p => p.version)).toEqual(['1.1']);
  });
  it('deduplicates plans with identical member versions, keeping the first target', () => {
    const r = selectGroupCandidates([member('a', '1.0', ['1.0', '1.1']), member('b', '1.0', ['1.0', '1.1', '1.1.1'])]);
    expect(r.plans).toEqual([
      { version: '1.1', versions: { 'g:a': '1.1', 'g:b': '1.1' } },
      { version: '1.1.1', versions: { 'g:a': '1.1', 'g:b': '1.1.1' } },
    ]);
  });
  it('explains a member whose current version is not on Maven Central', () => {
    const r = selectGroupCandidates([member('a', '1.0', ['1.0', '1.1']), member('b', '9.9-internal', ['1.0'])]);
    expect(r.plans).toEqual([]);
    expect(r.reason).toContain('g:b');
  });
  it('is the plain candidate list for a single member', () => {
    const m = member('a', '1.0', ['1.0', '1.1', '1.2']);
    expect(selectGroupCandidates([m]).plans).toEqual(m.list.candidates.map(v => ({ version: v, versions: { 'g:a': v } })));
  });
});

describe('planOverrides', () => {
  it('maps each member to its plan version, in member order', () => {
    const a = { group: 'g', name: 'a', version: '1.0', explicitVersion: true, scope: 'compile' };
    const b = { ...a, name: 'b' };
    const unit = { id: 'x', label: 'x', members: [a, b], reason: 'family' as const };
    expect(planOverrides(unit, { version: '1.1', versions: { 'g:a': '1.1', 'g:b': '1.0.5' } })).toEqual([{ dep: a, version: '1.1' }, { dep: b, version: '1.0.5' }]);
  });
});
