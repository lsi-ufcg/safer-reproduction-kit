/** A remote lookup (OSV, Sonatype, Maven Central) failed for good: callers must not treat it as "no data". */
export class LookupError extends Error {
  constructor(
    readonly source: 'osv' | 'sonatype' | 'maven-central',
    readonly target: string,
    message: string,
  ) {
    super(`${source} lookup failed for ${target}: ${message}`);
    this.name = 'LookupError';
  }
}

/** The project does not build/test on its current versions, so no candidate can be judged. */
export class BaselineError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'BaselineError';
  }
}

/** A Maven (or other build-tool) resolution call failed or returned an unusable result; logFile keeps its output. */
export class ResolveError extends Error {
  constructor(
    message: string,
    readonly logFile?: string,
  ) {
    super(message);
    this.name = 'ResolveError';
  }
}

/** The build's repository or network failed (see infra.ts): no candidate verdict can be trusted, so the run stops. */
export class InfrastructureError extends Error {
  constructor(
    message: string,
    readonly logFile?: string,
  ) {
    super(message);
    this.name = 'InfrastructureError';
  }
}
