import { describe, expect, it } from 'vitest';

import { buildReport, cell, renderMarkdown } from './report';
import { TreeScore } from './scoring';

const v = (id: string, severity: 'high' | 'critical', score: number, pkg: string) => ({ id, ids: [id], aliases: [], score, severity, scoreSource: 'cvss3' as const, packages: [pkg] });
const before: TreeScore = { rate: 49 + 22.5, vulns: [v('GHSA-a', 'critical', 9.8, 'g:a:1'), v('GHSA-b', 'high', 7.5, 'g:a:1')], bySeverity: { low: 0, medium: 0, high: 1, critical: 1, unknown: 0 } };
const after: TreeScore = { rate: 22.5, vulns: [v('GHSA-b', 'high', 7.5, 'g:a:2')], bySeverity: { low: 0, medium: 0, high: 1, critical: 0, unknown: 0 } };

describe('report', () => {
  const r = buildReport({
    project: 'demo', runDir: '/r', startedAt: 's', finishedAt: 'f', before, after,
    events: [
      { type: 'adopted', ts: 't', dep: 'g:a', from: '1', version: '2', rate: 22.5, currentRate: 71.5, removed: ['GHSA-a'], added: [] },
      { type: 'rejected', ts: 't', dep: 'g:a', version: '3', step: 'build', firstError: 'cannot find symbol', logFile: '/r/attempts/g_a/3/build.log' },
      { type: 'excluded', ts: 't', dep: 'g:b', version: '5', step: 'lookup', reason: 'osv lookup failed' },
      { type: 'kept', ts: 't', dep: 'g:b', version: '4', reason: 'no candidate scores lower than current' },
      { type: 'skipped', ts: 't', dep: 'g:c', version: '1', reason: 'version managed by parent/BOM' },
    ],
  });
  it('summarises distinct counts and fixed/introduced', () => {
    expect(r.before).toEqual({ distinct: 2, rate: 71.5, bySeverity: before.bySeverity });
    expect(r.after.distinct).toBe(1);
    expect(r.fixed.map(x => x.id)).toEqual(['GHSA-a']);
    expect(r.introduced).toEqual([]);
  });
  it('lists one decision per dependency', () => {
    expect(r.decisions).toEqual([
      { dep: 'g:a', from: '1', to: '2', outcome: 'adopted', note: 'fixed 1, introduced 0' },
      { dep: 'g:b', from: '4', to: '4', outcome: 'kept', note: 'no candidate scores lower than current' },
      { dep: 'g:c', from: '1', to: '1', outcome: 'skipped', note: 'version managed by parent/BOM' },
    ]);
    expect(r.rejected).toHaveLength(1);
    expect(r.excluded).toHaveLength(1);
  });
  it('labels grouped decisions and lists their members', () => {
    const label = 'io.springfox [springfox-swagger-ui, springfox-swagger2]';
    const members = [{ dep: 'io.springfox:springfox-swagger-ui', from: '2.9.2', to: '3.0.0' }, { dep: 'io.springfox:springfox-swagger2', from: '2.9.2', to: '3.0.0' }];
    const report = buildReport({
      project: 'demo', runDir: '/r', startedAt: 's', finishedAt: 'f', before, after,
      events: [{ type: 'adopted', ts: 't', dep: label, from: '2.9.2', version: '3.0.0', rate: 22.5, currentRate: 71.5, removed: [], added: [], members, groupReason: 'family' }],
    });
    expect(report.decisions[0]).toEqual({ dep: label, from: '2.9.2', to: '3.0.0', outcome: 'adopted', note: 'group (family): fixed 0, introduced 0', members });
    expect(renderMarkdown(report)).toContain(`| ${label} | 2.9.2 | 3.0.0 | adopted | \`group (family): fixed 0, introduced 0\` |`);
    expect(report.limitations.some(l => l.includes('upgraded together'))).toBe(true);
  });
  it('passes members through to rejected and excluded rows, and only for grouped events', () => {
    const members = [{ dep: 'g:a', from: '1.0.1', to: '1.0.2' }, { dep: 'g:b', from: '1.0.0', to: '1.0.2' }];
    const report = buildReport({
      project: 'demo', runDir: '/r', startedAt: 's', finishedAt: 'f', before, after,
      events: [
        { type: 'rejected', ts: 't', dep: 'g [a, b]', version: '1.0.2', step: 'build', firstError: 'boom', members },
        { type: 'excluded', ts: 't', dep: 'g [a, b]', version: '1.0.3', step: 'lookup', reason: 'down', members },
        { type: 'rejected', ts: 't', dep: 'g:c', version: '2', step: 'build', firstError: 'x' },
      ],
    });
    expect(report.rejected[0].members).toEqual(members);
    expect(report.excluded[0].members).toEqual(members);
    expect('members' in report.rejected[1]).toBe(false);
  });
  it('renders markdown with the key sections', () => {
    const md = renderMarkdown(r);
    for (const h of ['# Safer report — demo', '## Vulnerabilities (distinct IDs, runtime tree)', '## Decisions', '## Rejected candidates', '## Excluded candidates', '## Limitations']) expect(md).toContain(h);
    expect(md).toContain('| critical | 1 | 0 |');
  });
  it('cell() escapes pipes, collapses newlines and wraps free text in backticks', () => {
    expect(cell('a|b\nc')).toBe('a\\|b c');
    expect(cell('Optional<T> is not | a type', { code: true })).toBe('`Optional<T> is not \\| a type`');
    expect(cell('', { code: true })).toBe('');
    const md = renderMarkdown(
      buildReport({
        project: 'demo', runDir: '/r', startedAt: 's', finishedAt: 'f', before, after, notes: ['final tree could not be re-resolved: boom'],
        events: [{ type: 'rejected', ts: 't', dep: 'g:a', version: '3', step: 'build', firstError: 'incompatible types: List<T>\ncannot be | converted', logFile: 'attempts/g_a/3/build.log' }],
      }),
    );
    expect(md).toContain('| g:a | 3 | build | `incompatible types: List<T> cannot be \\| converted` | attempts/g_a/3/build.log |');
    expect(md).toContain('## Notes\n\n- final tree could not be re-resolved: boom');
  });
});
