import fs from 'fs';
import path from 'path';

import { LookupError } from './errors';
import { fetchJsonWithRetry } from './http';
import { mapLimit } from './limit';
import { Gav, gavKey } from './model';

export type OsvRecord = { id: string; aliases: string[]; cvssV3?: string; githubSeverity?: string };

export interface VulnSource {
  vulnIds(gavs: Gav[]): Promise<Map<string, string[]>>;
  records(ids: string[]): Promise<Map<string, OsvRecord>>;
}

export type OsvClientOptions = {
  baseUrl?: string;
  concurrency?: number;
  retries?: number;
  backoffMs?: number;
  timeoutMs?: number;
  fetchImpl?: typeof fetch;
  cacheDir?: string;
};

const BATCH = 500;

const cvss3Of = (list: any[] | undefined): string | undefined => list?.find(s => s?.type === 'CVSS_V3' && typeof s.score === 'string')?.score;

/** A batch result or query page must be an object whose `vulns` is absent or an array of objects with a string id. */
function validPage(x: any): boolean {
  if (x === null || typeof x !== 'object' || Array.isArray(x)) return false;
  if (x.vulns === undefined) return true;
  return Array.isArray(x.vulns) && x.vulns.every((v: any) => v !== null && typeof v === 'object' && typeof v.id === 'string');
}

export function toOsvRecord(json: any): OsvRecord {
  const affectedV3 = (json.affected ?? []).map((a: any) => cvss3Of(a?.severity)).find(Boolean);
  return {
    id: json.id,
    aliases: Array.isArray(json.aliases) ? json.aliases : [],
    cvssV3: cvss3Of(json.severity) ?? affectedV3,
    githubSeverity: json.database_specific?.severity,
  };
}

export class OsvClient implements VulnSource {
  private readonly ids = new Map<string, string[]>();
  private readonly recs = new Map<string, OsvRecord>();
  private readonly base: string;

  constructor(private readonly opts: OsvClientOptions = {}) {
    this.base = opts.baseUrl ?? 'https://api.osv.dev/v1';
  }

  private call(url: string, init: RequestInit, target: string) {
    return fetchJsonWithRetry(url, init, {
      retries: this.opts.retries ?? 3,
      backoffMs: this.opts.backoffMs ?? 1000,
      timeoutMs: this.opts.timeoutMs ?? 60000,
      fetchImpl: this.opts.fetchImpl,
      source: 'osv',
      target,
    });
  }

  private post(endpoint: string, body: unknown, target: string) {
    return this.call(`${this.base}/${endpoint}`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) }, target);
  }

  async vulnIds(gavs: Gav[]): Promise<Map<string, string[]>> {
    const missing = [...new Map(gavs.map(g => [gavKey(g), g])).values()].filter(g => !this.ids.has(gavKey(g)));
    for (let i = 0; i < missing.length; i += BATCH) {
      const chunk = missing.slice(i, i + BATCH);
      const queries = chunk.map(g => ({ package: { ecosystem: 'Maven', name: `${g.group}:${g.name}` }, version: g.version }));
      const target = `querybatch of ${chunk.length} packages`;
      const { status, body } = await this.post('querybatch', { queries }, target);
      if (status !== 200 || !Array.isArray(body?.results) || body.results.length !== chunk.length) {
        throw new LookupError('osv', target, `HTTP ${status} or malformed response`);
      }
      await mapLimit(
        chunk.map((g, idx) => ({ g, idx })),
        this.opts.concurrency ?? 8,
        async ({ g, idx }) => {
          const result = body.results[idx];
          if (!validPage(result)) throw new LookupError('osv', gavKey(g), 'malformed querybatch result');
          const found: string[] = (result.vulns ?? []).map((v: { id: string }) => v.id);
          let token: string | undefined = result.next_page_token;
          while (token) {
            const page = await this.post('query', { ...queries[idx], page_token: token }, gavKey(g));
            if (page.status !== 200) throw new LookupError('osv', gavKey(g), `HTTP ${page.status} while paging`);
            if (!validPage(page.body)) throw new LookupError('osv', gavKey(g), 'malformed response while paging');
            found.push(...(page.body.vulns ?? []).map((v: { id: string }) => v.id));
            token = page.body.next_page_token;
          }
          this.ids.set(gavKey(g), [...new Set(found)].sort());
        },
      );
    }
    return new Map(gavs.map(g => [gavKey(g), this.ids.get(gavKey(g))!]));
  }

  async records(ids: string[]): Promise<Map<string, OsvRecord>> {
    const missing = [...new Set(ids)].filter(id => !this.recs.has(id));
    await mapLimit(missing, this.opts.concurrency ?? 8, async id => {
      const { status, body } = await this.call(`${this.base}/vulns/${encodeURIComponent(id)}`, { method: 'GET' }, id);
      if (status !== 200 || body?.id == null) throw new LookupError('osv', id, `HTTP ${status}`);
      this.recs.set(id, toOsvRecord(body));
    });
    return new Map([...new Set(ids)].map(id => [id, this.recs.get(id)!]));
  }

  /** Persists what this run looked up, so reports can be audited offline. */
  flush(): void {
    if (!this.opts.cacheDir) return;
    fs.mkdirSync(this.opts.cacheDir, { recursive: true });
    fs.writeFileSync(path.join(this.opts.cacheDir, 'ids.json'), JSON.stringify(Object.fromEntries(this.ids), null, 1));
    fs.writeFileSync(path.join(this.opts.cacheDir, 'records.json'), JSON.stringify(Object.fromEntries(this.recs), null, 1));
  }
}
