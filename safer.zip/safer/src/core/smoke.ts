import { spawn } from 'child_process';
import fs from 'fs';

import { SmokeTestConfigType } from '../types/config';
import { StepResult } from './model';

export type SmokeEnv = { projectPath: string; artifact: string | null; attemptDir: string };

/** Runs the user's smoke command in its own process group; a timeout kills the whole group. */
export function runSmoke(cfg: SmokeTestConfigType, env: SmokeEnv, logFile: string): Promise<StepResult> {
  return new Promise(resolve => {
    const started = Date.now();
    const fd = fs.openSync(logFile, 'w');
    const child = spawn('bash', ['-c', cfg.command], {
      cwd: env.projectPath, // documented: the smoke command runs from the project directory
      detached: true,
      stdio: ['ignore', fd, fd],
      env: { ...process.env, SAFER_PROJECT_PATH: env.projectPath, SAFER_ARTIFACT: env.artifact ?? '', SAFER_ATTEMPT_DIR: env.attemptDir },
    });
    let timedOut = false;
    let done = false;
    const killGroup = () => {
      try {
        process.kill(-child.pid!, 'SIGKILL');
      } catch {
        // already gone
      }
    };
    const timer = setTimeout(() => {
      timedOut = true;
      killGroup();
    }, cfg.timeoutSec * 1000);
    const finish = (code: number | null) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      killGroup(); // leftover background children must not outlive the smoke step
      fs.closeSync(fd);
      const durationMs = Date.now() - started;
      if (timedOut) return resolve({ ok: false, firstError: `timeout after ${cfg.timeoutSec}s`, logFile, durationMs });
      if (code === 0) return resolve({ ok: true, logFile, durationMs });
      const lastLine = fs.readFileSync(logFile, 'utf8').trim().split('\n').filter(Boolean).pop() ?? '';
      resolve({ ok: false, firstError: `exit ${code}${lastLine ? `: ${lastLine.slice(0, 300)}` : ''}`, logFile, durationMs });
    };
    child.on('exit', finish);
    child.on('error', () => finish(-1));
  });
}
