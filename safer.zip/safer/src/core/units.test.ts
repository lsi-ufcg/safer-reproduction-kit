import { describe, expect, it } from 'vitest';

import { DirectDep, Gav } from './model';
import { buildUnits, isEligible, singleUnit, unitId, unitLabel } from './units';

const dep = (group: string, name: string, version: string, extra: Partial<DirectDep> = {}): DirectDep => ({ group, name, version, explicitVersion: true, scope: 'compile', ...extra });
const gav = (group: string, name: string, version: string): Gav => ({ group, name, version });

const swagger2 = dep('io.springfox', 'springfox-swagger2', '2.9.2');
const swaggerUi = dep('io.springfox', 'springfox-swagger-ui', '2.9.2');
const minio = dep('io.minio', 'minio', '8.5.2');
const baseline = [gav('io.springfox', 'springfox-swagger2', '2.9.2'), gav('io.springfox', 'springfox-swagger-ui', '2.9.2'), gav('io.springfox', 'springfox-core', '2.9.2'), gav('io.minio', 'minio', '8.5.2')];

describe('isEligible', () => {
  it('needs an explicit version and a shipped scope', () => {
    expect(isEligible(minio)).toBe(true);
    expect(isEligible({ ...minio, explicitVersion: false })).toBe(false);
    expect(isEligible({ ...minio, scope: 'test' })).toBe(false);
    expect(isEligible({ ...minio, scope: 'provided' })).toBe(false);
    expect(isEligible({ ...minio, scope: 'runtime' })).toBe(true);
  });
});

describe('buildUnits', () => {
  it('groups direct deps of a family aligned at baseline, in build-file order', () => {
    const units = buildUnits([minio, swagger2, swaggerUi], baseline);
    expect(units.map(u => u.label)).toEqual(['io.minio:minio', 'io.springfox [springfox-swagger-ui, springfox-swagger2]']);
    expect(units[1]).toMatchObject({ reason: 'family', members: [swaggerUi, swagger2] });
    expect(units[0]).toMatchObject({ reason: 'single', id: 'io.minio_minio', members: [minio] });
  });
  it('does not group a family that is not aligned at baseline', () => {
    const split = [gav('io.springfox', 'springfox-swagger2', '2.9.2'), gav('io.springfox', 'springfox-swagger-ui', '2.10.0')];
    const units = buildUnits([swagger2, { ...swaggerUi, version: '2.10.0' }], split);
    expect(units.map(u => u.reason)).toEqual(['single', 'single']);
  });
  it('groups deps sharing a version property even across families', () => {
    const a = dep('com.example.one', 'a', '1.0', { versionProperty: 'lib.version' });
    const b = dep('org.other.two', 'b', '1.0', { versionProperty: 'lib.version' });
    const units = buildUnits([a, b], [gav('com.example.one', 'a', '1.0'), gav('org.other.two', 'b', '1.0')]);
    expect(units).toHaveLength(1);
    expect(units[0]).toMatchObject({ reason: 'property', label: '[com.example.one:a, org.other.two:b]' });
  });
  it('merges both signals into one unit', () => {
    const core = dep('com.fasterxml.jackson.core', 'jackson-core', '2.14.2', { versionProperty: 'jackson.version' });
    const databind = dep('com.fasterxml.jackson.core', 'jackson-databind', '2.14.2', { versionProperty: 'jackson.version' });
    const xml = dep('com.fasterxml.jackson.dataformat', 'jackson-dataformat-xml', '2.14.2');
    const tree = [core, databind, xml].map(d => gav(d.group, d.name, d.version));
    const units = buildUnits([core, databind, xml], tree);
    expect(units).toHaveLength(1);
    expect(units[0].reason).toBe('property+family');
    expect(units[0].members.map(m => m.name)).toEqual(['jackson-core', 'jackson-databind', 'jackson-dataformat-xml']);
  });
  it('leaves ineligible deps out of every unit', () => {
    const units = buildUnits([swagger2, { ...swaggerUi, scope: 'test' }, { ...minio, explicitVersion: false }], baseline);
    expect(units).toHaveLength(1);
    expect(units[0]).toMatchObject({ reason: 'single', members: [swagger2] });
  });
});

describe('unitId / unitLabel / singleUnit', () => {
  it('keeps today\'s single-dep id and label', () => {
    expect(singleUnit(minio)).toEqual({ id: 'io.minio_minio', label: 'io.minio:minio', members: [minio], reason: 'single' });
  });
  it('builds filesystem-safe group ids and truncates long ones with a hash', () => {
    expect(unitId([swaggerUi, swagger2])).toBe('group-io.springfox_springfox-swagger-ui+io.springfox_springfox-swagger2');
    const many = Array.from({ length: 10 }, (_, i) => dep('org.example.family', `artifact-number-${i}`, '1.0'));
    const id = unitId(many);
    expect(id).toMatch(/^group-.{114}-[0-9a-f]{8}$/);
    expect(id).not.toBe(unitId(many.slice(1)));
  });
  it('labels a group with mixed groupIds by full keys', () => {
    expect(unitLabel([dep('a.b', 'x', '1'), dep('c.d', 'y', '1')])).toBe('[a.b:x, c.d:y]');
  });
});
