import type { VersionPlan } from './candidates';
import type { DirectDep, Gav, Override, StepResult } from './model';
import type { UpdateUnit } from './units';

export type Via = 'literal' | 'property' | 'property-inlined' | 'catalog';

export interface BuildTool {
  name: 'maven' | 'gradle';
  /** Project name (used for run directory naming). */
  projectName(): string;
  /** True when the project has its own unit tests. */
  hasTests(): boolean;
  /** Prepares the build environment (starts the container, snapshots the build file). */
  init(): Promise<void>;
  /** Lists the project's direct dependencies in build-file order (with versionProperty when the version comes from one). */
  listDirectDeps(): Promise<DirectDep[]>;
  /** Resolves the runtime dependency tree, optionally with direct dependencies overridden (build files untouched). */
  resolveTree(overrides?: Override[]): Promise<Gav[]>;
  /**
   * Optional bulk form of resolveTree for many plans of one unit, keyed by plan.version (a failure as an Error).
   * Tools whose single resolution is expensive (Gradle) implement it.
   */
  resolveTrees?(unit: UpdateUnit, plans: VersionPlan[]): Promise<Map<string, Gav[] | Error>>;
  /** Edits the build files to use the given versions; one result per override, in order. */
  apply(overrides: Override[]): Promise<{ via: Via; property?: string }[]>;
  /** Restores the build files to the last accepted state (undoes apply). */
  restore(): Promise<void>;
  /** Marks the current build files as the new accepted state. */
  accept(): Promise<void>;
  /** Builds the project (optionally running its tests); output goes to logFile. */
  build(opts: { tests: boolean; logFile: string }): Promise<StepResult>;
  /** Runtime classpath as seen from inside the build container. */
  classpath(): Promise<string>;
  /** Compiled main classes, relative to the project root (e.g. `target/classes`, `build/classes/java/main`). */
  classesDir(): string;
  /** Path of the packaged jar/war, or null when none was produced. */
  packagedArtifact(): Promise<string | null>;
  /** Restores the accepted build file and releases resources (container, temp files). */
  dispose(): Promise<void>;
  /** Optional tool versions for run.json (e.g. java, maven). */
  info?(): Record<string, string>;
}
