import { describe, expect, it } from 'vitest';

import { infraFailure, notFoundArtifacts, transferError } from './infra';

const MAVEN_PLUGIN_404 = [
  '[INFO] Downloading from nexus-safer: http://localhost:8081/repository/maven-public/org/apache/maven/plugins/maven-compiler-plugin/3.3/maven-compiler-plugin-3.3.pom',
  '[WARNING] The POM for org.apache.maven.plugins:maven-compiler-plugin:jar:3.3 is missing, no dependency information available',
  '[ERROR] Plugin org.apache.maven.plugins:maven-compiler-plugin:3.3 or one of its dependencies could not be resolved:',
  '[ERROR] \tCould not find artifact org.apache.maven.plugins:maven-compiler-plugin:jar:3.3 in nexus-safer (http://localhost:8081/repository/maven-public/)',
].join('\n');

describe('notFoundArtifacts', () => {
  it('reads Maven, cached-failure and Gradle coordinates (version is the last segment)', () => {
    const log = [
      MAVEN_PLUGIN_404,
      '[ERROR] Failed to execute goal on project x: Could not resolve dependencies: Failure to find io.minio:minio:jar:all:8.5.10 in http://localhost:8081/repository/maven-public/ was cached in the local repository',
      '   > Could not find com.google.guava:guava:20.0.',
      '     Required by:',
    ].join('\n');
    expect(notFoundArtifacts(log)).toEqual([
      { group: 'org.apache.maven.plugins', name: 'maven-compiler-plugin', version: '3.3' },
      { group: 'io.minio', name: 'minio', version: '8.5.10' },
      { group: 'com.google.guava', name: 'guava', version: '20.0' },
    ]);
  });
  it('is empty for compile errors and test failures', () => {
    expect(notFoundArtifacts('[ERROR] /app/src/main/java/A.java:[3,8] cannot find symbol\n[ERROR] Tests run: 3, Failures: 1')).toEqual([]);
  });
});

describe('transferError', () => {
  it('finds Maven and Gradle repository transfer failures', () => {
    expect(transferError('[ERROR] Failed to execute goal: Could not transfer artifact g:a:pom:1.0 from/to nexus-safer (http://localhost:8081/x): Connection refused')).toMatch(
      /^Could not transfer artifact g:a:pom:1.0 from\/to nexus-safer/,
    );
    expect(transferError("   > Could not GET 'https://repo.maven.apache.org/maven2/g/a/1.0/a-1.0.pom'. Received status code 503")).toMatch(/^Could not GET/);
  });
  it('ignores a test that happens to print a connection error', () => {
    expect(transferError('java.net.ConnectException: Connection refused\n[ERROR] Tests run: 1, Failures: 0, Errors: 1')).toBeUndefined();
  });
});

describe('infraFailure', () => {
  it('blames the repository when Maven Central has the missing artifact', async () => {
    const msg = await infraFailure(MAVEN_PLUGIN_404, async () => true);
    expect(msg).toMatch(/did not serve org.apache.maven.plugins:maven-compiler-plugin:3.3, which Maven Central has/);
  });
  it('is not infrastructure when Central does not have it either (a genuinely missing artifact)', async () => {
    expect(await infraFailure(MAVEN_PLUGIN_404, async () => false)).toBeUndefined();
  });
  it('is infrastructure when Central cannot be reached to check', async () => {
    const msg = await infraFailure(MAVEN_PLUGIN_404, async () => {
      throw new Error('fetch failed');
    });
    expect(msg).toMatch(/Maven Central could not be reached.*fetch failed/);
  });
  it('reports transfer errors without asking Central', async () => {
    let asked = false;
    const msg = await infraFailure('Could not transfer metadata g:a/maven-metadata.xml from/to central (https://x): Unknown host x', async () => (asked = true));
    expect(msg).toMatch(/^repository transfer failed/);
    expect(asked).toBe(false);
  });
  it('blames the local repository when Maven 3.9 refuses an artifact it has but got from another repository', async () => {
    const log =
      '[ERROR] Failed to execute goal on project app: Could not resolve dependencies for project g:app:jar:1.0: Failed to collect dependencies at ' +
      'org.apache.cxf:cxf-core:jar:3.4.4: Failed to read artifact descriptor for org.apache.geronimo.specs:geronimo-jta_1.1_spec:jar:1.1.1: ' +
      'The following artifacts could not be resolved: org.apache:apache:pom:3 (present, but unavailable): Cannot access geosolutions ' +
      '(https://maven.geo-solutions.it) in offline mode and the artifact org.apache:apache:pom:3 has not been downloaded from it before.';
    let asked = false;
    const msg = await infraFailure(log, async () => (asked = true));
    expect(msg).toMatch(/^local repository has org\.apache:apache:pom:3 but Maven would not use it/);
    expect(asked).toBe(false);
  });
  it('is undefined for an ordinary compile error', async () => {
    expect(await infraFailure('[ERROR] COMPILATION ERROR\n[ERROR] /app/A.java:[1,1] cannot find symbol', async () => true)).toBeUndefined();
  });
});
