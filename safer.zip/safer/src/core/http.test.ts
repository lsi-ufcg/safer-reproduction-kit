import { describe, expect, it } from 'vitest';

import { fetchJsonWithRetry } from './http';
import { LookupError } from './errors';

const response = (status: number, body: unknown) =>
  new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json' } });

const opts = (fetchImpl: typeof fetch) => ({ retries: 3, backoffMs: 1, timeoutMs: 1000, fetchImpl, source: 'osv' as const, target: 'x' });

describe('fetchJsonWithRetry', () => {
  it('retries 429/5xx then succeeds', async () => {
    const seq = [response(429, {}), response(503, {}), response(200, { ok: 1 })];
    let calls = 0;
    const r = await fetchJsonWithRetry('http://t', {}, opts((async () => seq[calls++]) as unknown as typeof fetch));
    expect(r).toEqual({ status: 200, body: { ok: 1 } });
    expect(calls).toBe(3);
  });
  it('returns 404 without retrying', async () => {
    let calls = 0;
    const r = await fetchJsonWithRetry('http://t', {}, opts((async () => { calls++; return response(404, {}); }) as unknown as typeof fetch));
    expect(r.status).toBe(404);
    expect(calls).toBe(1);
  });
  it('throws LookupError after exhausting retries on network errors', async () => {
    const f = (async () => { throw new TypeError('fetch failed'); }) as unknown as typeof fetch;
    await expect(fetchJsonWithRetry('http://t', {}, opts(f))).rejects.toBeInstanceOf(LookupError);
  });
});
