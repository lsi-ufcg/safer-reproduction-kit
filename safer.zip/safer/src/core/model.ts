export type Gav = { group: string; name: string; version: string };
/** versionProperty: the build-file property / catalog ref (`catalog:<key>`) the version comes from, when it is one. */
export type DirectDep = Gav & { explicitVersion: boolean; scope: string; versionProperty?: string };
/** One direct dependency moved to one version (a candidate edit or resolution). */
export type Override = { dep: DirectDep; version: string };
export type Severity = 'low' | 'medium' | 'high' | 'critical' | 'unknown';
export type StepResult = { ok: boolean; firstError?: string; logFile: string; durationMs: number };

export const gavKey = (g: Gav): string => `${g.group}:${g.name}:${g.version}`;
export const depKey = (g: { group: string; name: string }): string => `${g.group}:${g.name}`;
