import { describe, expect, it } from 'vitest';

import { compareVersions, familyKey, flavor, isDateStyle, isPrerelease, majorMinor } from './versions';

describe('compareVersions', () => {
  it.each([
    ['2.0', '2.0.0', 0],
    ['2.0.0', '2.0.1', -1],
    ['2.10.0', '2.9.9', 1],
    ['2.7.0-RC1', '2.7.0', -1],
    ['2.7.0-RC1', '2.6.9', 1],
    ['2.7.0-RC1', '2.7.0-RC2', -1],
    ['1.0.0-alpha', '1.0.0-beta', -1],
    ['1.0.0-beta-2', '1.0.0-M1', -1],
    ['1.0.0-M3', '1.0.0-RC1', -1],
    ['1.0.0-SNAPSHOT', '1.0.0', -1],
    ['6.4.4.Final', '6.4.4', 0],
    ['1.0.0', '1.0.0-sp1', -1],
    ['32.1.3-jre', '32.1.2-jre', 1],
    ['8.5.10', '8.5.9', 1],
  ])('%s vs %s = %i', (a, b, expected) => {
    expect(compareVersions(a, b)).toBe(expected);
    expect(compareVersions(b, a)).toBe(expected === 0 ? 0 : -expected);
  });
  it('sorts a list without NaN surprises', () => {
    const list = ['2.7.0', '2.7.0-RC1', '2.0.0-M1', '2.6.0', '2.0.0'];
    expect([...list].sort(compareVersions)).toEqual(['2.0.0-M1', '2.0.0', '2.6.0', '2.7.0-RC1', '2.7.0']);
  });
});

describe('isPrerelease', () => {
  it.each(['2.7.0-RC1', '1.0-rc', '3.0.0-M2', '1.0-beta', '1.0.0-alpha.11', '5.0-SNAPSHOT', '2.0.0.CR1', '21-ea', '1.0-preview', '7.0.0-milestone-1'])(
    '%s is a pre-release',
    v => expect(isPrerelease(v)).toBe(true),
  );
  it.each(['2.7.0', '6.4.4.Final', '32.1.3-jre', '1.0.0-sp1', '2.0.RELEASE'])('%s is not', v => expect(isPrerelease(v)).toBe(false));
});

describe('misc', () => {
  it('flavor', () => {
    expect(flavor('32.1.3-jre')).toBe('jre');
    expect(flavor('32.1.3-android')).toBe('android');
    expect(flavor('2.7.0')).toBe('');
    expect(flavor('2.7.0-RC1')).toBe('');
  });
  it('isDateStyle', () => {
    expect(isDateStyle('20020520')).toBe(true);
    expect(isDateStyle('2.0.1')).toBe(false);
  });
  it('majorMinor', () => {
    expect(majorMinor('2.14.2')).toBe('2.14');
    expect(majorMinor('6')).toBe('6.0');
  });
  it('familyKey', () => {
    expect(familyKey('com.fasterxml.jackson.core')).toBe('com.fasterxml.jackson');
    expect(familyKey('com.fasterxml.jackson.dataformat')).toBe('com.fasterxml.jackson');
    expect(familyKey('org.springframework')).toBe('org.springframework');
  });
});
