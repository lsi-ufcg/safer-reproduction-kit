import { describe, expect, it } from 'vitest';

import { saferRevision } from './run-info';

describe('saferRevision', () => {
  it('returns the short revision and the dirty flag', () => {
    const calls: string[][] = [];
    const git = (args: string[]) => {
      calls.push(args);
      return args.includes('rev-parse') ? 'abc1234\n' : ' M src/core/x.ts\n';
    };
    expect(saferRevision('/safer', git)).toEqual({ revision: 'abc1234', dirty: true });
    expect(calls[0]).toEqual(['-C', '/safer', 'rev-parse', '--short', 'HEAD']);
    expect(saferRevision('/safer', a => (a.includes('rev-parse') ? 'abc1234\n' : ''))).toEqual({ revision: 'abc1234', dirty: false });
  });
  it('falls back to unknown when git is missing', () => {
    expect(saferRevision('/safer', () => { throw new Error('spawn git ENOENT'); })).toEqual({ revision: 'unknown', dirty: false });
  });
  it('works against a directory that is not a repository', () => {
    expect(saferRevision('/')).toMatchObject({ revision: expect.any(String) });
  });
});
