import fs from 'fs';
import os from 'os';
import path from 'path';

import { describe, expect, it } from 'vitest';

import { runSmoke } from './smoke';

const dir = () => fs.mkdtempSync(path.join(os.tmpdir(), 'safer-smoke-'));

describe('runSmoke', () => {
  it('passes env and succeeds on exit 0', async () => {
    const d = dir();
    const r = await runSmoke({ enabled: true, command: 'echo "$SAFER_ARTIFACT|$SAFER_PROJECT_PATH|$SAFER_ATTEMPT_DIR"', timeoutSec: 10 }, { projectPath: d, artifact: '/p/a.jar', attemptDir: d }, path.join(d, 'smoke.log'));
    expect(r.ok).toBe(true);
    expect(fs.readFileSync(path.join(d, 'smoke.log'), 'utf8')).toContain(`/p/a.jar|${d}|${d}`);
  });
  it('fails with the last output line on non-zero exit', async () => {
    const d = dir();
    const r = await runSmoke({ enabled: true, command: 'echo started; echo "APPLICATION FAILED TO START"; exit 3', timeoutSec: 10 }, { projectPath: d, artifact: null, attemptDir: d }, path.join(d, 'smoke.log'));
    expect(r).toMatchObject({ ok: false, firstError: 'exit 3: APPLICATION FAILED TO START' });
  });
  it('runs from the project directory', async () => {
    const d = dir();
    const project = fs.mkdtempSync(path.join(os.tmpdir(), 'safer-smoke-project-'));
    fs.writeFileSync(path.join(project, 'marker.txt'), 'here');
    const r = await runSmoke({ enabled: true, command: 'pwd; cat marker.txt', timeoutSec: 10 }, { projectPath: project, artifact: null, attemptDir: d }, path.join(d, 'smoke.log'));
    expect(r.ok).toBe(true);
    expect(fs.readFileSync(path.join(d, 'smoke.log'), 'utf8')).toBe(`${fs.realpathSync(project)}\nhere`);
  });
  it('kills the whole process group on timeout', async () => {
    const d = dir();
    const marker = path.join(d, 'child-alive');
    const started = Date.now();
    const r = await runSmoke({ enabled: true, command: `(sleep 3; touch ${marker}) & sleep 30`, timeoutSec: 1 }, { projectPath: d, artifact: null, attemptDir: d }, path.join(d, 'smoke.log'));
    expect(r).toMatchObject({ ok: false, firstError: 'timeout after 1s' });
    expect(Date.now() - started).toBeLessThan(5000);
    await new Promise(res => setTimeout(res, 3500));
    expect(fs.existsSync(marker)).toBe(false);
  });
});
