import fs from 'fs';
import path from 'path';

import type { UnitReason } from './units';

export type EventType = 'baseline' | 'candidates' | 'scored' | 'excluded' | 'rejected' | 'adopted' | 'kept' | 'skipped' | 'run-summary' | 'run-failed';
export type Step = 'init' | 'lookup' | 'resolve' | 'apply' | 'build' | 'alignment' | 'randoop' | 'smoke' | 'report';
export type DecisionEvent = {
  type: EventType;
  ts: string;
  dep?: string;
  version?: string;
  from?: string;
  reason?: string;
  step?: Step;
  firstError?: string;
  logFile?: string;
  durationMs?: number;
  rate?: number;
  currentRate?: number;
  added?: string[];
  removed?: string[];
  data?: Record<string, unknown>;
  /** Grouped units only: each member's current version, and its version in this plan. */
  members?: { dep: string; from: string; to?: string }[];
  /** Grouped units only: why the members move together. */
  groupReason?: Exclude<UnitReason, 'single'>;
};
export type SummaryRow = { dep: string; from: string; to: string; outcome: 'adopted' | 'kept' | 'skipped'; note: string; members?: { dep: string; from: string; to?: string }[] };

const pad2 = (n: number) => String(n).padStart(2, '0');
const clock = (iso: string) => {
  const d = new Date(iso);
  return `${pad2(d.getHours())}:${pad2(d.getMinutes())}:${pad2(d.getSeconds())}`;
};
const rate = (n?: number) => (n ?? 0).toFixed(1);
export const duration = (ms = 0) => {
  const s = Math.round(ms / 1000);
  return s >= 60 ? `${Math.floor(s / 60)}m${pad2(s % 60)}s` : `${s}s`;
};
const label = (word: string) => word.padEnd(9);
/** ` (name version, …)` for group members whose plan version differs from the target; '' otherwise. */
const lagging = (e: DecisionEvent) => {
  const off = (e.members ?? []).filter(m => m.to !== undefined && m.to !== e.version).map(m => `${m.dep.split(':')[1]} ${m.to}`);
  return off.length ? ` (${off.join(', ')})` : '';
};

export function formatConsoleLine(e: DecisionEvent): string | null {
  const t = clock(e.ts);
  switch (e.type) {
    case 'baseline': {
      const d = e.data ?? {};
      if (d.ok === false && e.step === 'randoop') return `${t} ${label('BASELINE')} Randoop unusable, continuing without it · ${e.firstError ?? e.reason}${e.logFile ? ` (log: ${e.logFile})` : ''}`;
      if (d.ok === false) return `${t} ${label('BASELINE')} FAILED · ${e.step}: ${e.firstError ?? e.reason} (log: ${e.logFile})`;
      const sev = (d.bySeverity ?? {}) as Record<string, number>;
      return `${t} ${label('BASELINE')} ${d.build ?? 'build skipped'} · ${d.distinct} vulns (C${sev.critical ?? 0} H${sev.high ?? 0} M${sev.medium ?? 0} L${sev.low ?? 0} U${sev.unknown ?? 0}) · rate ${rate(e.rate)}`;
    }
    case 'skipped':
      return `${t} ${label('SKIP')} ${e.dep} ${e.version} · ${e.reason}`;
    case 'excluded':
      return `${t} ${label('EXCLUDE')} ${e.dep} ${e.version}${lagging(e)} · ${e.step}: ${e.reason}${e.logFile ? ` (log: ${e.logFile})` : ''}`;
    case 'rejected':
      return `${t} ${label('REJECT')} ${e.dep} ${e.version}${lagging(e)} · ${e.step}: ${e.firstError ?? e.reason}${e.logFile ? ` (log: ${e.logFile})` : ''}`;
    case 'adopted':
      return `${t} ${label('ADOPT')} ${e.dep} ${e.from} → ${e.version}${lagging(e)} · rate ${rate(e.currentRate)} → ${rate(e.rate)} · fixed ${e.removed?.length ?? 0}, introduced ${e.added?.length ?? 0}`;
    case 'kept':
      return `${t} ${label('KEEP')} ${e.dep} ${e.version} · ${e.reason}`;
    case 'run-failed':
      return `${t} RUN FAILED · ${e.step}: ${e.reason}`;
    default:
      return null;
  }
}

const stamp = (d: Date) => `${d.getFullYear()}${pad2(d.getMonth() + 1)}${pad2(d.getDate())}-${pad2(d.getHours())}${pad2(d.getMinutes())}${pad2(d.getSeconds())}`;

export class EventLog {
  private readonly list: DecisionEvent[] = [];

  private constructor(
    readonly runDir: string,
    private readonly out: (line: string) => void,
  ) {}

  static create(baseDir: string, project: string, opts: { now?: Date; console?: (line: string) => void } = {}): EventLog {
    const runDir = path.join(baseDir, `${stamp(opts.now ?? new Date())}-${project}`);
    fs.mkdirSync(path.join(runDir, 'attempts'), { recursive: true });
    return new EventLog(runDir, opts.console ?? (line => console.log(line)));
  }

  /** Prints a free-form line on the console (never raw build output). */
  warn(line: string): void {
    this.out(line);
  }

  /** Writes a resolved tree to trees/<name>.txt, one sorted g:a:v per line. */
  writeTree(name: string, tree: { group: string; name: string; version: string }[]): void {
    fs.mkdirSync(path.join(this.runDir, 'trees'), { recursive: true });
    const lines = [...new Set(tree.map(g => `${g.group}:${g.name}:${g.version}`))].sort();
    fs.writeFileSync(path.join(this.runDir, 'trees', `${name}.txt`), lines.length ? `${lines.join('\n')}\n` : '');
  }

  /** attempts/<group_artifact>/<version>/, created on demand. */
  attemptDir(dep: string, version: string): string {
    const dir = path.join(this.runDir, 'attempts', dep.replace(/:/g, '_'), version);
    fs.mkdirSync(dir, { recursive: true });
    return dir;
  }

  /** Paths in events are relative to the run dir so the directory can be moved. */
  rel(p: string): string {
    return path.relative(this.runDir, p);
  }

  emit(e: Omit<DecisionEvent, 'ts'>): DecisionEvent {
    const event = { ts: new Date().toISOString(), ...e } as DecisionEvent;
    this.list.push(event);
    fs.appendFileSync(path.join(this.runDir, 'decisions.jsonl'), `${JSON.stringify(event)}\n`);
    const line = formatConsoleLine(event);
    if (line) this.out(line);
    return event;
  }

  events(): DecisionEvent[] {
    return [...this.list];
  }

  writeRunJson(data: Record<string, unknown>): void {
    fs.writeFileSync(path.join(this.runDir, 'run.json'), JSON.stringify(data, null, 2));
  }

  printSummary(rows: SummaryRow[]): void {
    const count = (o: SummaryRow['outcome']) => rows.filter(r => r.outcome === o).length;
    this.out(`\nSummary (${count('adopted')} adopted, ${count('kept')} kept, ${count('skipped')} skipped) — run dir: ${this.runDir}`);
    const w = Math.min(60, Math.max(...rows.map(r => r.dep.length), 10));
    const word = { adopted: 'ADOPT', kept: 'KEEP', skipped: 'SKIP' } as const;
    for (const r of rows) {
      const dep = r.dep.length > w ? `${r.dep.slice(0, w - 1)}…` : r.dep.padEnd(w);
      const change = r.outcome === 'adopted' ? `${r.from.padEnd(10)} → ${r.to.padEnd(10)}` : `${r.from.padEnd(10)}   ${''.padEnd(10)}`;
      this.out(`  ${word[r.outcome].padEnd(6)} ${dep}  ${change}  ${r.note}`);
    }
  }
}
