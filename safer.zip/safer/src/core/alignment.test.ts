import { describe, expect, it } from 'vitest';

import { alignedFamilies, checkAlignment, describeMisalignment } from './alignment';

const j = (name: string, version: string, group = 'com.fasterxml.jackson.core') => ({ group, name, version });
const baseline = [j('jackson-core', '2.14.2'), j('jackson-databind', '2.14.2'), j('jackson-dataformat-xml', '2.14.2', 'com.fasterxml.jackson.dataformat'),
  { group: 'io.micrometer', name: 'micrometer-core', version: '1.10.5' }, { group: 'io.micrometer', name: 'micrometer-tracing', version: '1.0.3' },
  { group: 'io.minio', name: 'minio', version: '8.5.2' }];

describe('alignment', () => {
  it('ignores single-artifact and already-misaligned families', () => {
    expect([...alignedFamilies(baseline)]).toEqual(['com.fasterxml.jackson']);
  });
  it('flags a family that becomes split', () => {
    const candidate = baseline.map(g => (g.name === 'jackson-dataformat-xml' ? { ...g, version: '2.18.2' } : g));
    const m = checkAlignment(baseline, candidate);
    expect(m).toEqual([{
      family: 'com.fasterxml.jackson',
      versions: { '2.14': ['com.fasterxml.jackson.core:jackson-core', 'com.fasterxml.jackson.core:jackson-databind'], '2.18': ['com.fasterxml.jackson.dataformat:jackson-dataformat-xml'] },
      artifacts: { 'com.fasterxml.jackson.core:jackson-core': '2.14.2', 'com.fasterxml.jackson.core:jackson-databind': '2.14.2', 'com.fasterxml.jackson.dataformat:jackson-dataformat-xml': '2.18.2' },
    }]);
    expect(describeMisalignment(m[0])).toBe('com.fasterxml.jackson split 2.14 [jackson-core, jackson-databind] vs 2.18 [jackson-dataformat-xml]');
  });
  it('accepts a family that moves together and changes outside aligned families', () => {
    const together = baseline.map(g => (g.group.startsWith('com.fasterxml') ? { ...g, version: '2.15.0' } : g));
    expect(checkAlignment(baseline, together)).toEqual([]);
    const other = baseline.map(g => (g.name === 'micrometer-tracing' ? { ...g, version: '1.1.0' } : g));
    expect(checkAlignment(baseline, other)).toEqual([]);
  });
  it('names a duplicate provider when artifacts differ only by a -jdkNNon suffix', () => {
    const bc = (name: string, version: string) => ({ group: 'org.bouncycastle', name, version });
    const base = [bc('bcprov-jdk15on', '1.69'), bc('bcpkix-jdk15on', '1.69')];
    const cand = [...base, bc('bcprov-jdk18on', '1.78')];
    const [m] = checkAlignment(base, cand);
    expect(describeMisalignment(m)).toBe(
      'duplicate provider: bcprov-jdk15on 1.69 and bcprov-jdk18on 1.78 both on the runtime classpath; org.bouncycastle split 1.69 [bcpkix-jdk15on, bcprov-jdk15on] vs 1.78 [bcprov-jdk18on]',
    );
  });
});
