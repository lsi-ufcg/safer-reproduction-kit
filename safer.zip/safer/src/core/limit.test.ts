import { describe, expect, it } from 'vitest';

import { limiter, mapLimit } from './limit';

describe('limiter', () => {
  it('never runs more than n tasks at once and keeps order in mapLimit', async () => {
    let running = 0;
    let peak = 0;
    const out = await mapLimit([1, 2, 3, 4, 5, 6], 2, async x => {
      running++;
      peak = Math.max(peak, running);
      await new Promise(r => setTimeout(r, 5));
      running--;
      return x * 10;
    });
    expect(peak).toBe(2);
    expect(out).toEqual([10, 20, 30, 40, 50, 60]);
  });
  it('propagates rejections', async () => {
    const run = limiter(1);
    await expect(run(async () => { throw new Error('x'); })).rejects.toThrow('x');
  });
});
