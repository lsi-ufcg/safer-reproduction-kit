import { createHash } from 'crypto';

import { alignedFamilies } from './alignment';
import { DirectDep, Gav, depKey } from './model';
import { familyKey } from './versions';

/**
 * Direct dependencies that are upgraded together: they share a version property / catalog ref, or belong to a
 * library family whose artifacts all shared one major.minor at baseline (moving one alone would split it).
 */
export type UnitReason = 'single' | 'property' | 'family' | 'property+family';
export type UpdateUnit = { id: string; label: string; members: DirectDep[]; reason: UnitReason };

/** Only these deps are upgraded: an explicit version and a scope that ships at runtime. */
export const isEligible = (d: DirectDep): boolean => d.explicitVersion && d.scope !== 'test' && d.scope !== 'provided';

const MAX_ID = 120;
const slug = (d: DirectDep) => `${d.group}_${d.name}`;

/** Filesystem-safe id (attempts/<id>/): `group_name` for one member, `group-<slugs joined by +>` for several. */
export function unitId(members: DirectDep[]): string {
  if (members.length === 1) return slug(members[0]);
  const full = `group-${members.map(slug).join('+')}`;
  if (full.length <= MAX_ID) return full;
  return `${full.slice(0, MAX_ID)}-${createHash('sha256').update(full).digest('hex').slice(0, 8)}`;
}

/** `group:name` for one member; `group [a, b]` when all share a groupId; `[g1:a, g2:b]` otherwise. */
export function unitLabel(members: DirectDep[]): string {
  if (members.length === 1) return depKey(members[0]);
  if (new Set(members.map(m => m.group)).size === 1) return `${members[0].group} [${members.map(m => m.name).join(', ')}]`;
  return `[${members.map(depKey).join(', ')}]`;
}

export const singleUnit = (dep: DirectDep): UpdateUnit => ({ id: unitId([dep]), label: unitLabel([dep]), members: [dep], reason: 'single' });

/** Units of the eligible deps, ordered by their first member's position in `deps`; members sorted by group:name. */
export function buildUnits(deps: DirectDep[], baselineTree: Gav[]): UpdateUnit[] {
  const eligible = deps.filter(isEligible);
  const aligned = alignedFamilies(baselineTree);
  const sameProperty = (a: DirectDep, b: DirectDep) => !!a.versionProperty && a.versionProperty === b.versionProperty;
  const sameFamily = (a: DirectDep, b: DirectDep) => familyKey(a.group) === familyKey(b.group) && aligned.has(familyKey(a.group));

  const parent = eligible.map((_, i) => i);
  const find = (i: number): number => (parent[i] === i ? i : (parent[i] = find(parent[i])));
  for (let i = 0; i < eligible.length; i++)
    for (let j = i + 1; j < eligible.length; j++) if (sameProperty(eligible[i], eligible[j]) || sameFamily(eligible[i], eligible[j])) parent[find(j)] = find(i);

  const components = new Map<number, DirectDep[]>();
  eligible.forEach((d, i) => components.set(find(i), [...(components.get(find(i)) ?? []), d]));
  return [...components.values()].map(list => {
    const members = [...list].sort((a, b) => depKey(a).localeCompare(depKey(b)));
    const pairs = members.flatMap((a, i) => members.slice(i + 1).map(b => [a, b] as const));
    const byProperty = pairs.some(([a, b]) => sameProperty(a, b));
    const byFamily = pairs.some(([a, b]) => sameFamily(a, b));
    const reason: UnitReason = members.length === 1 ? 'single' : byProperty && byFamily ? 'property+family' : byProperty ? 'property' : 'family';
    return { id: unitId(members), label: unitLabel(members), members, reason };
  });
}
