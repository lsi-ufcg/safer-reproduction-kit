import { Gav } from './model';
import { familyKey, majorMinor } from './versions';

/** versions: major.minor → sorted group:artifact keys; artifacts: group:artifact → full resolved version. */
export type Misalignment = { family: string; versions: Record<string, string[]>; artifacts: Record<string, string> };

function families(tree: Gav[]): Map<string, Map<string, string[]>> {
  const out = new Map<string, Map<string, string[]>>();
  for (const g of tree) {
    const fam = familyKey(g.group);
    const byMm = out.get(fam) ?? new Map<string, string[]>();
    const mm = majorMinor(g.version);
    byMm.set(mm, [...(byMm.get(mm) ?? []), `${g.group}:${g.name}`].sort());
    out.set(fam, byMm);
  }
  return out;
}

const artifactCount = (byMm: Map<string, string[]>) => [...byMm.values()].reduce((n, l) => n + l.length, 0);

/** Families with ≥2 artifacts that all share major.minor. */
export function alignedFamilies(tree: Gav[]): Set<string> {
  return new Set([...families(tree)].filter(([, byMm]) => byMm.size === 1 && artifactCount(byMm) >= 2).map(([f]) => f));
}

export function checkAlignment(baseline: Gav[], candidate: Gav[]): Misalignment[] {
  const aligned = alignedFamilies(baseline);
  return [...families(candidate)]
    .filter(([fam, byMm]) => aligned.has(fam) && byMm.size > 1)
    .map(([family, byMm]) => ({
      family,
      versions: Object.fromEntries([...byMm].sort(([a], [b]) => a.localeCompare(b, undefined, { numeric: true }))),
      artifacts: Object.fromEntries(
        candidate
          .filter(g => familyKey(g.group) === family)
          .map(g => [`${g.group}:${g.name}`, g.version] as const)
          .sort(([a], [b]) => a.localeCompare(b)),
      ),
    }));
}

const JDK_SUFFIX = /-jdk\d+(on)?$/;

/** Pairs of artifacts that differ only by a -jdkNNon suffix (e.g. bcprov-jdk15on vs bcprov-jdk18on) at different versions. */
function duplicateProviders(m: Misalignment): string[] {
  const byBase = new Map<string, [string, string][]>();
  for (const [key, version] of Object.entries(m.artifacts ?? {})) {
    const [group, name] = key.split(':');
    if (!JDK_SUFFIX.test(name)) continue;
    const base = `${group}:${name.replace(JDK_SUFFIX, '')}`;
    byBase.set(base, [...(byBase.get(base) ?? []), [name, version]]);
  }
  const out: string[] = [];
  for (const list of byBase.values()) {
    if (list.length < 2 || new Set(list.map(([, v]) => v)).size < 2) continue;
    const named = list.map(([n, v]) => `${n} ${v}`);
    out.push(`duplicate provider: ${named.slice(0, -1).join(', ')} and ${named.at(-1)} both on the runtime classpath`);
  }
  return out;
}

export function describeMisalignment(m: Misalignment): string {
  const parts = Object.entries(m.versions).map(([mm, arts]) => `${mm} [${arts.map(a => a.split(':')[1]).join(', ')}]`);
  return [...duplicateProviders(m), `${m.family} split ${parts.join(' vs ')}`].join('; ');
}
