import fs from 'fs';
import os from 'os';
import path from 'path';

import { describe, expect, it } from 'vitest';

import { BuildTool } from './build-tool';
import { InfrastructureError, LookupError, ResolveError } from './errors';
import { EventLog, formatConsoleLine } from './event-log';
import { DirectDep, Gav } from './model';
import { TreeScore } from './scoring';
import { PlannerAborted, runPlanner } from './update-planner';

const W = { low: 1, medium: 2, high: 3, critical: 5 };
const deps: DirectDep[] = [
  { group: 'com.fasterxml.jackson.dataformat', name: 'jackson-dataformat-xml', version: '2.14.2', explicitVersion: true, scope: 'compile' },
  { group: 'io.minio', name: 'minio', version: '8.5.2', explicitVersion: true, scope: 'compile' },
  { group: 'org.springframework.boot', name: 'spring-boot-starter-web', version: '3.0.4', explicitVersion: false, scope: 'compile' },
  { group: 'org.junit', name: 'junit', version: '4.13.2', explicitVersion: true, scope: 'test' },
  { group: 'org.springdoc', name: 'springdoc', version: '2.0.2', explicitVersion: true, scope: 'compile' },
];

function fakeTool(opts: { failBuild?: (pom: Record<string, string>) => boolean } = {}) {
  const accepted: Record<string, string> = Object.fromEntries(deps.map(d => [d.name, d.version]));
  let pom = { ...accepted };
  const calls: string[] = [];
  const tree = (p: Record<string, string>): Gav[] => [
    { group: 'com.fasterxml.jackson.core', name: 'jackson-core', version: '2.14.2' },
    { group: 'com.fasterxml.jackson.dataformat', name: 'jackson-dataformat-xml', version: p['jackson-dataformat-xml'] },
    { group: 'io.minio', name: 'minio', version: p['minio'] },
    { group: 'org.springdoc', name: 'springdoc', version: p['springdoc'] },
  ];
  const tool: BuildTool = {
    name: 'maven',
    projectName: () => 'demo',
    hasTests: () => true,
    init: async () => { calls.push('init'); },
    listDirectDeps: async () => deps,
    resolveTree: async o => tree(o?.length ? { ...accepted, ...Object.fromEntries(o.map(x => [x.dep.name, x.version])) } : accepted),
    apply: async os => { pom = { ...accepted, ...Object.fromEntries(os.map(o => [o.dep.name, o.version])) }; calls.push(`apply ${os.map(o => `${o.dep.name} ${o.version}`).join(', ')}`); return os.map(() => ({ via: 'literal' as const })); },
    restore: async () => { pom = { ...accepted }; calls.push('restore'); },
    accept: async () => { Object.assign(accepted, pom); calls.push('accept'); },
    build: async ({ tests, logFile }) => { calls.push(`build tests=${tests}`); fs.mkdirSync(path.dirname(logFile), { recursive: true }); const ok = !(opts.failBuild?.(pom)); return { ok, logFile, durationMs: 1, firstError: ok ? undefined : 'cannot find symbol' }; },
    classpath: async () => '/app/target/classes',
    classesDir: () => 'target/classes',
    packagedArtifact: async () => '/p/target/app.jar',
    dispose: async () => { calls.push('dispose'); },
  };
  return { tool, calls, accepted };
}

// Vulnerability ids per artifact version; scoreTree is faked from these.
const VULNS: Record<string, string[]> = {
  'minio:8.5.2': ['M1', 'M2'], 'minio:8.5.10': ['M2'], 'minio:8.6.0': [],
  'jackson-dataformat-xml:2.14.2': ['X1'], 'jackson-dataformat-xml:2.18.2': [],
  'springdoc:2.0.2': ['S1'], 'springdoc:2.8.0': [],
};
const fakeScore = async (tree: Gav[]): Promise<TreeScore> => {
  const ids = [...new Set(tree.flatMap(g => VULNS[`${g.name}:${g.version}`] ?? []))].sort();
  const vulns = ids.map(id => ({ id, ids: [id], aliases: [], score: 7.5, severity: 'high' as const, scoreSource: 'cvss3' as const, packages: [] }));
  return { rate: ids.length * 22.5, vulns, bySeverity: { low: 0, medium: 0, high: ids.length, critical: 0, unknown: 0 } };
};
const versions: Record<string, string[]> = {
  'jackson-dataformat-xml': ['2.18.2', '2.14.2'],
  minio: ['8.6.0', '8.5.10', '8.5.2'],
  springdoc: ['2.8.0', '2.7.0-RC1', '2.0.2'],
  junit: ['4.13.2'],
};

const cfg = { weights: W, buildProject: true, projectTests: true, exploratoryTesting: false, allowPrerelease: false, alignmentCheck: true, projectPath: '/p' };
const newLog = () => EventLog.create(fs.mkdtempSync(path.join(os.tmpdir(), 'safer-plan-')), 'demo', { console: () => {} });

// The single-dependency event stream, as it was before grouping existed (ts and durationMs stripped).
const SINGLE_EVENTS = [
  {
    "type": "baseline",
    "rate": 90,
    "data": {
      "ok": true,
      "build": "build ok (tests on, 0s)",
      "distinct": 4,
      "bySeverity": {
        "low": 0,
        "medium": 0,
        "high": 4,
        "critical": 0,
        "unknown": 0
      },
      "tree": 4
    }
  },
  {
    "type": "candidates",
    "dep": "com.fasterxml.jackson.dataformat:jackson-dataformat-xml",
    "version": "2.14.2",
    "data": {
      "current": "2.14.2",
      "candidates": [
        "2.18.2"
      ],
      "currentFound": true,
      "olderCount": 0,
      "dropped": {
        "prerelease": [],
        "dateStyle": [],
        "flavor": []
      }
    }
  },
  {
    "type": "scored",
    "dep": "com.fasterxml.jackson.dataformat:jackson-dataformat-xml",
    "version": "2.18.2",
    "rate": 67.5,
    "currentRate": 90,
    "added": [],
    "removed": [
      "X1"
    ],
    "data": {
      "aligned": false,
      "misalignment": "com.fasterxml.jackson split 2.14 [jackson-core] vs 2.18 [jackson-dataformat-xml]"
    }
  },
  {
    "type": "rejected",
    "dep": "com.fasterxml.jackson.dataformat:jackson-dataformat-xml",
    "version": "2.18.2",
    "step": "alignment",
    "firstError": "com.fasterxml.jackson split 2.14 [jackson-core] vs 2.18 [jackson-dataformat-xml]"
  },
  {
    "type": "kept",
    "dep": "com.fasterxml.jackson.dataformat:jackson-dataformat-xml",
    "version": "2.14.2",
    "reason": "all 1 lower-score candidates failed validation (see REJECT lines)"
  },
  {
    "type": "candidates",
    "dep": "io.minio:minio",
    "version": "8.5.2",
    "data": {
      "current": "8.5.2",
      "candidates": [
        "8.5.10",
        "8.6.0"
      ],
      "currentFound": true,
      "olderCount": 0,
      "dropped": {
        "prerelease": [],
        "dateStyle": [],
        "flavor": []
      }
    }
  },
  {
    "type": "scored",
    "dep": "io.minio:minio",
    "version": "8.5.10",
    "rate": 67.5,
    "currentRate": 90,
    "added": [],
    "removed": [
      "M1"
    ],
    "data": {
      "aligned": true
    }
  },
  {
    "type": "scored",
    "dep": "io.minio:minio",
    "version": "8.6.0",
    "rate": 45,
    "currentRate": 90,
    "added": [],
    "removed": [
      "M1",
      "M2"
    ],
    "data": {
      "aligned": true
    }
  },
  {
    "type": "rejected",
    "dep": "io.minio:minio",
    "version": "8.6.0",
    "step": "build",
    "firstError": "cannot find symbol",
    "logFile": "attempts/io.minio_minio/8.6.0/build.log"
  },
  {
    "type": "adopted",
    "dep": "io.minio:minio",
    "from": "8.5.2",
    "version": "8.5.10",
    "rate": 67.5,
    "currentRate": 90,
    "added": [],
    "removed": [
      "M1"
    ],
    "data": {
      "via": "literal"
    }
  },
  {
    "type": "skipped",
    "dep": "org.springframework.boot:spring-boot-starter-web",
    "version": "3.0.4",
    "reason": "version managed by parent/BOM"
  },
  {
    "type": "skipped",
    "dep": "org.junit:junit",
    "version": "4.13.2",
    "reason": "scope test: not part of the shipped runtime tree"
  },
  {
    "type": "candidates",
    "dep": "org.springdoc:springdoc",
    "version": "2.0.2",
    "data": {
      "current": "2.0.2",
      "candidates": [
        "2.8.0"
      ],
      "currentFound": true,
      "olderCount": 0,
      "dropped": {
        "prerelease": [
          "2.7.0-RC1"
        ],
        "dateStyle": [],
        "flavor": []
      }
    }
  },
  {
    "type": "scored",
    "dep": "org.springdoc:springdoc",
    "version": "2.8.0",
    "rate": 45,
    "currentRate": 67.5,
    "added": [],
    "removed": [
      "S1"
    ],
    "data": {
      "aligned": true
    }
  },
  {
    "type": "rejected",
    "dep": "org.springdoc:springdoc",
    "version": "2.8.0",
    "step": "smoke",
    "firstError": "exit 1",
    "logFile": "attempts/org.springdoc_springdoc/2.8.0/smoke.log"
  },
  {
    "type": "kept",
    "dep": "org.springdoc:springdoc",
    "version": "2.0.2",
    "reason": "all 1 lower-score candidates failed validation (see REJECT lines)"
  },
  {
    "type": "run-summary",
    "data": {
      "adopted": 1,
      "kept": 2,
      "skipped": 2,
      "rejected": 3,
      "excluded": 0,
      "units": 3,
      "groupedUnits": 0,
      "before": 4,
      "after": 3,
      "beforeRate": 90,
      "expectedRate": 67.5,
      "finalRate": 67.5
    }
  }
];
const SINGLE_CONSOLE = [
  "12:34:56 BASELINE  build ok (tests on, 0s) \u00b7 4 vulns (C0 H4 M0 L0 U0) \u00b7 rate 90.0",
  null,
  null,
  "12:34:56 REJECT    com.fasterxml.jackson.dataformat:jackson-dataformat-xml 2.18.2 \u00b7 alignment: com.fasterxml.jackson split 2.14 [jackson-core] vs 2.18 [jackson-dataformat-xml]",
  "12:34:56 KEEP      com.fasterxml.jackson.dataformat:jackson-dataformat-xml 2.14.2 \u00b7 all 1 lower-score candidates failed validation (see REJECT lines)",
  null,
  null,
  null,
  "12:34:56 REJECT    io.minio:minio 8.6.0 \u00b7 build: cannot find symbol (log: attempts/io.minio_minio/8.6.0/build.log)",
  "12:34:56 ADOPT     io.minio:minio 8.5.2 \u2192 8.5.10 \u00b7 rate 90.0 \u2192 67.5 \u00b7 fixed 1, introduced 0",
  "12:34:56 SKIP      org.springframework.boot:spring-boot-starter-web 3.0.4 \u00b7 version managed by parent/BOM",
  "12:34:56 SKIP      org.junit:junit 4.13.2 \u00b7 scope test: not part of the shipped runtime tree",
  null,
  null,
  "12:34:56 REJECT    org.springdoc:springdoc 2.8.0 \u00b7 smoke: exit 1 (log: attempts/org.springdoc_springdoc/2.8.0/smoke.log)",
  "12:34:56 KEEP      org.springdoc:springdoc 2.0.2 \u00b7 all 1 lower-score candidates failed validation (see REJECT lines)",
  null
];

describe('runPlanner', () => {
  it('makes the expected decision for each dependency', async () => {
    const { tool, calls, accepted } = fakeTool({ failBuild: p => p.minio === '8.6.0' });
    const log = newLog();
    const res = await runPlanner({ ...cfg, smokeTest: { enabled: true, command: 'true', timeoutSec: 5 } }, {
      tool, log, scoreTree: fakeScore,
      versionSource: async d => versions[d.name] ?? [],
      runSmoke: async (_c, env, logFile) => ({ ok: !env.attemptDir.includes('springdoc'), logFile, durationMs: 1, firstError: 'exit 1' }),
    });
    const ev = log.events();
    const by = (type: string, name: string) => ev.filter(e => e.type === type && e.dep?.endsWith(`:${name}`));

    // jackson-dataformat-xml 2.18.2 splits the jackson family -> rejected by alignment, before any build
    expect(by('rejected', 'jackson-dataformat-xml')[0]).toMatchObject({ version: '2.18.2', step: 'alignment' });
    expect(by('kept', 'jackson-dataformat-xml')).toHaveLength(1);
    // minio: 8.6.0 (rate 0) fails the build, 8.5.10 (rate 22.5) is adopted
    expect(by('rejected', 'minio')[0]).toMatchObject({ version: '8.6.0', step: 'build', firstError: 'cannot find symbol' });
    expect(by('adopted', 'minio')[0]).toMatchObject({ from: '8.5.2', version: '8.5.10', removed: ['M1'], added: [] });
    expect(accepted.minio).toBe('8.5.10');
    // BOM-managed and test-scoped deps are skipped
    expect(by('skipped', 'spring-boot-starter-web')[0].reason).toMatch(/parent\/BOM/);
    expect(by('skipped', 'junit')[0].reason).toMatch(/scope test/);
    // springdoc: RC never considered; 2.8.0 fails the smoke test
    expect(JSON.stringify(by('candidates', 'springdoc')[0].data)).toContain('2.7.0-RC1');
    expect(by('scored', 'springdoc').map(e => e.version)).toEqual(['2.8.0']);
    expect(by('rejected', 'springdoc')[0]).toMatchObject({ version: '2.8.0', step: 'smoke' });
    // tests honoured, file always restored and disposed
    expect(calls.filter(c => c.startsWith('build')).every(c => c === 'build tests=true')).toBe(true);
    expect(calls.at(-1)).toBe('dispose');
    expect(res.before.vulns.map(v => v.id)).toEqual(['M1', 'M2', 'S1', 'X1']);
    expect(res.after.vulns.map(v => v.id)).toEqual(['M2', 'S1', 'X1']);
    expect(fs.existsSync(path.join(log.runDir, 'report.md'))).toBe(true);
    expect(fs.existsSync(path.join(log.runDir, 'run.json'))).toBe(true);
    expect(log.events().every(e => e.members === undefined)).toBe(true);
    expect(ev.map(({ ts: _ts, durationMs: _d, ...rest }) => rest)).toEqual(SINGLE_EVENTS);
    const fixedTs = new Date(2026, 0, 1, 12, 34, 56).toISOString();
    expect(ev.map(e => formatConsoleLine({ ...e, ts: fixedTs }))).toEqual(SINGLE_CONSOLE);
  });

  it('excludes candidates whose lookup fails instead of scoring them 0', async () => {
    const { tool } = fakeTool();
    const log = newLog();
    await runPlanner(cfg, {
      tool, log,
      scoreTree: async tree => {
        if (tree.some(g => g.name === 'minio' && g.version === '8.6.0')) throw new LookupError('osv', 'GHSA-x', 'HTTP 503 after 4 attempts');
        return fakeScore(tree);
      },
      versionSource: async d => versions[d.name] ?? [],
    });
    const ev = log.events();
    expect(ev.find(e => e.type === 'excluded' && e.version === '8.6.0')).toMatchObject({ step: 'lookup' });
    expect(ev.find(e => e.type === 'adopted' && e.dep === 'io.minio:minio')).toMatchObject({ version: '8.5.10' });
  });

  it('honours projectTests=false and aborts when the baseline fails', async () => {
    const t1 = fakeTool();
    await runPlanner({ ...cfg, projectTests: false }, { tool: t1.tool, log: newLog(), scoreTree: fakeScore, versionSource: async d => versions[d.name] ?? [] });
    expect(t1.calls.filter(c => c.startsWith('build')).every(c => c === 'build tests=false')).toBe(true);

    const t2 = fakeTool({ failBuild: () => true });
    await expect(runPlanner(cfg, { tool: t2.tool, log: newLog(), scoreTree: fakeScore, versionSource: async () => [] })).rejects.toThrow(/baseline build failed/);
    expect(t2.calls.at(-1)).toBe('dispose');
  });

  it('alignmentCheck=false lets the split candidate through to the build', async () => {
    const { tool } = fakeTool();
    const log = newLog();
    await runPlanner({ ...cfg, alignmentCheck: false }, { tool, log, scoreTree: fakeScore, versionSource: async d => versions[d.name] ?? [] });
    expect(log.events().find(e => e.type === 'adopted' && e.dep?.endsWith('jackson-dataformat-xml'))).toMatchObject({ version: '2.18.2' });
  });

  it('stops without further writes or decisions once aborted', async () => {
    const { tool, calls } = fakeTool();
    const log = newLog();
    let aborted = false;
    const realBuild = tool.build;
    let builds = 0;
    tool.build = async o => {
      const r = await realBuild(o);
      if (++builds === 2) aborted = true; // Ctrl+C kills the first candidate build (the baseline was build 1)
      return builds === 2 ? { ...r, ok: false, firstError: 'killed' } : r;
    };
    await expect(runPlanner(cfg, { tool, log, scoreTree: fakeScore, versionSource: async d => versions[d.name] ?? [], isAborted: () => aborted })).rejects.toThrow(/aborted/);
    const idx = calls.map((c, i) => (c.startsWith('apply') ? i : -1)).filter(i => i >= 0);
    expect(calls.slice(idx.at(-1)!).filter(c => c.startsWith('apply'))).toHaveLength(1);
    expect(calls.slice(idx.at(-1)!)).toEqual([calls[idx.at(-1)!], 'build tests=true', 'restore', 'dispose']);
    expect(builds).toBe(2);
    expect(log.events().some(e => e.step === 'build' || e.type === 'adopted' || e.type === 'run-summary')).toBe(false);
  });

  it('turns a throw during apply/classpath into a rejection and still completes', async () => {
    const { tool } = fakeTool();
    const log = newLog();
    const origApply = tool.apply;
    tool.apply = async os => {
      if (os[0].dep.name === 'minio' && os[0].version === '8.6.0') throw new Error('pom write failed');
      return origApply(os);
    };
    const origClasspath = tool.classpath;
    tool.classpath = async () => origClasspath();
    let runs = 0;
    const res = await runPlanner({ ...cfg, exploratoryTesting: true }, {
      tool, log, scoreTree: fakeScore, versionSource: async d => versions[d.name] ?? [],
      randoop: {
        generate: async (_c, logFile) => ({ ok: true, logFile, durationMs: 1 }),
        run: async (_c, logFile) => {
          if (runs++ === 0) return { ok: true, logFile, durationMs: 1 }; // the baseline check passes
          throw new Error('docker exec failed');
        },
        cleanup: async () => {},
      },
    });
    const ev = log.events();
    expect(ev.find(e => e.type === 'rejected' && e.version === '8.6.0')).toMatchObject({ step: 'apply', firstError: 'pom write failed' });
    expect(ev.find(e => e.type === 'rejected' && e.step === 'randoop')).toMatchObject({ firstError: 'docker exec failed' });
    for (const name of ['io.minio:minio', 'org.springdoc:springdoc', 'com.fasterxml.jackson.dataformat:jackson-dataformat-xml']) {
      expect(ev.filter(e => e.dep === name && ['skipped', 'kept', 'adopted'].includes(e.type))).toHaveLength(1);
    }
    expect(fs.existsSync(path.join(log.runDir, 'report.md'))).toBe(true);
    expect(res.report).toBeDefined();
  });

  it('continues with Randoop disabled when generation fails and still cleans up', async () => {
    for (const mode of ['fail', 'throw'] as const) {
      const { tool } = fakeTool();
      const log = newLog();
      let cleaned = 0;
      let ran = 0;
      await runPlanner({ ...cfg, exploratoryTesting: true }, {
        tool, log, scoreTree: fakeScore, versionSource: async d => versions[d.name] ?? [],
        randoop: {
          generate: async (_c, logFile) => { if (mode === 'throw') throw new Error('copy failed'); return { ok: false, logFile, durationMs: 1, firstError: 'javac error' }; },
          run: async (_c, logFile) => { ran++; return { ok: true, logFile, durationMs: 1 }; },
          cleanup: async () => { cleaned++; },
        },
      });
      expect(log.events().find(e => e.type === 'baseline' && e.step === 'randoop')).toMatchObject({ data: { ok: false } });
      expect(ran).toBe(0);
      expect(cleaned).toBe(1);
      expect(log.events().some(e => e.type === 'adopted')).toBe(true);
    }
  });

  it('disables Randoop when the generated tests already fail on the unchanged project', async () => {
    const { tool } = fakeTool();
    const log = newLog();
    let runs = 0;
    await runPlanner({ ...cfg, exploratoryTesting: true }, {
      tool, log, scoreTree: fakeScore, versionSource: async d => versions[d.name] ?? [],
      randoop: {
        generate: async (_c, logFile) => ({ ok: true, logFile, durationMs: 1 }),
        run: async (_c, logFile) => { runs++; return { ok: false, logFile, durationMs: 1, firstError: 'Tests run: 9, Failures: 1' }; },
        cleanup: async () => {},
      },
    });
    const ev = log.events();
    expect(ev.find(e => e.type === 'baseline' && e.step === 'randoop')).toMatchObject({
      firstError: 'generated tests fail on the unchanged project: Tests run: 9, Failures: 1',
      data: { ok: false },
    });
    expect(runs).toBe(1); // only the baseline check: candidates are not judged by these tests
    expect(ev.some(e => e.type === 'rejected' && e.step === 'randoop')).toBe(false);
    expect(ev.some(e => e.type === 'adopted')).toBe(true);
  });

  const vs = async (d: { name: string }) => versions[d.name] ?? [];
  const runJson = (log: EventLog) => JSON.parse(fs.readFileSync(path.join(log.runDir, 'run.json'), 'utf8'));

  it('records alignment on every scored event, flagging misaligned candidates', async () => {
    const { tool } = fakeTool();
    const log = newLog();
    await runPlanner(cfg, { tool, log, scoreTree: fakeScore, versionSource: vs });
    const scored = log.events().filter(e => e.type === 'scored');
    expect(scored.find(e => e.version === '2.18.2')?.data).toEqual({ aligned: false, misalignment: expect.stringContaining('com.fasterxml.jackson split') });
    expect(scored.find(e => e.version === '8.5.10')?.data).toEqual({ aligned: true });
  });

  it('excludes a candidate whose resolution fails, with the Maven log as a relative logFile', async () => {
    const { tool } = fakeTool();
    const log = newLog();
    const orig = tool.resolveTree;
    tool.resolveTree = async o => {
      if (o?.[0]?.version === '8.6.0') throw new ResolveError('mvn dependency:list returned an empty tree', path.join(log.runDir, 'mvn-x.log'));
      return orig(o);
    };
    await runPlanner(cfg, { tool, log, scoreTree: fakeScore, versionSource: vs });
    const ex = log.events().find(e => e.type === 'excluded' && e.version === '8.6.0');
    expect(ex).toMatchObject({ step: 'resolve', reason: 'mvn dependency:list returned an empty tree', logFile: 'mvn-x.log' });
    expect(ex?.reason).not.toContain(log.runDir);
  });

  it('uses the tool\'s bulk resolveTrees when present; a per-version Error excludes only that candidate', async () => {
    const { tool, accepted } = fakeTool();
    const log = newLog();
    const single: string[] = [];
    const orig = tool.resolveTree;
    tool.resolveTree = async o => { if (o) single.push(o[0].version); return orig(o); };
    const bulk: string[][] = [];
    tool.resolveTrees = async (unit, plans) => {
      bulk.push(plans.map(p => p.version));
      return new Map(await Promise.all(plans.map(async p => [p.version, p.version === '8.6.0' ? new ResolveError('gradle saferDeps failed: boom') : await orig([{ dep: unit.members[0], version: p.version }])] as const)));
    };
    await runPlanner(cfg, { tool, log, scoreTree: fakeScore, versionSource: vs });
    expect(single).toEqual([]);
    expect(bulk.find(b => b.includes('8.6.0'))?.sort()).toEqual(['8.5.10', '8.6.0']);
    expect(log.events().find(e => e.type === 'excluded' && e.version === '8.6.0')).toMatchObject({ step: 'resolve', reason: 'gradle saferDeps failed: boom' });
    expect(accepted.minio).toBe('8.5.10');
  });

  it('falls back to per-version resolveTree when the bulk call itself throws', async () => {
    const { tool, accepted } = fakeTool();
    const log = newLog();
    tool.resolveTrees = async () => { throw new Error('daemon died'); };
    await runPlanner(cfg, { tool, log, scoreTree: fakeScore, versionSource: vs });
    expect(log.events().filter(e => e.type === 'excluded')).toEqual([]);
    expect(accepted.minio).toBe('8.6.0');
  });

  it('says a current version missing from Maven Central is probably internal', async () => {
    const { tool } = fakeTool();
    const log = newLog();
    await runPlanner(cfg, { tool, log, scoreTree: fakeScore, versionSource: async d => (d.name === 'minio' ? ['9.0.0'] : versions[d.name] ?? []) });
    expect(log.events().find(e => e.type === 'kept' && e.dep === 'io.minio:minio')?.reason).toBe(
      'current version not on Maven Central (internal or private artifact?), so there is nothing to compare it with',
    );
  });

  it('explains KEEP with the best scored candidate, or says none could be scored', async () => {
    const { tool } = fakeTool();
    const log = newLog();
    await runPlanner(cfg, {
      tool, log, versionSource: vs,
      scoreTree: async tree => {
        if (tree.some(g => g.name === 'springdoc' && g.version === '2.8.0')) throw new LookupError('osv', 'x', 'HTTP 503');
        return fakeScore(tree.map(g => (g.name === 'minio' ? { ...g, version: '8.5.2' } : g)));
      },
    });
    const kept = (n: string) => log.events().find(e => e.type === 'kept' && e.dep?.endsWith(`:${n}`))?.reason;
    expect(kept('minio')).toBe('no candidate scores lower than current (rate 90.0; 2 scored, best 8.5.10 at rate 90.0)');
    expect(kept('springdoc')).toBe('no candidate scores lower than current (rate 90.0; no candidate could be scored); 1 candidates excluded (see EXCLUDE lines)');
  });

  it('creates attempt dirs only for candidates that reach the build', async () => {
    const { tool } = fakeTool({ failBuild: p => p.minio === '8.6.0' });
    const log = newLog();
    await runPlanner(cfg, { tool, log, scoreTree: fakeScore, versionSource: vs });
    const attempts = path.join(log.runDir, 'attempts');
    expect(fs.readdirSync(attempts).sort()).toEqual(['io.minio_minio', 'org.springdoc_springdoc']);
    expect(fs.existsSync(path.join(attempts, 'com.fasterxml.jackson.dataformat_jackson-dataformat-xml'))).toBe(false);
  });

  it('writes run.json with status ok, tool info, and persists baseline/final trees', async () => {
    const { tool } = fakeTool({ failBuild: p => p.minio === '8.6.0' });
    tool.info = () => ({ java: '17', maven: 'Apache Maven 3.9.16' });
    const log = newLog();
    await runPlanner(cfg, { tool, log, scoreTree: fakeScore, versionSource: vs, saferRevision: { revision: 'abc1234', dirty: true } });
    const run = runJson(log);
    expect(run).toMatchObject({ status: 'ok', tools: { safer: { revision: 'abc1234', dirty: true }, node: process.version, java: '17', maven: 'Apache Maven 3.9.16' } });
    expect(run.summary).toMatchObject({ expectedRate: run.summary.finalRate });
    const baseline = fs.readFileSync(path.join(log.runDir, 'trees', 'baseline.txt'), 'utf8').trim().split('\n');
    expect(baseline).toEqual([...baseline].sort());
    expect(baseline).toContain('io.minio:minio:8.5.2');
    expect(fs.readFileSync(path.join(log.runDir, 'trees', 'final.txt'), 'utf8')).toContain('io.minio:minio:8.5.10');
  });

  it('records a failed run: run-failed event, console line and run.json status failed', async () => {
    const { tool } = fakeTool();
    const lines: string[] = [];
    const log = EventLog.create(fs.mkdtempSync(path.join(os.tmpdir(), 'safer-plan-')), 'demo', { console: l => lines.push(l) });
    tool.listDirectDeps = async () => { throw new ResolveError('mvn dependency:list failed: boom'); };
    await expect(runPlanner(cfg, { tool, log, scoreTree: fakeScore, versionSource: vs })).rejects.toThrow(/boom/);
    expect(log.events().at(-1)).toMatchObject({ type: 'run-failed', step: 'resolve', reason: 'mvn dependency:list failed: boom' });
    expect(lines.some(l => / RUN FAILED · resolve: mvn dependency:list failed: boom$/.test(l))).toBe(true);
    expect(runJson(log)).toMatchObject({ status: 'failed', failedStep: 'resolve', error: 'mvn dependency:list failed: boom' });
    expect('units' in runJson(log).summary).toBe(false); // failed before the units were built
  });

  it('records an aborted run as status aborted without run-failed', async () => {
    const { tool } = fakeTool();
    const log = newLog();
    await expect(runPlanner(cfg, { tool, log, scoreTree: fakeScore, versionSource: vs, isAborted: () => true })).rejects.toBeInstanceOf(PlannerAborted);
    expect(runJson(log).status).toBe('aborted');
    expect(log.events().some(e => e.type === 'run-failed')).toBe(false);
  });

  it('includes the unit counts in the summary of a run aborted after the units were built', async () => {
    const { tool } = fakeTool();
    const log = newLog();
    let built = false;
    const list = tool.listDirectDeps;
    tool.listDirectDeps = async () => { built = true; return list(); };
    await expect(runPlanner(cfg, { tool, log, scoreTree: fakeScore, versionSource: vs, isAborted: () => built })).rejects.toBeInstanceOf(PlannerAborted);
    expect(runJson(log).summary).toMatchObject({ units: 3, groupedUnits: 0 });
  });

  it('falls back to the last accepted score when the final re-resolve fails, and still writes the report', async () => {
    const { tool } = fakeTool();
    const lines: string[] = [];
    const log2 = EventLog.create(fs.mkdtempSync(path.join(os.tmpdir(), 'safer-plan-')), 'demo', { console: l => lines.push(l) });
    const orig = tool.resolveTree;
    let plain = 0;
    tool.resolveTree = async o => {
      if (!o && ++plain === 2) throw new ResolveError('network down');
      return orig(o);
    };
    const res = await runPlanner(cfg, { tool, log: log2, scoreTree: fakeScore, versionSource: vs });
    expect(res.after.rate).toBe(log2.events().filter(e => e.type === 'adopted').at(-1)!.rate);
    expect(fs.readFileSync(path.join(log2.runDir, 'report.md'), 'utf8')).toContain('final tree could not be re-resolved: `network down`');
    expect(runJson(log2)).toMatchObject({ status: 'ok' });
    expect(lines.some(l => l.includes('final tree could not be re-resolved'))).toBe(true);
    expect(fs.existsSync(path.join(log2.runDir, 'trees', 'final.txt'))).toBe(true);
  });

  it('warns when the final rate differs from the last accepted rate', async () => {
    const { tool } = fakeTool();
    const lines: string[] = [];
    const log = EventLog.create(fs.mkdtempSync(path.join(os.tmpdir(), 'safer-plan-')), 'demo', { console: l => lines.push(l) });
    let plain = 0;
    const orig = tool.resolveTree;
    tool.resolveTree = async o => {
      const t = await orig(o);
      // the final re-resolve sees an extra vulnerable artifact
      return !o && ++plain === 2 ? [...t, { group: 'io.minio', name: 'minio', version: '8.5.2' }] : t;
    };
    await runPlanner(cfg, { tool, log, scoreTree: fakeScore, versionSource: vs });
    const summary = log.events().find(e => e.type === 'run-summary')!.data!;
    expect(summary.finalRate).not.toBe(summary.expectedRate);
    expect(lines.some(l => /WARNING .*final tree rate .* differs from the last accepted rate/.test(l))).toBe(true);
  });

  it('runs dispose even when Randoop cleanup throws, and keeps the original error', async () => {
    const randoop = (cleanup: () => Promise<void>) => ({
      generate: async (_c: string, logFile: string) => ({ ok: true, logFile, durationMs: 1 }),
      run: async (_c: string, logFile: string) => ({ ok: true, logFile, durationMs: 1 }),
      cleanup,
    });
    const t1 = fakeTool();
    await expect(runPlanner({ ...cfg, exploratoryTesting: true }, { tool: t1.tool, log: newLog(), scoreTree: fakeScore, versionSource: vs, randoop: randoop(async () => { throw new Error('rm failed'); }) })).rejects.toThrow('rm failed');
    expect(t1.calls.at(-1)).toBe('dispose');

    const t2 = fakeTool();
    t2.tool.listDirectDeps = async () => { throw new Error('original'); };
    await expect(runPlanner({ ...cfg, exploratoryTesting: true }, { tool: t2.tool, log: newLog(), scoreTree: fakeScore, versionSource: vs, randoop: randoop(async () => { throw new Error('rm failed'); }) })).rejects.toThrow('original');
    expect(t2.calls.at(-1)).toBe('dispose');
  });

  describe('infrastructure failures', () => {
    const NEXUS_404 = 'Could not find artifact io.minio:minio:jar:8.6.0 in nexus-safer (http://localhost:8081/repository/maven-public/)';
    const infraCheck = async (text: string) => (text.includes('nexus-safer') ? 'the repository did not serve it' : undefined);

    it('stops the run instead of excluding a candidate when its resolution failed for infrastructure reasons', async () => {
      const { tool, calls } = fakeTool();
      const log = newLog();
      const orig = tool.resolveTree;
      tool.resolveTree = async o => {
        if (o?.[0]?.version === '8.6.0') throw new ResolveError(`mvn dependency:list failed: ${NEXUS_404}`);
        return orig(o);
      };
      await expect(runPlanner(cfg, { tool, log, scoreTree: fakeScore, versionSource: vs, infraCheck })).rejects.toBeInstanceOf(InfrastructureError);
      expect(log.events().some(e => e.type === 'excluded' && e.version === '8.6.0')).toBe(false);
      expect(log.events().at(-1)).toMatchObject({ type: 'run-failed', step: 'resolve' });
      expect(calls.at(-1)).toBe('dispose');
    });

    it('stops instead of rejecting a candidate whose build failed for infrastructure reasons, restoring the build file', async () => {
      const { tool, calls, accepted } = fakeTool();
      const log = newLog();
      tool.build = async ({ logFile }) => {
        fs.mkdirSync(path.dirname(logFile), { recursive: true });
        fs.writeFileSync(logFile, `[ERROR] ${NEXUS_404}\n`);
        const ok = !calls.some(c => c.startsWith('apply minio'));
        return { ok, logFile, durationMs: 1, firstError: ok ? undefined : 'Could not resolve dependencies' };
      };
      await expect(runPlanner(cfg, { tool, log, scoreTree: fakeScore, versionSource: vs, infraCheck })).rejects.toThrow(/building io.minio:minio:8.6.0 failed: the repository did not serve it/);
      expect(log.events().some(e => e.type === 'rejected' && e.dep === 'io.minio:minio')).toBe(false);
      expect(calls).toContain('restore');
      expect(accepted.minio).toBe('8.5.2');
    });

    it('reports an infrastructure baseline failure as such, not as a project that does not build', async () => {
      const { tool } = fakeTool({ failBuild: () => true });
      const origBuild = tool.build;
      tool.build = async o => {
        const r = await origBuild(o);
        fs.writeFileSync(o.logFile, NEXUS_404);
        return r;
      };
      await expect(runPlanner(cfg, { tool, log: newLog(), scoreTree: fakeScore, versionSource: vs, infraCheck })).rejects.toThrow(/^baseline build failed: the repository did not serve it/);
    });

    it('still excludes and rejects normally when the check finds no infrastructure problem', async () => {
      const { tool } = fakeTool({ failBuild: p => p.minio === '8.6.0' });
      const log = newLog();
      await runPlanner(cfg, { tool, log, scoreTree: fakeScore, versionSource: vs, infraCheck: async () => undefined });
      expect(log.events().find(e => e.type === 'rejected' && e.version === '8.6.0')).toMatchObject({ step: 'build' });
    });
  });
});

describe('runPlanner with grouped units', () => {
  const ui: DirectDep = { group: 'io.springfox', name: 'springfox-swagger-ui', version: '2.9.2', explicitVersion: true, scope: 'compile' };
  const sw: DirectDep = { group: 'io.springfox', name: 'springfox-swagger2', version: '2.9.2', explicitVersion: true, scope: 'compile' };
  const gdeps = [sw, ui];
  const VULN: Record<string, string[]> = { '2.9.2': ['F1', 'F2'], '2.10.5': ['F2'], '3.0.0': [] };

  function groupTool(opts: { failBuild?: (p: Record<string, string>) => boolean } = {}) {
    const accepted: Record<string, string> = { [sw.name]: sw.version, [ui.name]: ui.version };
    let pom = { ...accepted };
    const calls: string[] = [];
    const tree = (p: Record<string, string>): Gav[] => [
      { group: 'io.springfox', name: 'springfox-swagger2', version: p[sw.name] },
      { group: 'io.springfox', name: 'springfox-swagger-ui', version: p[ui.name] },
      { group: 'io.springfox', name: 'springfox-core', version: p[sw.name] },
    ];
    const tool: BuildTool = {
      name: 'maven', projectName: () => 'demo', hasTests: () => true, init: async () => {},
      listDirectDeps: async () => gdeps,
      resolveTree: async o => tree(o?.length ? { ...accepted, ...Object.fromEntries(o.map(x => [x.dep.name, x.version])) } : accepted),
      apply: async os => { pom = { ...accepted, ...Object.fromEntries(os.map(o => [o.dep.name, o.version])) }; calls.push(`apply ${os.map(o => `${o.dep.name} ${o.version}`).join(', ')}`); return os.map(() => ({ via: 'literal' as const })); },
      restore: async () => { pom = { ...accepted }; calls.push('restore'); },
      accept: async () => { Object.assign(accepted, pom); calls.push('accept'); },
      build: async ({ logFile }) => { fs.mkdirSync(path.dirname(logFile), { recursive: true }); const ok = !opts.failBuild?.(pom); return { ok, logFile, durationMs: 1, firstError: ok ? undefined : 'cannot find symbol' }; },
      classpath: async () => '/app/target/classes', classesDir: () => 'target/classes', packagedArtifact: async () => null, dispose: async () => {},
    };
    return { tool, calls, accepted };
  }
  const score = async (t: Gav[]): Promise<TreeScore> => {
    const ids = [...new Set(t.filter(g => g.name === 'springfox-swagger2').flatMap(g => VULN[g.version] ?? []))];
    return { rate: ids.length * 22.5, vulns: ids.map(id => ({ id, ids: [id], aliases: [], score: 7.5, severity: 'high' as const, scoreSource: 'cvss3' as const, packages: [] })), bySeverity: { low: 0, medium: 0, high: ids.length, critical: 0, unknown: 0 } };
  };
  const vs = async () => ['3.0.0', '2.10.5', '2.9.2'];

  it('adopts a family as one unit instead of rejecting each member on alignment', async () => {
    const { tool, calls, accepted } = groupTool();
    const log = newLog();
    await runPlanner(cfg, { tool, log, scoreTree: score, versionSource: vs });
    const ev = log.events();
    expect(ev.some(e => e.type === 'rejected' && e.step === 'alignment')).toBe(false);
    const adopted = ev.find(e => e.type === 'adopted')!;
    expect(adopted).toMatchObject({ dep: 'io.springfox [springfox-swagger-ui, springfox-swagger2]', from: '2.9.2', version: '3.0.0', groupReason: 'family' });
    expect(adopted.members).toEqual([
      { dep: 'io.springfox:springfox-swagger-ui', from: '2.9.2', to: '3.0.0' },
      { dep: 'io.springfox:springfox-swagger2', from: '2.9.2', to: '3.0.0' },
    ]);
    expect(adopted.data).toEqual({ applied: [{ dep: 'io.springfox:springfox-swagger-ui', via: 'literal' }, { dep: 'io.springfox:springfox-swagger2', via: 'literal' }] });
    expect(accepted).toEqual({ 'springfox-swagger2': '3.0.0', 'springfox-swagger-ui': '3.0.0' });
    expect(calls).toContain('apply springfox-swagger-ui 3.0.0, springfox-swagger2 3.0.0');
    expect(ev.filter(e => ['adopted', 'kept', 'skipped'].includes(e.type))).toHaveLength(1); // one decision for the unit
    const run = JSON.parse(fs.readFileSync(path.join(log.runDir, 'run.json'), 'utf8'));
    expect(run.summary).toMatchObject({ units: 1, groupedUnits: 1 });
    expect(fs.existsSync(path.join(log.runDir, 'attempts', 'group-io.springfox_springfox-swagger-ui+io.springfox_springfox-swagger2', '3.0.0'))).toBe(true);
  });

  it('names a grouped unit with a space in infrastructure messages', async () => {
    const { tool } = groupTool();
    const orig = tool.resolveTree;
    tool.resolveTree = async o => { if (o?.length) throw new ResolveError('nexus-safer down'); return orig(o); };
    const infraCheck = async (text: string) => (text.includes('nexus-safer') ? 'the repository did not serve it' : undefined);
    await expect(runPlanner(cfg, { tool, log: newLog(), scoreTree: score, versionSource: vs, infraCheck })).rejects.toThrow(/resolving io\.springfox \[springfox-swagger-ui, springfox-swagger2\] 3\.0\.0 failed/);
  });

  it('falls back to the next plan when a group build fails, restoring the files', async () => {
    const { tool, calls } = groupTool({ failBuild: p => p['springfox-swagger2'] === '3.0.0' });
    const log = newLog();
    await runPlanner(cfg, { tool, log, scoreTree: score, versionSource: vs });
    const ev = log.events();
    expect(ev.find(e => e.type === 'rejected')).toMatchObject({ version: '3.0.0', step: 'build', members: expect.any(Array) });
    expect(ev.find(e => e.type === 'adopted')).toMatchObject({ version: '2.10.5' });
    expect(calls.indexOf('restore')).toBeGreaterThan(calls.indexOf('apply springfox-swagger-ui 3.0.0, springfox-swagger2 3.0.0'));
  });

  it('keeps a group whose members cannot follow any target', async () => {
    const { tool } = groupTool();
    const log = newLog();
    await runPlanner(cfg, { tool, log, scoreTree: score, versionSource: async d => (d.name === 'springfox-swagger-ui' ? ['2.9.2'] : ['3.0.0', '2.9.2']) });
    expect(log.events().find(e => e.type === 'kept')).toMatchObject({ dep: 'io.springfox [springfox-swagger-ui, springfox-swagger2]', version: '2.9.2', reason: 'no newer version is available for every member of the group' });
  });
});
