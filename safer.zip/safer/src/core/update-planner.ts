import fs from 'fs';
import path from 'path';

import { SmokeTestConfigType, WeightVulnerabilityType } from '../types/config';
import { checkAlignment, describeMisalignment } from './alignment';
import { BuildTool } from './build-tool';
import { CandidateList, VersionPlan, VersionSource, listCandidates, planOverrides, selectGroupCandidates } from './candidates';
import { BaselineError, InfrastructureError, LookupError, ResolveError } from './errors';
import { EventLog, Step, duration } from './event-log';
import { mapLimit } from './limit';
import { DirectDep, Gav, StepResult, depKey } from './model';
import { UpdateUnit, buildUnits, isEligible } from './units';
import { RunReport, buildReport, writeReport } from './report';
import { TreeScore, diffVulns } from './scoring';
import { runSmoke } from './smoke';
import { compareVersions } from './versions';

export type PlannerConfig = {
  projectPath: string;
  weights: WeightVulnerabilityType;
  buildProject: boolean;
  projectTests: boolean;
  exploratoryTesting: boolean;
  allowPrerelease: boolean;
  alignmentCheck: boolean;
  smokeTest?: SmokeTestConfigType;
};

export type RandoopHooks = {
  generate(classpath: string, logFile: string): Promise<StepResult>;
  run(classpath: string, logFile: string): Promise<StepResult>;
  cleanup(): Promise<void>;
};

export type PlannerDeps = {
  tool: BuildTool;
  scoreTree: (tree: Gav[]) => Promise<TreeScore>;
  versionSource: VersionSource;
  log: EventLog;
  randoop?: RandoopHooks;
  runSmoke?: typeof runSmoke;
  scoreConcurrency?: number;
  /** Polled before every apply/resolve/validate step; once true the planner stops without emitting further decisions. */
  isAborted?: () => boolean;
  /**
   * Given a failure's log text, explains why it is an infrastructure problem (see infra.ts) or returns undefined.
   * When it answers, the run stops with an InfrastructureError instead of recording an exclusion or rejection.
   */
  infraCheck?: (logText: string) => Promise<string | undefined>;
  /** Safer's own git revision, recorded in run.json (see saferRevision()). */
  saferRevision?: { revision: string; dirty: boolean };
};

export class PlannerAborted extends Error {
  constructor() {
    super('run aborted');
  }
}

export type PlannerResult = { before: TreeScore; after: TreeScore; report: RunReport };

type Scored = { version: string; plan: VersionPlan; tree: Gav[]; score: TreeScore };
type Failure = { step: Step; firstError: string; logFile?: string; durationMs?: number };

const message = (err: unknown) => (err instanceof Error ? err.message : String(err));
const logFileOf = (err: unknown) => (err instanceof ResolveError ? err.logFile : undefined);
const readLog = (file?: string) => {
  try {
    return file ? fs.readFileSync(file, 'utf8') : '';
  } catch {
    return '';
  }
};

/** Throws InfrastructureError when the failure (its message and log) is a repository/network problem. */
async function stopOnInfra(d: PlannerDeps, what: string, firstError: string, logFile?: string): Promise<void> {
  if (!d.infraCheck) return;
  const why = await d.infraCheck(`${firstError}\n${readLog(logFile)}`);
  if (why) throw new InfrastructureError(`${what}: ${why}. Verdicts after this point would be wrong, so the run stopped; fix the repository/network and run again.`, logFile);
}
const byRateThenVersion = (a: Scored, b: Scored) => a.score.rate - b.score.rate || compareVersions(a.version, b.version);
const ids = (vs: { id: string }[]) => vs.map(v => v.id);

const sameVersion = (u: UpdateUnit) => new Set(u.members.map(m => m.version)).size === 1;
/** Event fields naming a unit: today's dep/version for one member; the label, `mixed` versions and members for a group. */
const unitFrom = (u: UpdateUnit) => (sameVersion(u) ? u.members[0].version : 'mixed');
const groupFields = (u: UpdateUnit, plan?: VersionPlan) =>
  u.members.length === 1
    ? {}
    : { groupReason: u.reason as Exclude<UpdateUnit['reason'], 'single'>, members: u.members.map(m => ({ dep: depKey(m), from: m.version, ...(plan && { to: plan.versions[depKey(m)] }) })) };

export async function runPlanner(cfg: PlannerConfig, d: PlannerDeps): Promise<PlannerResult> {
  const { tool, log } = d;
  const startedAt = new Date().toISOString();
  let randoopReady = false;
  let generateAttempted = false;
  let stage: Step = 'init'; // what the run was doing, for run-failed
  let failed = false;
  let unitCounts: { units: number; groupedUnits: number } | undefined; // set once the units are built
  const checkAbort = () => {
    if (d.isAborted?.()) throw new PlannerAborted();
  };
  const count = (t: string) => log.events().filter(e => e.type === t).length;
  const counts = () => ({ adopted: count('adopted'), kept: count('kept'), skipped: count('skipped'), rejected: count('rejected'), excluded: count('excluded') });
  const writeRun = (status: 'ok' | 'failed' | 'aborted', extra: Record<string, unknown>) => {
    const finishedAt = new Date().toISOString();
    let toolInfo: Record<string, string> = {};
    try {
      toolInfo = tool.info?.() ?? {};
    } catch {
      // tool info is best effort
    }
    log.writeRunJson({
      project: tool.projectName(),
      status,
      startedAt,
      finishedAt,
      durationMs: Date.parse(finishedAt) - Date.parse(startedAt),
      tools: { safer: d.saferRevision ?? { revision: 'unknown', dirty: false }, node: process.version, ...toolInfo },
      config: cfg,
      ...extra,
    });
    return finishedAt;
  };
  try {
    await tool.init();
    const testsOn = cfg.projectTests && tool.hasTests();

    let buildNote = 'build skipped';
    if (cfg.buildProject) {
      stage = 'build';
      const logFile = path.join(log.runDir, 'baseline', 'build.log');
      const r = await tool.build({ tests: testsOn, logFile });
      if (!r.ok) {
        log.emit({ type: 'baseline', step: 'build', firstError: r.firstError, logFile: log.rel(logFile), durationMs: r.durationMs, data: { ok: false, tests: testsOn } });
        await stopOnInfra(d, 'baseline build failed', r.firstError ?? '', logFile);
        throw new BaselineError(
          `baseline build failed (tests ${testsOn ? 'on' : 'off'}): ${r.firstError}. Safer cannot judge candidates. Fix the build${testsOn ? ' or set executions.projectTests=false' : ''}.`,
        );
      }
      buildNote = `build ok (tests ${testsOn ? 'on' : 'off'}, ${duration(r.durationMs)})`;
    }

    stage = 'resolve';
    let baselineTree = await tool.resolveTree();
    log.writeTree('baseline', baselineTree);
    stage = 'lookup';
    let current = await d.scoreTree(baselineTree);
    const before = current;
    log.emit({ type: 'baseline', rate: current.rate, data: { ok: true, build: buildNote, distinct: current.vulns.length, bySeverity: current.bySeverity, tree: baselineTree.length } });

    if (cfg.exploratoryTesting && cfg.buildProject && d.randoop) {
      stage = 'randoop';
      const logFile = path.join(log.runDir, 'baseline', 'randoop-generate.log');
      generateAttempted = true;
      try {
        const classpath = await tool.classpath();
        const r = await d.randoop.generate(classpath, logFile);
        if (!r.ok) log.emit({ type: 'baseline', step: 'randoop', firstError: r.firstError, logFile: log.rel(logFile), data: { ok: false } });
        else {
          // generated tests that already fail (or flake) on the unchanged project would reject every candidate
          const check = await d.randoop.run(classpath, path.join(log.runDir, 'baseline', 'randoop.log'));
          randoopReady = check.ok;
          if (!check.ok)
            log.emit({ type: 'baseline', step: 'randoop', firstError: `generated tests fail on the unchanged project: ${check.firstError ?? 'failed'}`, logFile: log.rel(check.logFile), data: { ok: false } });
        }
      } catch (err) {
        randoopReady = false;
        log.emit({ type: 'baseline', step: 'randoop', firstError: message(err), logFile: log.rel(logFileOf(err) ?? logFile), data: { ok: false } });
      }
    }

    stage = 'resolve';
    const directDeps = await tool.listDirectDeps();
    const units = buildUnits(directDeps, baselineTree);
    unitCounts = { units: units.length, groupedUnits: units.filter(u => u.members.length > 1).length };
    const unitOf = new Map(units.flatMap(u => u.members.map(m => [depKey(m), u] as const)));
    const done = new Set<string>();
    for (const dep of directDeps) {
      checkAbort();
      stage = 'resolve';
      if (!dep.explicitVersion) {
        log.emit({ type: 'skipped', dep: depKey(dep), version: dep.version, reason: 'version managed by parent/BOM' });
        continue;
      }
      if (!isEligible(dep)) {
        log.emit({ type: 'skipped', dep: depKey(dep), version: dep.version, reason: `scope ${dep.scope}: not part of the shipped runtime tree` });
        continue;
      }
      const unit = unitOf.get(depKey(dep))!;
      if (done.has(unit.id)) continue; // a later member of a unit already decided
      done.add(unit.id);
      const id = unit.label;
      const single = unit.members.length === 1;

      const lists: { dep: DirectDep; list: CandidateList }[] = [];
      try {
        for (const m of unit.members) lists.push({ dep: m, list: await listCandidates(m, { allowPrerelease: cfg.allowPrerelease }, d.versionSource) });
      } catch (err) {
        log.emit({ type: 'kept', dep: id, version: unitFrom(unit), step: 'lookup', reason: `candidate lookup failed: ${message(err)}`, ...groupFields(unit) });
        continue;
      }
      const { plans, reason } = selectGroupCandidates(lists);
      log.emit({
        type: 'candidates', dep: id, version: unitFrom(unit), ...groupFields(unit),
        data: single ? lists[0].list : { reason: unit.reason, plans, members: Object.fromEntries(lists.map(l => [depKey(l.dep), l.list])) },
      });
      if (plans.length === 0) {
        const why = single
          ? lists[0].list.currentFound ? 'already at the newest eligible version' : 'current version not on Maven Central (internal or private artifact?), so there is nothing to compare it with'
          : reason ?? 'no newer version is available for every member of the group';
        log.emit({ type: 'kept', dep: id, version: unitFrom(unit), reason: why, ...groupFields(unit) });
        continue;
      }

      checkAbort();
      // bulk resolution when the tool offers it; a failure of the bulk call itself falls back to per-version calls
      const trees = tool.resolveTrees ? await tool.resolveTrees(unit, plans).catch(() => undefined) : undefined;
      checkAbort();
      let infra: InfrastructureError | undefined; // thrown once every in-flight resolution has settled
      const scoredAll = await mapLimit(plans, d.scoreConcurrency ?? 2, async (plan): Promise<Scored | null> => {
        const version = plan.version;
        try {
          if (d.isAborted?.()) return null;
          const pre = trees?.get(version);
          if (pre instanceof Error) throw pre;
          const tree = pre ?? (await tool.resolveTree(planOverrides(unit, plan)));
          const score = await d.scoreTree(tree);
          const diff = diffVulns(current, score);
          // recorded for every scored candidate (S5), even those never tried; rejection still happens in validate
          const split = checkAlignment(baselineTree, tree);
          const alignment = split.length ? { aligned: false, misalignment: split.map(describeMisalignment).join('; ') } : { aligned: true };
          log.emit({ type: 'scored', dep: id, version, rate: score.rate, currentRate: current.rate, added: ids(diff.introduced), removed: ids(diff.fixed), data: alignment, ...groupFields(unit, plan) });
          return { version, plan, tree, score };
        } catch (err) {
          const logFile = logFileOf(err);
          if (infra) return null;
          if (!(err instanceof LookupError)) {
            try {
              await stopOnInfra(d, `resolving ${id}${unit.members.length > 1 ? ' ' : ':'}${version} failed`, message(err), logFile);
            } catch (e) {
              if (e instanceof InfrastructureError) {
                infra = e;
                return null;
              }
              throw e;
            }
          }
          log.emit({ type: 'excluded', dep: id, version, step: err instanceof LookupError ? 'lookup' : 'resolve', reason: message(err), logFile: logFile ? log.rel(logFile) : undefined, ...groupFields(unit, plan) });
          return null;
        }
      });
      if (infra) throw infra;
      checkAbort();
      const scored = scoredAll.filter((s): s is Scored => s !== null);
      const excludedCount = scoredAll.length - scored.length;
      const better = scored.filter(s => s.score.rate < current.rate).sort(byRateThenVersion);
      if (better.length === 0) {
        const extra = excludedCount ? `; ${excludedCount} candidates excluded (see EXCLUDE lines)` : '';
        const best = [...scored].sort(byRateThenVersion)[0];
        const detail = best ? `${scored.length} scored, best ${best.version} at rate ${best.score.rate.toFixed(1)}` : 'no candidate could be scored';
        log.emit({ type: 'kept', dep: id, version: unitFrom(unit), reason: `no candidate scores lower than current (rate ${current.rate.toFixed(1)}; ${detail})${extra}`, ...groupFields(unit) });
        continue;
      }

      let adopted = false;
      stage = 'apply'; // apply/restore/accept of the build file
      for (const c of better) {
        checkAbort();
        const attemptDir = () => log.attemptDir(unit.id, c.version); // created only when a step writes a log
        const progress: { step: Step } = { step: 'apply' };
        let applied: { via: string; property?: string }[] | undefined;
        let failure: Failure | null;
        try {
          applied = await tool.apply(planOverrides(unit, c.plan));
          failure = await validate(cfg, d, testsOn, randoopReady, baselineTree, c, attemptDir, progress, checkAbort);
          checkAbort(); // a step killed by the abort must not be reported as a rejection
        } catch (err) {
          if (err instanceof PlannerAborted) {
            await tool.restore();
            throw err;
          }
          failure = { step: progress.step, firstError: message(err), logFile: logFileOf(err) };
        }
        if (failure) {
          if (failure.step === 'build') {
            try {
              await stopOnInfra(d, `building ${id}${unit.members.length > 1 ? ' ' : ':'}${c.version} failed`, failure.firstError, failure.logFile);
            } catch (err) {
              await tool.restore();
              throw err;
            }
          }
          log.emit({ type: 'rejected', dep: id, version: c.version, ...failure, logFile: failure.logFile ? log.rel(failure.logFile) : undefined, ...groupFields(unit, c.plan) });
          await tool.restore();
          continue;
        }
        await tool.accept();
        const diff = diffVulns(current, c.score);
        log.emit({ type: 'adopted', dep: id, from: unitFrom(unit), version: c.version, rate: c.score.rate, currentRate: current.rate, added: ids(diff.introduced), removed: ids(diff.fixed), data: single ? applied?.[0] : { applied: (applied ?? []).map((a, i) => ({ dep: depKey(unit.members[i]), ...a })) }, ...groupFields(unit, c.plan) });
        baselineTree = c.tree;
        current = c.score;
        adopted = true;
        break;
      }
      if (!adopted) log.emit({ type: 'kept', dep: id, version: unitFrom(unit), reason: `all ${better.length} lower-score candidates failed validation (see REJECT lines)`, ...groupFields(unit) });
    }

    // Final tree: re-resolved from the accepted pom; if that fails, the last accepted tree/score stand in.
    const notes: string[] = [];
    let after = current;
    let finalTree = baselineTree;
    try {
      stage = 'resolve';
      const tree = await tool.resolveTree();
      stage = 'lookup';
      after = await d.scoreTree(tree);
      finalTree = tree;
    } catch (err) {
      notes.push(`final tree could not be re-resolved: \`${message(err)}\`; the report uses the last accepted tree and score`);
      log.warn(`WARNING   final tree could not be re-resolved (${message(err)}); using the last accepted tree and score`);
    }
    if (Math.abs(after.rate - current.rate) > 0.005) {
      const msg = `final tree rate ${after.rate.toFixed(1)} differs from the last accepted rate ${current.rate.toFixed(1)}`;
      notes.push(msg);
      log.warn(`WARNING   ${msg}`);
    }

    stage = 'report';
    log.writeTree('final', finalTree);
    const finishedAt = new Date().toISOString();
    const report = buildReport({ project: tool.projectName(), runDir: log.runDir, startedAt, finishedAt, before, after, events: log.events(), notes });
    writeReport(log.runDir, report);
    const summary = { ...counts(), ...unitCounts, before: before.vulns.length, after: after.vulns.length, beforeRate: before.rate, expectedRate: current.rate, finalRate: after.rate };
    writeRun('ok', { summary, notes });
    log.emit({ type: 'run-summary', data: summary });
    log.printSummary(report.decisions);
    return { before, after, report };
  } catch (err) {
    failed = true;
    try {
      if (err instanceof PlannerAborted) {
        writeRun('aborted', { summary: { ...counts(), ...unitCounts } });
      } else {
        log.emit({ type: 'run-failed', step: stage, reason: message(err) });
        writeRun('failed', { failedStep: stage, error: message(err), summary: { ...counts(), ...unitCounts } });
      }
    } catch {
      // recording the failure must not mask it
    }
    throw err;
  } finally {
    // each cleanup runs even if another fails; the run's own error wins over cleanup errors
    const cleanupErrors: unknown[] = [];
    if (generateAttempted) {
      try {
        await d.randoop?.cleanup();
      } catch (err) {
        cleanupErrors.push(err);
      }
    }
    try {
      await tool.dispose();
    } catch (err) {
      cleanupErrors.push(err);
    }
    if (cleanupErrors.length) {
      if (failed) log.warn(`cleanup failed: ${cleanupErrors.map(message).join('; ')}`);
      else throw cleanupErrors[0]; // eslint-disable-line no-unsafe-finally
    }
  }
}

async function validate(
  cfg: PlannerConfig,
  d: PlannerDeps,
  testsOn: boolean,
  randoopReady: boolean,
  baselineTree: Gav[],
  c: Scored,
  attemptDir: () => string,
  progress: { step: Step },
  checkAbort: () => void,
): Promise<Failure | null> {
  checkAbort();
  progress.step = 'alignment';
  if (cfg.alignmentCheck) {
    const split = checkAlignment(baselineTree, c.tree);
    if (split.length) return { step: 'alignment', firstError: split.map(describeMisalignment).join('; ') };
  }
  if (!cfg.buildProject) return null;
  checkAbort();
  progress.step = 'build';
  const attempt = attemptDir(); // alignment rejects leave no empty attempt dir
  const b = await d.tool.build({ tests: testsOn, logFile: path.join(attempt, 'build.log') });
  if (!b.ok) return { step: 'build', firstError: b.firstError ?? 'build failed', logFile: b.logFile, durationMs: b.durationMs };
  checkAbort();
  if (randoopReady && d.randoop) {
    progress.step = 'randoop';
    const r = await d.randoop.run(await d.tool.classpath(), path.join(attempt, 'randoop.log'));
    if (!r.ok) return { step: 'randoop', firstError: r.firstError ?? 'Randoop regression tests failed', logFile: r.logFile, durationMs: r.durationMs };
  }
  checkAbort();
  if (cfg.smokeTest?.enabled) {
    progress.step = 'smoke';
    const s = await (d.runSmoke ?? runSmoke)(cfg.smokeTest, { projectPath: cfg.projectPath, artifact: await d.tool.packagedArtifact(), attemptDir: attempt }, path.join(attempt, 'smoke.log'));
    if (!s.ok) return { step: 'smoke', firstError: s.firstError ?? 'smoke test failed', logFile: s.logFile, durationMs: s.durationMs };
  }
  return null;
}
