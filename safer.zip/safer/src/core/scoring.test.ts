import { describe, expect, it } from 'vitest';

import { OsvRecord, VulnSource } from './osv-client';
import { diffVulns, scoreRecord, scoreTree, severityFromScore } from './scoring';

const W = { low: 1, medium: 2, high: 3, critical: 5 };
const V31_98 = 'CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H'; // 9.8
const V31_75 = 'CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N'; // 7.5

function source(idsByGav: Record<string, string[]>, recs: OsvRecord[]): VulnSource {
  return {
    vulnIds: async gavs => new Map(gavs.map(g => [`${g.group}:${g.name}:${g.version}`, idsByGav[`${g.group}:${g.name}:${g.version}`] ?? []])),
    records: async ids => new Map(recs.filter(r => ids.includes(r.id)).map(r => [r.id, r])),
  };
}

describe('severity', () => {
  it.each([[0.1, 'low'], [3.9, 'low'], [4.0, 'medium'], [6.9, 'medium'], [7.0, 'high'], [8.9, 'high'], [9.0, 'critical']] as const)(
    '%f -> %s',
    (s, sev) => expect(severityFromScore(s)).toBe(sev),
  );
  it('label never contradicts score: GitHub CRITICAL with 7.5 is high', () => {
    expect(scoreRecord({ id: 'x', aliases: [], cvssV3: V31_75, githubSeverity: 'CRITICAL' })).toEqual({ score: 7.5, severity: 'high', scoreSource: 'cvss3' });
  });
  it('label fallback uses band floor; nothing -> unknown/0', () => {
    expect(scoreRecord({ id: 'x', aliases: [], githubSeverity: 'MODERATE' })).toEqual({ score: 4.0, severity: 'medium', scoreSource: 'github-label' });
    expect(scoreRecord({ id: 'x', aliases: [] })).toEqual({ score: 0, severity: 'unknown', scoreSource: 'none' });
  });
});

describe('scoreTree', () => {
  it('counts each vulnerability once across the tree and merges aliases', async () => {
    const tree = [
      { group: 'com.f', name: 'core', version: '2.14.2' },
      { group: 'com.f', name: 'databind', version: '2.14.2' },
    ];
    const src = source(
      { 'com.f:core:2.14.2': ['GHSA-a', 'GHSA-b'], 'com.f:databind:2.14.2': ['GHSA-a', 'OSV-c'] },
      [
        { id: 'GHSA-a', aliases: ['CVE-1'], cvssV3: V31_98 },
        { id: 'GHSA-b', aliases: [], cvssV3: V31_75 },
        { id: 'OSV-c', aliases: ['CVE-1'] },
      ],
    );
    const s = await scoreTree(tree, src, W);
    expect(s.vulns.map(v => v.id)).toEqual(['GHSA-a', 'GHSA-b']);
    expect(s.vulns[0].ids).toEqual(['GHSA-a', 'OSV-c']);
    expect(s.vulns[0].packages).toEqual(['com.f:core:2.14.2', 'com.f:databind:2.14.2']);
    expect(s.bySeverity).toEqual({ low: 0, medium: 0, high: 1, critical: 1, unknown: 0 });
    expect(s.rate).toBe(9.8 * 5 + 7.5 * 3);
  });
  it('diffVulns matches by any shared id or alias', async () => {
    const before = await scoreTree([{ group: 'g', name: 'a', version: '1' }], source({ 'g:a:1': ['GHSA-a', 'GHSA-b'] }, [
      { id: 'GHSA-a', aliases: ['CVE-1'], cvssV3: V31_98 },
      { id: 'GHSA-b', aliases: [], cvssV3: V31_75 },
    ]), W);
    const after = await scoreTree([{ group: 'g', name: 'a', version: '2' }], source({ 'g:a:2': ['OSV-x', 'GHSA-n'] }, [
      { id: 'OSV-x', aliases: ['CVE-1'], cvssV3: V31_98 },
      { id: 'GHSA-n', aliases: [], cvssV3: V31_75 },
    ]), W);
    const d = diffVulns(before, after);
    expect(d.fixed.map(v => v.id)).toEqual(['GHSA-b']);
    expect(d.introduced.map(v => v.id)).toEqual(['GHSA-n']);
  });
});
