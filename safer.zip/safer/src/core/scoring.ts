import { parseCvssVector } from 'vuln-vects';

import { WeightVulnerabilityType } from '../types/config';
import { Gav, Severity } from './model';
import { OsvRecord, VulnSource } from './osv-client';

export type ScoredVuln = {
  id: string; // canonical: smallest OSV id of the merged group
  ids: string[]; // all OSV ids merged into this vulnerability
  aliases: string[];
  score: number;
  severity: Severity;
  scoreSource: 'cvss3' | 'github-label' | 'none';
  packages: string[]; // gavKeys in the tree carrying it
};

export type TreeScore = { rate: number; vulns: ScoredVuln[]; bySeverity: Record<Severity, number> };

const BAND_FLOOR = { low: 0.1, medium: 4.0, high: 7.0, critical: 9.0 } as const;
const LABEL: Record<string, keyof typeof BAND_FLOOR> = { LOW: 'low', MODERATE: 'medium', MEDIUM: 'medium', HIGH: 'high', CRITICAL: 'critical' };

export function severityFromScore(score: number): Severity {
  if (score <= 0) return 'unknown';
  if (score < 4.0) return 'low';
  if (score < 7.0) return 'medium';
  if (score < 9.0) return 'high';
  return 'critical';
}

export function scoreRecord(r: OsvRecord): { score: number; severity: Severity; scoreSource: ScoredVuln['scoreSource'] } {
  if (r.cvssV3) {
    try {
      const score = parseCvssVector(r.cvssV3).overallScore;
      if (score > 0) return { score, severity: severityFromScore(score), scoreSource: 'cvss3' };
    } catch {
      // malformed vector: fall through to the label
    }
  }
  const label = r.githubSeverity ? LABEL[r.githubSeverity.toUpperCase()] : undefined;
  if (label) return { score: BAND_FLOOR[label], severity: label, scoreSource: 'github-label' };
  return { score: 0, severity: 'unknown', scoreSource: 'none' };
}

/** Groups OSV ids that describe the same vulnerability (shared id or alias). */
function mergeGroups(records: OsvRecord[]): OsvRecord[][] {
  const parent = new Map<string, string>();
  const find = (x: string): string => {
    while (parent.get(x) !== x) x = parent.get(x)!;
    return x;
  };
  const union = (a: string, b: string) => {
    for (const k of [a, b]) if (!parent.has(k)) parent.set(k, k);
    parent.set(find(a), find(b));
  };
  for (const r of records) {
    union(r.id, r.id);
    for (const alias of r.aliases) union(r.id, alias);
  }
  const groups = new Map<string, OsvRecord[]>();
  for (const r of records) {
    const root = find(r.id);
    groups.set(root, [...(groups.get(root) ?? []), r]);
  }
  return [...groups.values()];
}

export async function scoreTree(tree: Gav[], source: VulnSource, weights: WeightVulnerabilityType): Promise<TreeScore> {
  const idsByGav = await source.vulnIds(tree);
  const allIds = [...new Set([...idsByGav.values()].flat())];
  const records = await source.records(allIds);
  const packagesOf = (id: string) => [...idsByGav.entries()].filter(([, ids]) => ids.includes(id)).map(([k]) => k);

  const vulns: ScoredVuln[] = mergeGroups(allIds.map(id => records.get(id)!)).map(group => {
    const scored = group.map(r => ({ r, ...scoreRecord(r) })).sort((a, b) => b.score - a.score);
    const best = scored[0];
    const ids = group.map(r => r.id).sort();
    return {
      id: ids[0],
      ids,
      aliases: [...new Set(group.flatMap(r => r.aliases))].filter(a => !ids.includes(a)).sort(),
      score: best.score,
      severity: best.severity,
      scoreSource: best.scoreSource,
      packages: [...new Set(ids.flatMap(packagesOf))].sort(),
    };
  });
  vulns.sort((a, b) => a.id.localeCompare(b.id));

  const bySeverity: Record<Severity, number> = { low: 0, medium: 0, high: 0, critical: 0, unknown: 0 };
  let rate = 0;
  for (const v of vulns) {
    bySeverity[v.severity]++;
    rate += v.score * (v.severity === 'unknown' ? 0 : weights[v.severity] ?? 0);
  }
  return { rate: Math.round(rate * 100) / 100, vulns, bySeverity };
}

const keysOf = (v: ScoredVuln) => [...v.ids, ...v.aliases];

export function diffVulns(before: TreeScore, after: TreeScore): { fixed: ScoredVuln[]; introduced: ScoredVuln[] } {
  const beforeKeys = new Set(before.vulns.flatMap(keysOf));
  const afterKeys = new Set(after.vulns.flatMap(keysOf));
  return {
    fixed: before.vulns.filter(v => !keysOf(v).some(k => afterKeys.has(k))),
    introduced: after.vulns.filter(v => !keysOf(v).some(k => beforeKeys.has(k))),
  };
}
