/**
 * Maven-style version handling: numeric components compared one by one (missing = 0),
 * then the qualifier by Maven's order alpha < beta < milestone < rc < snapshot < release < sp.
 * Unknown qualifiers ("jre", "android") are flavors: they rank after sp and compare by text.
 */
export type ParsedVersion = { parts: number[]; qualifier: string; qualifierName: string; qualifierNumber: number; rank: number };

const RANK: Record<string, number> = {
  alpha: 1, a: 1, ea: 1, preview: 1, pre: 1, dev: 1,
  beta: 2, b: 2,
  milestone: 3, m: 3,
  rc: 4, cr: 4,
  snapshot: 5,
  '': 6, ga: 6, final: 6, release: 6,
  sp: 7,
};
const RELEASE_RANK = 6;
const FLAVOR_RANK = 8;

export function parseVersion(version: string): ParsedVersion {
  const v = version.trim().toLowerCase();
  const m = v.match(/^(\d+(?:\.\d+)*)(.*)$/);
  if (!m) return { parts: [], qualifier: v, qualifierName: v, qualifierNumber: 0, rank: FLAVOR_RANK };
  const parts = m[1].split('.').map(Number);
  const qualifier = m[2].replace(/^[.-]/, '');
  const q = qualifier.match(/^([a-z]*)[.-]?(\d*)/);
  const qualifierName = q ? q[1] : qualifier;
  const qualifierNumber = q && q[2] ? Number(q[2]) : 0;
  const rank = RANK[qualifierName] ?? FLAVOR_RANK;
  return { parts, qualifier, qualifierName, qualifierNumber, rank };
}

const sign = (n: number): -1 | 0 | 1 => (n < 0 ? -1 : n > 0 ? 1 : 0);

export function compareVersions(a: string, b: string): -1 | 0 | 1 {
  const pa = parseVersion(a);
  const pb = parseVersion(b);
  const n = Math.max(pa.parts.length, pb.parts.length);
  for (let i = 0; i < n; i++) {
    const d = (pa.parts[i] ?? 0) - (pb.parts[i] ?? 0);
    if (d !== 0) return sign(d);
  }
  if (pa.rank !== pb.rank) return sign(pa.rank - pb.rank);
  if (pa.rank === FLAVOR_RANK && pa.qualifierName !== pb.qualifierName) return sign(pa.qualifierName.localeCompare(pb.qualifierName));
  if (pa.qualifierNumber !== pb.qualifierNumber) return sign(pa.qualifierNumber - pb.qualifierNumber);
  return 0;
}

export const isPrerelease = (v: string): boolean => parseVersion(v).rank < RELEASE_RANK;

/** Non-pre-release qualifier that marks a parallel line of releases (guava "jre"/"android"); '' if none. */
export const flavor = (v: string): string => {
  const p = parseVersion(v);
  return p.rank === FLAVOR_RANK ? p.qualifierName : '';
};

export const isDateStyle = (v: string): boolean => (parseVersion(v).parts[0] ?? 0) >= 1900;

export const majorMinor = (v: string): string => {
  const p = parseVersion(v).parts;
  return `${p[0] ?? 0}.${p[1] ?? 0}`;
};

export const familyKey = (group: string): string => group.split('.').slice(0, 3).join('.');
