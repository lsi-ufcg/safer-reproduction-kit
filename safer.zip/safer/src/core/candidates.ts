import { LookupError } from './errors';
import { fetchJsonWithRetry, RetryOptions } from './http';
import { Gav, Override, depKey } from './model';
import { UpdateUnit } from './units';
import { compareVersions, flavor, isDateStyle, isPrerelease, majorMinor } from './versions';

export type VersionSource = (dep: Gav) => Promise<string[]>;

export type CandidateList = {
  current: string;
  candidates: string[]; // ascending, strictly newer than current
  currentFound: boolean;
  olderCount: number;
  dropped: { prerelease: string[]; dateStyle: string[]; flavor: string[] };
};

export function selectCandidates(current: string, available: string[], opts: { allowPrerelease: boolean }): CandidateList {
  const result: CandidateList = {
    current,
    candidates: [],
    currentFound: available.some(v => compareVersions(v, current) === 0),
    olderCount: 0,
    dropped: { prerelease: [], dateStyle: [], flavor: [] },
  };
  if (!result.currentFound) return result; // no downgrades: without a reference point nothing is "newer"
  const allowPre = opts.allowPrerelease || isPrerelease(current);
  const currentIsDate = isDateStyle(current);
  const currentFlavor = flavor(current);
  for (const v of [...new Set(available)].sort(compareVersions)) {
    if (compareVersions(v, current) <= 0) {
      if (compareVersions(v, current) < 0) result.olderCount++;
      continue;
    }
    if (!currentIsDate && isDateStyle(v)) result.dropped.dateStyle.push(v);
    else if (!allowPre && isPrerelease(v)) result.dropped.prerelease.push(v);
    else if (flavor(v) !== currentFlavor) result.dropped.flavor.push(v);
    else result.candidates.push(v);
  }
  return result;
}

export async function listCandidates(dep: Gav, opts: { allowPrerelease: boolean }, source: VersionSource): Promise<CandidateList> {
  return selectCandidates(dep.version, await source(dep), opts);
}

/** One candidate for an update unit: the target version and the version each member (group:name) moves to. */
export type VersionPlan = { version: string; versions: Record<string, string> };

/**
 * Plans for moving a unit's members together. Targets are every member's candidates; a member without the target gets
 * its newest candidate in the target's major.minor that is older than it (families whose artifacts lag a patch), and a
 * target some member cannot follow is dropped. Plans with identical member versions are kept once (first target).
 */
export function selectGroupCandidates(members: { dep: Gav; list: CandidateList }[]): { plans: VersionPlan[]; reason?: string } {
  const unknown = members.find(m => !m.list.currentFound);
  if (unknown) return { plans: [], reason: `current version of ${depKey(unknown.dep)} not on Maven Central (internal or private artifact?), so there is nothing to compare it with` };
  const targets = [...new Set(members.flatMap(m => m.list.candidates))].sort(compareVersions);
  const plans: VersionPlan[] = [];
  const seen = new Set<string>();
  for (const target of targets) {
    const versions: Record<string, string> = {};
    for (const { dep, list } of members) {
      const v = list.candidates.includes(target) ? target : list.candidates.filter(c => majorMinor(c) === majorMinor(target) && compareVersions(c, target) < 0).sort(compareVersions).at(-1);
      if (!v) break;
      versions[depKey(dep)] = v;
    }
    if (Object.keys(versions).length !== members.length) continue;
    const signature = JSON.stringify(versions);
    if (seen.has(signature)) continue;
    seen.add(signature);
    plans.push({ version: target, versions });
  }
  return { plans };
}

/** The overrides of one plan, in member order. */
export const planOverrides = (unit: UpdateUnit, plan: VersionPlan): Override[] => unit.members.map(dep => ({ dep, version: plan.versions[depKey(dep)] }));

const SONATYPE_URL = 'https://central.sonatype.com/api/internal/browse/component/versions';

/** Sonatype Central browse API, newest first, paged until the current version shows up. */
export function sonatypeVersionSource(opts: Partial<RetryOptions> & { baseUrl?: string } = {}): VersionSource {
  return async dep => {
    const versions: string[] = [];
    for (let page = 0; ; page++) {
      const params = new URLSearchParams({
        filter: `namespace:${dep.group},name:${dep.name}`,
        sortField: 'normalizedVersion',
        sortDirection: 'desc',
        page: String(page),
        size: '20',
      });
      const { status, body } = await fetchJsonWithRetry(`${opts.baseUrl ?? SONATYPE_URL}?${params}`, { method: 'GET' }, {
        retries: opts.retries ?? 3,
        backoffMs: opts.backoffMs ?? 1000,
        timeoutMs: opts.timeoutMs ?? 30000,
        fetchImpl: opts.fetchImpl,
        source: 'sonatype',
        target: depKey(dep),
      });
      if (status !== 200 || !Array.isArray(body?.components)) throw new LookupError('sonatype', depKey(dep), `HTTP ${status}`);
      const pageVersions: string[] = body.components.map((c: { version: string }) => c.version);
      versions.push(...pageVersions);
      if (pageVersions.includes(dep.version) || page + 1 >= (body.pageCount ?? 0) || pageVersions.length === 0) return versions;
    }
  };
}

const MAVEN_CENTRAL_URL = 'https://repo1.maven.org/maven2';

/**
 * Maven Central's maven-metadata.xml: a stable, public file, but its <versions> list misses some old releases,
 * so it is only a fallback for the Sonatype browse API (an internal endpoint that may change). 404 means not on Central.
 */
export function mavenMetadataVersionSource(opts: Partial<RetryOptions> & { baseUrl?: string } = {}): VersionSource {
  return async dep => {
    const url = `${opts.baseUrl ?? MAVEN_CENTRAL_URL}/${dep.group.replace(/\./g, '/')}/${dep.name}/maven-metadata.xml`;
    const { status, body } = await fetchJsonWithRetry(url, { method: 'GET' }, {
      retries: opts.retries ?? 3,
      backoffMs: opts.backoffMs ?? 1000,
      timeoutMs: opts.timeoutMs ?? 30000,
      fetchImpl: opts.fetchImpl,
      source: 'maven-central',
      target: depKey(dep),
    });
    if (status === 404) return [];
    if (status !== 200 || typeof body !== 'string') throw new LookupError('maven-central', depKey(dep), `HTTP ${status}`);
    return [...body.matchAll(/<version>\s*([^<\s]+)\s*<\/version>/g)].map(m => m[1]);
  };
}

/** Uses `fallback` only when `primary` fails with a LookupError; if both fail, the primary's error is kept. */
export function withFallback(primary: VersionSource, fallback: VersionSource): VersionSource {
  return async dep => {
    try {
      return await primary(dep);
    } catch (err) {
      if (!(err instanceof LookupError)) throw err;
      try {
        return await fallback(dep);
      } catch {
        throw err;
      }
    }
  };
}
