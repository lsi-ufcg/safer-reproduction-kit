import fs from 'fs';
import path from 'path';

import { DecisionEvent, SummaryRow } from './event-log';
import { Severity } from './model';
import { ScoredVuln, TreeScore, diffVulns } from './scoring';

export type ReportInput = { project: string; runDir: string; startedAt: string; finishedAt: string; before: TreeScore; after: TreeScore; events: DecisionEvent[]; notes?: string[] };
export type ScoreSummary = { distinct: number; rate: number; bySeverity: Record<Severity, number> };
export type RunReport = {
  project: string;
  runDir: string;
  startedAt: string;
  finishedAt: string;
  before: ScoreSummary;
  after: ScoreSummary;
  fixed: ScoredVuln[];
  introduced: ScoredVuln[];
  decisions: SummaryRow[];
  rejected: { dep: string; version: string; step: string; firstError: string; logFile?: string; members?: SummaryRow['members'] }[];
  excluded: { dep: string; version: string; step: string; reason: string; logFile?: string; members?: SummaryRow['members'] }[];
  notes: string[];
  limitations: string[];
};

const LIMITATIONS = [
  'Only direct dependencies with an explicit version in the build files (pom.xml; build.gradle(.kts), gradle.properties or the version catalog) are updated; versions managed by a parent POM, BOM or platform are never changed.',
  'Transitive dependencies are not pinned; their versions change only through the direct dependency that brings them.',
  'Scores cover the resolved tree the packaged application ships (Maven runtime scope; Gradle productionRuntimeClasspath when Spring Boot defines it, otherwise runtimeClasspath), using OSV data at run time.',
  'Only the root module of multi-module projects is analysed.',
  'Direct dependencies that share a version property or catalog ref, or belong to a library family aligned at baseline, are upgraded together and never one at a time.',
];

const summary = (s: TreeScore): ScoreSummary => ({ distinct: s.vulns.length, rate: s.rate, bySeverity: s.bySeverity });

export function buildReport(input: ReportInput): RunReport {
  const { fixed, introduced } = diffVulns(input.before, input.after);
  const decisions: SummaryRow[] = [];
  for (const e of input.events) {
    const group = e.groupReason ? `group (${e.groupReason}): ` : '';
    const members = e.members ? { members: e.members } : {};
    if (e.type === 'adopted') decisions.push({ dep: e.dep!, from: e.from!, to: e.version!, outcome: 'adopted', note: `${group}fixed ${e.removed?.length ?? 0}, introduced ${e.added?.length ?? 0}`, ...members });
    if (e.type === 'kept') decisions.push({ dep: e.dep!, from: e.version!, to: e.version!, outcome: 'kept', note: `${group}${e.reason ?? ''}`, ...members });
    if (e.type === 'skipped') decisions.push({ dep: e.dep!, from: e.version!, to: e.version!, outcome: 'skipped', note: `${group}${e.reason ?? ''}`, ...members });
  }
  return {
    project: input.project,
    runDir: input.runDir,
    startedAt: input.startedAt,
    finishedAt: input.finishedAt,
    before: summary(input.before),
    after: summary(input.after),
    fixed,
    introduced,
    decisions,
    rejected: input.events.filter(e => e.type === 'rejected').map(e => ({ dep: e.dep!, version: e.version!, step: e.step!, firstError: e.firstError ?? e.reason ?? '', logFile: e.logFile, ...(e.members ? { members: e.members } : {}) })),
    excluded: input.events.filter(e => e.type === 'excluded').map(e => ({ dep: e.dep!, version: e.version!, step: e.step!, reason: e.reason ?? '', logFile: e.logFile, ...(e.members ? { members: e.members } : {}) })),
    notes: input.notes ?? [],
    limitations: LIMITATIONS,
  };
}

const SEVERITIES: Severity[] = ['critical', 'high', 'medium', 'low', 'unknown'];

/** One markdown table cell: escapes `|`, collapses newlines; `code` wraps free text in backticks so `<T>` and `*` survive rendering. */
export function cell(text: string | undefined, opts: { code?: boolean } = {}): string {
  const flat = (text ?? '').replace(/\r?\n+/g, ' ').replace(/\|/g, '\\|').trim();
  if (!opts.code || !flat) return flat;
  const ticks = flat.includes('`') ? '``' : '`';
  return `${ticks}${ticks === '``' ? ' ' : ''}${flat}${ticks === '``' ? ' ' : ''}${ticks}`;
}
const free = (text: string | undefined) => cell(text, { code: true });
const vulnRow = (v: ScoredVuln) => `| ${cell(v.id)} | ${v.severity} | ${v.score.toFixed(1)} | ${v.scoreSource} | ${cell(v.packages.join(', '))} |`;

export function renderMarkdown(r: RunReport): string {
  const lines = [
    `# Safer report — ${r.project}`,
    '',
    `Run: ${r.startedAt} → ${r.finishedAt}  ·  run dir: \`${r.runDir}\``,
    '',
    '## Vulnerabilities (distinct IDs, runtime tree)',
    '',
    '| severity | before | after |',
    '|---|---|---|',
    ...SEVERITIES.map(s => `| ${s} | ${r.before.bySeverity[s]} | ${r.after.bySeverity[s]} |`),
    `| **total** | **${r.before.distinct}** | **${r.after.distinct}** |`,
    `| rate | ${r.before.rate.toFixed(1)} | ${r.after.rate.toFixed(1)} |`,
    '',
    `### Fixed (${r.fixed.length})`,
    '',
    ...(r.fixed.length ? ['| id | severity | score | source | packages (before) |', '|---|---|---|---|---|', ...r.fixed.map(vulnRow)] : ['None.']),
    '',
    `### Introduced (${r.introduced.length})`,
    '',
    ...(r.introduced.length ? ['| id | severity | score | source | packages (after) |', '|---|---|---|---|---|', ...r.introduced.map(vulnRow)] : ['None.']),
    '',
    '## Decisions',
    '',
    '| dependency | from | to | outcome | note |',
    '|---|---|---|---|---|',
    ...r.decisions.map(d => `| ${cell(d.dep)} | ${cell(d.from)} | ${d.outcome === 'adopted' ? cell(d.to) : ''} | ${d.outcome} | ${free(d.note)} |`),
    '',
    `## Rejected candidates (${r.rejected.length})`,
    '',
    ...(r.rejected.length ? ['| dependency | version | step | first error | log |', '|---|---|---|---|---|', ...r.rejected.map(x => `| ${cell(x.dep)} | ${cell(x.version)} | ${x.step} | ${free(x.firstError)} | ${cell(x.logFile)} |`)] : ['None.']),
    '',
    `## Excluded candidates (${r.excluded.length})`,
    '',
    ...(r.excluded.length ? ['| dependency | version | step | reason | log |', '|---|---|---|---|---|', ...r.excluded.map(x => `| ${cell(x.dep)} | ${cell(x.version)} | ${x.step} | ${free(x.reason)} | ${cell(x.logFile)} |`)] : ['None.']),
    '',
    ...(r.notes.length ? ['## Notes', '', ...r.notes.map(n => `- ${n.replace(/\r?\n+/g, ' ')}`), ''] : []),
    '## Limitations',
    '',
    ...r.limitations.map(l => `- ${l}`),
    '',
  ];
  return lines.join('\n');
}

export function writeReport(runDir: string, r: RunReport): void {
  fs.writeFileSync(path.join(runDir, 'report.json'), JSON.stringify(r, null, 2));
  fs.writeFileSync(path.join(runDir, 'report.md'), renderMarkdown(r));
}
