/**
 * Tells infrastructure failures (repository down, network, a mirror that stopped serving) apart from genuine
 * incompatibilities in a Maven/Gradle log. Without this, an outage looks like candidates failing to resolve or build,
 * and Safer would silently exclude or reject good versions.
 */

/** Resolution lines that mean the repository could not be reached or answered with an error: always infrastructure. */
const TRANSFER = [
  /Could not transfer (?:artifact|metadata) \S+ (?:from\/to|to|from) .*/, // Maven: connection refused, unknown host, 5xx, 401...
  /Could not (?:GET|HEAD) '(?:https?:[^']+)'.*/, // Gradle
  /Could not resolve [^\s:]+:[^\s:]+:[^\s.]+.*\.\s*>\s*(?:Could not (?:GET|HEAD)|Connect|.*timed out|.*refused).*/, // Gradle nested cause on one line
];

/** "Not found" mentions with the coordinates in groups: they are infrastructure only when Maven Central has the artifact. */
const NOT_FOUND = [
  /Could not find artifact ([^\s:]+):([^\s:]+):((?:[^\s:]+:)*?)([^\s:]+) in /g, // Maven: g:a:ext[:classifier]:v
  /Failure to find ([^\s:]+):([^\s:]+):((?:[^\s:]+:)*?)([^\s:]+) in /g, // Maven: cached failure (.lastUpdated)
  /Could not find ([^\s:]+):([^\s:]+):()([^\s:]+?)\.(?:\s|$)/gm, // Gradle: g:a:v.
];

/**
 * Maven 3.9 (enhanced local repository) refuses an artifact that is in ~/.m2 but was downloaded from another repository
 * id: the build fails although nothing is missing, so it is never the candidate's fault.
 */
const PRESENT_UNAVAILABLE = /(\S+) \(present, but unavailable\)/;

export type Gav3 = { group: string; name: string; version: string };

/** Coordinates of every artifact the log says could not be found (unique, in order of appearance). */
export function notFoundArtifacts(log: string): Gav3[] {
  const seen = new Map<string, Gav3>();
  for (const re of NOT_FOUND) {
    for (const m of log.matchAll(re)) {
      const gav = { group: m[1], name: m[2], version: m[4] };
      seen.set(`${gav.group}:${gav.name}:${gav.version}`, gav);
    }
  }
  return [...seen.values()];
}

/** The first repository transfer error in the log, if any. */
export function transferError(log: string): string | undefined {
  for (const line of log.split('\n')) {
    for (const re of TRANSFER) {
      const m = line.match(re);
      if (m) return m[0].trim().slice(0, 400);
    }
  }
  return undefined;
}

/** True/false: Maven Central has the artifact's pom; throws when Central cannot be asked. */
export type CentralCheck = (gav: Gav3) => Promise<boolean>;

export const mavenCentralHas: CentralCheck = async ({ group, name, version }) => {
  const url = `https://repo1.maven.org/maven2/${group.replace(/\./g, '/')}/${name}/${version}/${name}-${version}.pom`;
  const res = await fetch(url, { method: 'HEAD', signal: AbortSignal.timeout(20_000) });
  if (res.status === 200) return true;
  if (res.status === 404) return false;
  throw new Error(`HTTP ${res.status} from ${url}`);
};

/**
 * Explains why the log's failure is an infrastructure problem, or undefined when it is not (or cannot be told apart
 * from a genuine one). At most `maxChecks` not-found artifacts are looked up on Maven Central.
 */
export async function infraFailure(log: string, centralHas: CentralCheck = mavenCentralHas, maxChecks = 5): Promise<string | undefined> {
  const transfer = transferError(log);
  if (transfer) return `repository transfer failed: ${transfer}`;
  const cached = log.match(PRESENT_UNAVAILABLE);
  if (cached) return `local repository has ${cached[1]} but Maven would not use it (downloaded from another repository; Maven 3.9 _remote.repositories)`;
  for (const gav of notFoundArtifacts(log).slice(0, maxChecks)) {
    const id = `${gav.group}:${gav.name}:${gav.version}`;
    let onCentral: boolean;
    try {
      onCentral = await centralHas(gav);
    } catch (err) {
      return `${id} could not be resolved and Maven Central could not be reached to check it (${err instanceof Error ? err.message : err})`;
    }
    if (onCentral) return `the build's repository did not serve ${id}, which Maven Central has (is the local Nexus/mirror healthy?)`;
  }
  return undefined;
}
