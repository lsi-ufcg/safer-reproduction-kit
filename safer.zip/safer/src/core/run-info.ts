import { execFileSync } from 'child_process';

type Git = (args: string[]) => string;

const realGit: Git = args => execFileSync('git', args, { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'], timeout: 10_000 });

/** Safer's own revision for run.json (read-only git); `unknown` when git or the repository is unavailable. */
export function saferRevision(saferRoot: string, git: Git = realGit): { revision: string; dirty: boolean } {
  try {
    const revision = git(['-C', saferRoot, 'rev-parse', '--short', 'HEAD']).trim() || 'unknown';
    let dirty = false;
    try {
      dirty = git(['-C', saferRoot, 'status', '--porcelain', '--untracked-files=no']).trim().length > 0;
    } catch {
      // revision known, cleanliness not: report clean rather than fail
    }
    return { revision, dirty };
  } catch {
    return { revision: 'unknown', dirty: false };
  }
}
