import 'dotenv/config';

export const OSV_BASE_URL = 'https://api.osv.dev/v1';
export const MVN_REPOSITORY_BASE_URL = 'https://repo1.maven.org/maven2';
export const SONATYPE_REPOSITORY_BASE_URL = 'https://central.sonatype.com/api/internal/browse/component/versions';
export const DEPS_DEV_BASE_URL = 'https://deps.dev/_/s';