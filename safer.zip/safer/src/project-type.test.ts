import fs from 'fs';
import os from 'os';
import path from 'path';

import { describe, expect, it } from 'vitest';

import { detectProjectType } from './project-type';

const dirWith = (...files: string[]) => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'safer-type-'));
  for (const f of files) fs.writeFileSync(path.join(dir, f), '');
  return dir;
};

describe('detectProjectType', () => {
  it('detects Maven from pom.xml', () => expect(detectProjectType(dirWith('pom.xml'))).toBe('maven'));
  it('detects Gradle from build.gradle', () => expect(detectProjectType(dirWith('build.gradle'))).toBe('gradle'));
  it('detects Gradle from build.gradle.kts', () => expect(detectProjectType(dirWith('build.gradle.kts', 'settings.gradle.kts'))).toBe('gradle'));
  it('prefers pom.xml when both exist', () => expect(detectProjectType(dirWith('build.gradle', 'pom.xml'))).toBe('maven'));
  it('returns null otherwise', () => expect(detectProjectType(dirWith('README.md'))).toBeNull());
});
