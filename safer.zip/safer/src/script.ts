import { promises } from 'fs';
import path from 'path';

import * as dotenv from 'dotenv';

import { getJsonConfig } from './helpers/get-config';
import { detectProjectType } from './project-type';
import { runForGradle } from './runners/gradle/script';
import { runForMaven } from './runners/maven/script';
import { ConfigType, ProjectType } from './types/config';

const runByProjectType: Record<ProjectType, (config: ConfigType) => Promise<void>> = {
  maven: runForMaven,
  gradle: runForGradle,
};

async function main() {
  // Safer's root .env (Safer is started from src/, so its root is the parent unless SAFER_ROOT_PATH says otherwise)
  dotenv.config({ path: path.join(process.env.SAFER_ROOT_PATH ?? path.resolve('..'), '.env') });

  const projectAbsolutePath = process.env.PROJECT_ROOT_PATH;
  if (!projectAbsolutePath) {
    console.error('PROJECT_ROOT_PATH must be set to the absolute path of the project to analyse.');
    process.exit(1);
  }

  const stats = await promises.stat(projectAbsolutePath).catch(() => null);
  if (!stats?.isDirectory()) {
    console.error('Invalid project absolute path. Please enter a valid directory path.');
    process.exit(1);
  }

  const projectType = detectProjectType(projectAbsolutePath);
  if (!projectType) {
    console.error('Invalid project type: no pom.xml, build.gradle or build.gradle.kts found. Consult the documentation for supported types.');
    process.exit(1);
  }

  const jsonConfig = await getJsonConfig(); // exits with a message when the config is invalid
  const config: ConfigType = { ...jsonConfig, projectType, projectAbsolutePath };
  try {
    await runByProjectType[projectType](config);
  } catch (error) {
    console.error(`An error occurred while running the script: ${error instanceof Error ? error.stack : error}`);
    process.exitCode = 1;
  }
}

main();
