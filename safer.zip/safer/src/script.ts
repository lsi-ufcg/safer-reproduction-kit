import fs, { promises } from 'fs';
import path from 'path';

import * as dotenv from 'dotenv';
import minimist from 'minimist';

import { getJsonConfig } from '#helpers/get-config';
import { RandoopRunner } from '#runners/randoop/randoop-runner';
import { JavaRunner } from '#runners/java/java-runner';
import { ConfigType, JsonConfigType, ProjectType } from '#types/config';

import { runForMaven } from './runners/maven/script';
import { runForGradle } from './runners/gradle/script';
import { constants } from './utils/contants';
import loggerSync from './utils/logger';


const args = minimist(process.argv.slice(2));

const runByProjectType: Record<ProjectType, (config: ConfigType) => void> = {
  maven: (config: ConfigType) => runForMaven(config),
  gradle: (config: ConfigType) => runForGradle(config),
};

function initTempDirectory(config: ConfigType): void {
  const { projectType, executions } = config;
  const tempDirPath = constants.tempDir;
  const reportDirPath = path.join(tempDirPath, 'report');
  const logsDirPath = path.join(tempDirPath, 'logs');

  fs.mkdirSync(tempDirPath, { recursive: true });
  fs.mkdirSync(reportDirPath, { recursive: true });
  fs.mkdirSync(logsDirPath, { recursive: true });

  const reportFilePath = path.join(reportDirPath, `${projectType}.log`);
  const errorLogFilePath = path.join(logsDirPath, 'error.log');
  const combinedLogFilePath = path.join(logsDirPath, 'combined.log');

  if (executions.clearLastReport && fs.existsSync(reportFilePath)) {
    fs.writeFileSync(reportFilePath, '');
  }

  if (executions.clearLastLogs) {
    if (fs.existsSync(errorLogFilePath)) {
      fs.writeFileSync(errorLogFilePath, '');
    }
    if (fs.existsSync(combinedLogFilePath)) {
      fs.writeFileSync(combinedLogFilePath, '');
    }
  }
}

async function main() {
  
  dotenv.config({
    path: path.resolve('.', '.env'),
  });

  let projectType = null;
  let projectAbsolutePath = process.argv[2] ?? process.env.PROJECT_ROOT_PATH;

  if(fs.existsSync(`${projectAbsolutePath}/pom.xml`)){
    console.log("THERE IS MAVEN!!!")
    projectType = 'maven';
  }else if(fs.existsSync(`${projectAbsolutePath}/build.gradle`)){
    projectType = 'gradle';
  }else{
    loggerSync({ level: 'error', message: 'Invalid project type. Consult the documentation for supported types.' });
    return;
  }

  if (!projectType || !projectAbsolutePath) {
    loggerSync({ level: 'error', message: 'Both --projectType and --projectAbsolutePath must be provided as arguments.' });
    return;
  }

  const stats = await promises.stat(projectAbsolutePath);
  if (!stats.isDirectory()) {
    console.error('Invalid project absolute path. Please enter a valid directory path.');
    process.exit(1);
  }

  const validProjectTypes = ['maven', 'gradle'];
  if (!validProjectTypes.includes(projectType)) {
    console.error('Invalid project type. Consult the documentation for supported types.');
    process.exit(1);
  }

  let jsonConfig = {} as JsonConfigType;
  try {
    jsonConfig = await getJsonConfig();
    
  } catch (error) {
    loggerSync({ level: 'error', message: 'An error occurred while reading config:', object: error });
    return;
  }

  const config: ConfigType = {...jsonConfig, projectType, projectAbsolutePath};

  initTempDirectory(config);
  try {
    runByProjectType[config.projectType](config);
  } catch (error) {
    RandoopRunner.deleteRandoopFiles(config.projectAbsolutePath);
    JavaRunner.deleteJavaContainer();
    loggerSync({ level: 'error', message: 'An error occurred while running the script:', object: error });
    return;
  }
}

main();
