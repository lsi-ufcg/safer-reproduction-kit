export const SEMANTIC_VERSIONING_REGEX = /[0-9]+\.[0-9]+\.[0-9]+/;
