# Safer

Safer looks at the direct dependencies of a Maven or Gradle project and, for each one, tries newer versions that leave the application with fewer known vulnerabilities. A new version is adopted only if the project still builds, passes its checks, and does not drag its related libraries onto mismatched versions. Every decision is recorded with the reason for it.

## Prerequisites

- Node.js 20 or newer, with npm (`.nvmrc` pins 20: run `nvm use`)
- Docker (Safer builds the project inside a container; the project's own JDK, Maven or Gradle are not needed on the host, except by a `smokeTest` command, which runs on the host. A Gradle project must include its wrapper, `gradlew` and `gradle/wrapper/`)
- Network access to Maven Central's search API (`central.sonatype.com`, with `repo1.maven.org` as a fallback) and OSV (`api.osv.dev`)

## Installation

```bash
npm install
```

## Configuration

Safer reads `config.json` from its own root directory. Set `SAFER_CONFIG` to read a different file. The file is validated against `src/types/schema_config.json`. The project to analyse is not part of the file: you pass it with `PROJECT_ROOT_PATH` (see Execution), and its type is detected from the project root: `pom.xml` means Maven; otherwise `build.gradle` or `build.gradle.kts` means Gradle. A directory with none of them is refused.

```json
{
  "$schema": "src/types/schema_config.json",
  "weightVulnerability": { "low": 1, "medium": 2, "high": 3, "critical": 5 },
  "executions": {
    "buildProject": true,
    "projectTests": true,
    "exploratoryTesting": false
  },
  "exploratoryTestingParams": { "timeLimitGeneratingTests": 30 },
  "allowPrerelease": false,
  "alignmentCheck": true,
  "smokeTest": {
    "enabled": true,
    "command": "bash ./smoke.sh",
    "timeoutSec": 300
  },
  "osv": { "concurrency": 8, "retries": 3 },
  "buildTimeoutSec": 3600
}
```

- `$schema`: reference to the schema, for editor completion. Do not change it.
- `weightVulnerability`: how much each severity counts. A tree's rate is the sum of `score x weight` over its distinct vulnerabilities, and lower is better.
- `executions.buildProject`: build the project (inside the container) before and after each change. With `false`, no candidate is validated: the best-scoring candidate that passes the alignment check is written to the build file (`pom.xml`, or the Gradle files) and kept, unbuilt and untested. Use it only for experiments, and review the result.
- `executions.projectTests`: run the project's tests as part of every build. Ignored if the project has no tests. If the baseline fails with tests on, Safer aborts and tells you to fix the build or turn this off.
- `executions.exploratoryTesting`: also generate Randoop regression tests against the unchanged project and run them against every candidate.
- `executions.clearLastLogs`, `executions.clearLastReport`: deprecated and ignored (every run gets its own directory). They are optional; older configs that still set them remain valid.
- `exploratoryTestingParams.timeLimitGeneratingTests`: seconds Randoop spends generating tests (default 60 when omitted).
- `allowPrerelease`: consider alpha, beta, milestone, RC, snapshot and similar versions. Default `false`.
- `alignmentCheck`: reject candidates that move only part of a library family to the new version (see below). Default `true`.
- `smokeTest`: an optional command that starts or exercises the packaged application. Unlike the build, it runs **on the host**, not in the container, so whatever it calls (for example `java -jar "$SAFER_ARTIFACT"`) must be installed on the host. It runs from the project directory with `SAFER_PROJECT_PATH`, `SAFER_ARTIFACT` (the packaged jar) and `SAFER_ATTEMPT_DIR` set. Exit code 0 means pass. It is killed, with its child processes, after `timeoutSec` seconds.
- `osv.concurrency`, `osv.retries`: parallel requests to OSV and retries per request.
- `buildTimeoutSec`: seconds a project build (`mvn clean verify`, or `./gradlew clean build`, in the container) may run before it is killed; the candidate is then rejected with `timeout after Ns`, or the run stops if it is the baseline build. Default 3600. Dependency resolution calls (Maven `dependency:list` and `dependency:build-classpath`, Gradle `saferDeps` and `saferClasspath`) have a fixed limit of 600 seconds; a candidate whose resolution times out is excluded.

Environment variables:

- `PROJECT_ROOT_PATH`: absolute path of the project to analyse.
- `SAFER_ROOT_PATH`: absolute path of this repository (default: the parent of the working directory, since Safer is started from `src/`).

These can also be set in a `.env` file at the root of this repository (copy `.env.example`).
- `SAFER_CONFIG`: alternative config file.
- `SAFER_CONTAINER_MEMORY`: memory limit of the build container (default `4g`).

## Execution

```bash
cd src
PROJECT_ROOT_PATH=/abs/path/to/project SAFER_ROOT_PATH=/abs/path/to/safer npx tsx script.ts
```

Safer edits the project's `pom.xml` (Maven) or its `build.gradle`/`build.gradle.kts`, `gradle.properties` and `gradle/libs.versions.toml` (Gradle) while it tries candidates. When it finishes, fails, or is interrupted (Ctrl+C, `SIGTERM`, or `SIGHUP` when the terminal closes), it puts these files back to the last accepted state: the original files plus the versions adopted so far. Nothing else is changed, apart from build output: the `target/` (Maven) or `build/` (Gradle) directory of the last build is left in the project, while Gradle's `.gradle/` project cache is never created there (it lives in the container under `/tmp/.gradle/project-cache`). The temporary files (`.safer-*` for Maven, `build/safer/` for Gradle) and the build container are removed. Review the adopted versions with your version control before keeping them.

## How Safer decides

1. **Candidates.** For each direct dependency with an explicit `<version>`, Safer lists the versions published on Maven Central that are newer than the current one (from Sonatype's Central search API; if that lookup fails, from the artifact's `maven-metadata.xml`, which can miss some old releases). Pre-releases are dropped unless `allowPrerelease` is set or the current version is itself a pre-release, and so are versions with a different qualifier such as `-jre` versus `-android`. Dependencies whose version comes from a parent or BOM, and `test` or `provided` dependencies, are skipped because changing them cannot alter the shipped runtime tree.

   **Grouping.** Direct dependencies that must move together form one update unit: those whose version comes from the same property or catalog `version.ref`, and those of one library family (see Alignment) whose artifacts all shared a major.minor version in the baseline tree. A unit is upgraded only as a whole: each candidate moves every member to the same version, or, for a member that has no release at that version, to its newest release in the same major.minor; a version some member cannot follow is not a candidate. A shared property is edited only when every use of it is in the unit and all members move to the same version; otherwise (for example a member lagging a patch) each declaration gets a literal version. Grouped units appear in the console and report as `<groupId> [artifact, …]` when the members share a groupId, otherwise `[group:artifact, …]`, and their events in `decisions.jsonl` carry `members` (each member's from/to version) and `groupReason` (`property`, `family` or `property+family`).
2. **Scoring.** For the baseline and for every candidate, Safer resolves the full runtime dependency tree with the project's build tool and looks up every artifact in OSV. Each distinct vulnerability counts once, even when several advisory ids or packages refer to it. Its score is the CVSS v3 base score; without a vector, the floor of its GitHub severity label; with neither it counts as `unknown` with weight 0. Scores map to the bands low (< 4.0), medium (< 7.0), high (< 9.0) and critical, and the rate is the weighted sum. If a lookup fails, the candidate is excluded rather than scored as clean.
3. **Selection.** Candidates whose rate is lower than the current one are tried in order of lowest rate, then lowest version.
4. **Alignment.** A library family is the set of artifacts whose groupIds share their first three segments (for example `com.fasterxml.jackson` for `com.fasterxml.jackson.core` and `com.fasterxml.jackson.dataformat`). Only families with at least two artifacts that all shared one major.minor version in the current tree are checked. If the candidate makes such a family resolve to more than one major.minor, it is rejected before any build. When two artifacts differ only by a `-jdkNNon` suffix (for example `bcprov-jdk15on` and `bcprov-jdk18on`), the reason says that both providers end up on the runtime classpath. Every `scored` event in `decisions.jsonl` also records `aligned` (and the `misalignment`, if any), including candidates that were never tried.
5. **Build and tests.** The candidate is applied to the build file and the project is built in the container, with its tests if `projectTests` is on.
6. **Exploratory tests.** With `exploratoryTesting`, Randoop tests generated from the baseline, and checked to pass on it, must still pass. Randoop tests every class compiled into the tool's classes directory (`target/classes` for Maven, `build/classes/java/main` for Gradle).
7. **Smoke test.** If configured, the smoke command must exit with 0.
8. **Adoption.** The first candidate that passes every step is adopted and becomes the new baseline for the next dependency. If none passes, the current version is kept.

## Output

Each run writes to `$SAFER_ROOT_PATH/.temp/runs/<yyyyMMdd-HHmmss>-<project>/`:

- `report.md` and `report.json`: before and after vulnerability counts, every decision with its reason, and the known limitations.
- `decisions.jsonl`: every event of the run, one JSON object per line.
- `run.json`: configuration, timing and totals, plus `status` (`ok`, `failed` or `aborted`; a failed run also records `failedStep` and `error`) and `tools` (Safer's git revision and dirty flag, Node, the detected Java version and the container's Maven version, or the wrapper's Gradle version).
- `trees/baseline.txt`, `trees/final.txt`: the resolved runtime tree before and after the run, one sorted `group:artifact:version` per line.
- `attempts/<group_artifact>/<version>/{build,randoop,smoke}.log`: full output of each step of each attempt. `baseline/` holds the same for the baseline.
- `osv/ids.json`, `osv/records.json`: the OSV data used, for auditing.

The console shows one line per decision and never raw build output:

```
13:35:16 BASELINE  build ok (tests on, 5m12s) · 172 vulns (C13 H73 M74 L12 U0) · rate 3079.2
13:41:02 REJECT    com.fasterxml.jackson.dataformat:jackson-dataformat-xml 2.18.2 · alignment: com.fasterxml.jackson split 2.14 [jackson-annotations, jackson-core, jackson-databind] vs 2.18 [jackson-dataformat-xml]
13:52:40 ADOPT     io.minio:minio 8.5.2 → 8.5.10 · rate 3079.2 → 3056.7 · fixed 1, introduced 0
13:52:41 KEEP      io.opentelemetry:opentelemetry-api 1.64.0 · no candidate scores lower than current (rate 3056.7; 3 scored, best 1.65.0 at rate 3056.7)
13:52:41 SKIP      org.projectlombok:lombok 1.18.26 · version managed by parent/BOM
```

It ends with a summary table and the run directory. Lines that begin with `EXCLUDE` mean a candidate could not be scored (with the Maven or Gradle log when resolution failed), and `REJECT` lines say which step failed and give the log to read. If Randoop cannot generate tests, or the generated tests already fail on the unchanged project (so they would reject every candidate), a `BASELINE` line says so and the run continues without Randoop. If the run itself fails, a `RUN FAILED · <step>: <message>` line is printed, the event is recorded as `run-failed` in `decisions.jsonl`, and `run.json` gets `status: "failed"`. If the final tree cannot be re-resolved, the report uses the last accepted tree and score and says so in its Notes; a final rate that differs from the last accepted one is printed as a `WARNING` line.

## Gradle projects

Gradle projects go through the same planner, scoring, alignment check, Randoop and smoke steps as Maven projects; only the build-tool layer differs (`src/runners/gradle/gradle-tool.ts`). Only the root project is analysed.

**Where Gradle runs.** Every Gradle call runs inside the build container through the project's own wrapper: `./gradlew --console=plain --no-configuration-cache -g /tmp/.gradle -Dorg.gradle.jvmargs=-Xmx768m --init-script /safer/safer.init.gradle …`, one call at a time. The container mounts:

- the project at `/app`;
- `~/.cache/safer/gradle` at `/tmp/.gradle` (`GRADLE_USER_HOME`: wrapper distributions and the dependency cache, kept between runs);
- `src/runners/gradle` read-only at `/safer`, for the init script.

When a Gradle call times out, the Gradle daemon is killed too (`pkill`, or `./gradlew --stop` if the image has no `pkill`). An out-of-memory kill of the test worker or the daemon is reported as `killed (likely out of memory)`. Compile and test classpath dependencies that do not resolve do not fail the run; their counts are written to `gradle-discovery.log` in the run's log directory. The container is removed at the end of the run. The Java version of the container comes from the build file (`JavaLanguageVersion.of(N)`, `JavaVersion.VERSION_N` or `sourceCompatibility`), and defaults to 17.

**Init script.** `src/runners/gradle/safer.init.gradle` adds two tasks to the root project. Neither changes the build files:

- `saferDeps` writes JSON with the declared direct dependencies and the resolved shipped tree, `compileClasspath` and `testRuntimeClasspath` components. The shipped tree is Spring Boot's `productionRuntimeClasspath` (what `bootJar`/`bootWar` package: `runtimeClasspath` without `developmentOnly`) when the plugin defines it, otherwise `runtimeClasspath`. An unresolved runtime dependency fails the task, because a partial tree would score as having fewer vulnerabilities. With `-PsaferOverride=group:name:version[,group:name:version…]`, it rewrites the declared versions of those direct dependencies in every configuration (the same as editing the build file, not a force), so a candidate is resolved without touching the files.
- With `-PsaferBatchFile=<file>`, a JSON object of plans (`{ "<version>": { "group:name": "version", … } }`), `saferDeps` also resolves the shipped tree once per plan in the same invocation, each from a named copy of the shipped configuration with those versions required. Safer sends candidates 25 at a time, which avoids paying Gradle's startup and configuration cost (several seconds) per candidate. Each batch also resolves an unmodified copy as a control; if it differs from the shipped tree (for example, a build that customises the resolution strategy of that configuration), Safer logs it to `gradle-discovery.log` and resolves one version per Gradle call for the rest of the run.
- `saferClasspath` writes `sourceSets.main.runtimeClasspath` for Randoop.

Both write under `build/safer/`, which Safer deletes.

**Build.** `./gradlew clean build`, with `-x test -x compileTestJava` when `projectTests` is off. The smoke test gets the newest `build/libs/*.jar` or `*.war`, ignoring `-plain`, `-sources` and `-javadoc` archives.

**Declarations Safer can edit.** These are read only from top-level `dependencies { }` blocks of `build.gradle` or `build.gradle.kts`. Blocks inside `buildscript`, `constraints`, `subprojects` and `allprojects` are ignored, and so is commented-out code.

- String notation: `implementation 'g:a:1.0'`, `implementation("g:a:1.0")`.
- Groovy map notation: `implementation group: 'g', name: 'a', version: '1.0'`.
- Kotlin named arguments: `implementation(group = "g", name = "a", version = "1.0")`.
- Version-catalog aliases: `implementation(libs.some.lib)`, with the library in `gradle/libs.versions.toml` holding either a literal version or a `version.ref`.

A version may come from a variable:

- `"g:a:$x"`, `"${x}"`, `"${project.x}"`, `"${rootProject.ext.x}"` or `"${property("x")}"` in string notation, or a bare name in map notation;
- defined in `gradle.properties`, `ext.x = '…'`, an `ext { }` block, `def x = '…'`, Kotlin `val x = "…"` or `extra["x"] = "…"`.

When such a variable, or a catalog `version.ref`, is used by exactly one declaration, Safer edits its definition. When it is shared, Safer writes a literal version at that one declaration instead, and the event records `property-inlined`, as for shared Maven properties.

**Version managed.** A direct dependency declared without a version gets it from somewhere else: the Spring `io.spring.dependency-management` plugin (`dependencyManagement { imports { mavenBom … } }`), a `platform(…)`/`enforcedPlatform(…)` BOM, or a plugin. Safer treats it like a Maven dependency managed by a parent or BOM: it is skipped with `version managed by parent/BOM`, and the BOM itself is never changed. Dependencies added by plugins rather than the build file are listed too, and are skipped in the same way.

**Scope mapping.** Configurations map to Maven-like scopes:

| Configuration | Scope |
|---|---|
| `implementation`, `api` | `compile` |
| `runtimeOnly` | `runtime` |
| `compileOnly`, `annotationProcessor`, `developmentOnly` | `provided` |
| `testImplementation`, `testRuntimeOnly` | `test` |

A dependency declared in several configurations takes the most shipped scope (compile, then runtime, then provided, then test). As with Maven, `provided` and `test` dependencies are skipped, and only the shipped tree (`productionRuntimeClasspath`, or `runtimeClasspath`) is scored. Other configurations (for example `kapt`, or custom ones) are not reported.

**Gradle limitations.**

- Root project only: subprojects of a multi-project build are neither analysed nor edited.
- Versions declared in `buildSrc` or in convention plugins are not seen, so those dependencies look version-managed and are skipped.
- Kotlin `extra` delegates other than `val x = "…"` and `extra["x"] = "…"` (for example `val x: String by project`) are not followed.
- Dependency locking (`gradle.lockfile`, `--write-locks`) is not supported: Safer does not update lock files, so a locked build may reject the candidates.
- The project must use the Gradle wrapper (`./gradlew`), and the build must work with `--no-configuration-cache`.

## Maven cache (Nexus)

Before starting the build container, Safer starts a local Nexus Repository container, `nexus-safer`, on port 8081 (`src/runners/nexus/start-nexus.sh`) and points Maven at it (`src/runners/nexus/settings.xml`), so artifacts are downloaded from Maven Central once and reused across runs. The container and its volume `nexus-safer-data` are kept between runs; the first start can take a few minutes. On first start the script enables anonymous access and accepts the Nexus Community Edition EULA (https://links.sonatype.com/products/nxrm/ce-eula), which Nexus requires before it serves artifacts. If Nexus does not come up (within `NEXUS_START_TIMEOUT` seconds, default 300), Maven downloads directly from Maven Central. Downloaded artifacts are also kept in `~/.cache/safer/m2` on the host.

**Repository or network failures stop the run.** A Nexus that is up but no longer fetches from Central, or a network outage, would otherwise look like candidates that fail to resolve or build. So every failed baseline build, excluded candidate and rejected build is checked (`src/core/infra.ts`). A repository transfer error (`Could not transfer artifact …`, Gradle's `Could not GET '…'`) counts as an infrastructure failure. So does an artifact reported as not found that Maven Central does have, or that cannot be checked because Central is unreachable. When either happens, Safer restores the build files and stops with `Aborted: … the build's repository did not serve g:a:v, which Maven Central has`, instead of recording a wrong verdict. Fix the repository, for example with `docker restart nexus-safer`, which clears an auto-blocked proxy and its cache of not-found answers. Delete any recent `*.lastUpdated` files under `~/.cache/safer/m2/repository`, then run again. An artifact that Central does not have either is a genuine failure and is recorded as usual.

**Concurrent runs.** Each run has its own build container, `java-container-safer-<Safer pid>`, and its own image tag per Java version, `java-setup:<version>`. Several Safer runs can therefore share a machine (and the Nexus cache). At start, Safer removes containers left behind by runs whose process no longer exists, and never touches those of runs still alive.

## Development

```bash
npm test
npm run typecheck
npm run lint
```

## Limitations

- Only direct dependencies with an explicit version in the project's build file are updated (an explicit `<version>` in the pom, or a declared version in Gradle); parent/BOM-managed versions are never changed.
- Transitive dependencies are not pinned; their versions change only through the direct dependency that brings them.
- Scores cover the resolved tree the packaged application ships (Maven runtime scope; Gradle `productionRuntimeClasspath` when Spring Boot defines it, otherwise `runtimeClasspath`), using OSV data at run time.
- Only the root module of multi-module Maven projects, and the root project of multi-project Gradle builds, is analysed.
- Gradle: see [Gradle limitations](#gradle-projects) (`buildSrc`, dependency locking, Kotlin delegates).
- Dependencies that must move together are upgraded only as a group (see Grouping); a member is never tried alone.
- A unit with a member that is not on Maven Central (for example a private artifact sharing a version property with a public one) is kept as a whole; its public members are not upgraded.
