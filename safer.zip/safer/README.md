# Safer

## Introduction
Safer is an application designed to identify and mitigate vulnerabilities in software dependencies by evaluating the compatibility of their versions with a given project. This tool aims to enhance project security through detailed analysis and flexible configuration.

## Prerequisites
To run Safer, ensure you have the following installed:
- Node.js version 16.16.0 or higher
- npm version 8.11.0 or higher
- Docker version 26.1.1 or higher

## Configuration
Before using Safer, you must configure the application by modifying the config.json file located at the root of the project. This file is structured in JSON format and serves as the entry point for our solution. The configuration file is designed for customizing various phases and parameters of Safer, ensuring enhanced control over the execution and analysis of the target project.

Here is an example of the configuration file content:
```json
{
  "$schema": "../../src/types/schema_config.json",
  "projectType": "maven",
  "projectAbsolutePath": "/home/user/projeto",
  "weightVulnerability": {
    "low": 1,
    "medium": 2,
    "high": 3,
    "critical": 5
  },
  "executions": {
    "buildProject": true,
    "projectTests": true,
    "exploratoryTesting": true,
    "clearLastLogs": true,
    "clearLastReport": true
  },
  "exploratoryTestingParams": {
    "timeLimitGeneratingTests": 30
  }
}
```

### Configuration Details
- **schema**: This field acts as a reference to the configuration schema and is designated as read-only, indicating that it should not be altered by users.
- **projectType**: Specifies the type of build management tool used in the project, such as Maven or Gradle.
- **projectAbsolutePath**: Sets the absolute path of the project directory.
- **weightVulnerability**: This nested object assigns weights to the different severities of detected vulnerabilities, aiding in risk prioritization.
- **executions**: Details execution flags for different testing and building phases of the target project.
- **exploratoryTestingParams**: Contains specific parameters for conducting exploratory testing, including a time limit for test generation.

## Installation
To install Safer's dependencies, navigate to the project directory and run:
```bash
npm install
```

## Execution
To execute Safer, after configuring the `config.json` file and installing necessary dependencies, run:
```bash
npm run execute
```

For general execution (chossing between maven or gradle withtout randoop)
```
#inside /src
tsx script.ts
```